<#
.DESCRIPTION
    Deletes Items On Behalf of the File's Owner
.INPUTS
    dryviqServer                            =   SkySync server host and port
    dryviqAdminUser                         =   SkySync admin username
	dryviqAdminUserPassword                 =   SkySync admin user password
    connectionId			                =   Connection ID where items reside
    jobID                                   =   Migration JobID   
    transscriptPath			                =   Path to write Transcript file
    restrictDeletionToEmailAddressFormat	=   OPTIONAL: #optional. if specified, restricts deletion attempt to only owners matching the specified email address format.
    
.OUTPUTS
    CSV file in relative directory
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $dryviqServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'DeleteFiles.ps1' $dryviqServer=http://DESKTOP-9BHVIFS:9090/ $connectionId="46a08dd47b674b46bd8108314a1f2f51"
#>

Param(
    [string]$dryviqServer = "http://localhost:9090/",
    [string]$dryviqAdminUser = "admin",
    [string]$dryviqAdminUserPassword = 'P@ssword!',
    [string]$connectionId = "986512a0806b4a18a0e549f2919cb6fc",
    [string]$jobId = "161b2b0941254fedbfde7f1044911e2c",
    [string]$transscriptPath = ".\DeleteItems_transscript_" + (Get-Date).tostring("yyyyMMdd_hhmmss") + ".txt",
    [string]$restrictDeletionToEmailAddressFormat = "*skysynch.com" #Optional: if specified, restricts deletion attempt to only owners matching the specified email address format.
)

function get-skysync-access-token
{
    param( [string] $dryviqServer, [string] $dryviqAdminUser, [string] $dryviqAdminUserPassword )
    $accessRequestUrl = $dryviqServer + "connect/token"

    $accessRequestBody = @{
        grant_type = "password"
        scope      = "offline_access profile roles"
        resource   = $dryviqServer
        username   = $dryviqAdminUser
        password   = $dryviqAdminUserPassword
    }

    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
    return $accessRequestResult.access_token
}

function get-request-header
{
    param( [string]$accessToken )
    $requestHeader = @{
        Authorization = "Bearer " + $accessToken
        Accept        = "application/json"
    }
    return $requestHeader
}

function get-request-header-with-impersonation
{
    param( [string]$accessToken, [string]$username )
    $requestHeader = @{
        Authorization  = "Bearer " + $accessToken
        Accept         = "application/json"
        "X-Connect-As" = $username
    }
    return $requestHeader
}

function get-job-failed-to-delete-items($jobId)
{
    $offset = 0
    $totalItems = @()
    $maxItemsPerRequest = 1000
    $hasMore = $true

    $accessToken = get-skysync-access-token $dryviqServer $dryviqAdminUser $dryviqAdminUserPassword
    $authHeader = get-request-header $accessToken

    Write-host "Retrieving failed items for job " + $jobId
    #Retrieve permission failures where the item exists on the destination
    while ($hasMore)
    {
        $failedItemsMethod = $dryviqServer + "v1/transfers/$jobId/items?fields=last_failure,source.path,source.name,source.id,transfer.source.impersonate_as&destination_exists=1&audit_categories=a4bdd7af71f6490c817155b4d1dabe51&limit=$maxItemsPerRequest&offset=$offset" 
        $response = Invoke-RestMethod -Method Get $failedItemsMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"

        $totalItems += $response.item
        $hasMore = $response.meta.has_more

        if ($hasMore) #make additional item requests as necessary
        {
            $offset += $maxItemsPerRequest
        }

    }

    $itemsToDelete = @()
    #filter out any permission failures that were not delete ItemOperation
    foreach ($item in $totalItems)
    {
        if ($null -ne $item.last_failure.message && $item.last_failure.message -like "*PortalArchitects.Connectors.Transfers.DeleteItemOperation*")
        {
            $itemsToDelete += $item
        }
    }

    Write-host "Identified " $itemsToDelete.Count " items to delete from job for user " $item.transfer.source.impersonate_as.email
    return $itemsToDelete
}

function get-file-owner($item)
{
    $accessToken = get-skysync-access-token $dryviqServer $dryviqAdminUser $dryviqAdminUserPassword
    $authHeader = get-request-header-with-impersonation $accessToken $item.transfer.source.impersonate_as.email

    $getItemMethod = $dryviqServer + "v1/connections/$connectionId/files/$($item.source.id)?fields=owner" 
    $response = Invoke-RestMethod -Method Get $getItemMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"

    return $item | Add-Member -NotePropertyName owner -NotePropertyValue $response.item.owner.email
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Start-Transcript -Path $transscriptPath

$startTime = "{0:G}" -f (Get-date)
Write-Host "*** Script started on $startTime ***" -f Blue -b DarkYellow

$itemsToDelete = @()
try
{
    $failedItems = get-job-failed-to-delete-items $jobId

    #add file owner property to the item
    foreach ($item in $failedItems)
    {
        #$item = get-file-owner $item
        get-file-owner $item
        
        if ($null -ne $item.owner)
        {
            if (![string]::IsNullOrEmpty($restrictDeletionToEmailAddressFormat))
            {
                if(!($item.owner -like $restrictDeletionToEmailAddressFormat))
                {
                    continue
                }
            }
            $itemsToDelete += $item    
        }
    }
}
catch
{
    $exMsg = $_.Exception.Message
    $line = $_.Exception.InvocationInfo.ScriptLineNumber
    $st = $_.ScriptStackTrace
    Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
    Write-Host "Failed to Get failed items to delete for JobID: " $jobId -ForegroundColor Red
    Write-Host "Exception Message: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
    Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
}


foreach ($item in $itemsToDelete)
{   
    try
    {
        Write-Host "Deleting item " + $item.source.name + " from owner's account: " $item.owner " having Platform Item ID: " $item.source.id

        $accessToken = get-skysync-access-token $dryviqServer $dryviqAdminUser $dryviqAdminUserPassword
        $authHeader = get-request-header-with-impersonation $accessToken $item.owner

        ##DELETE FILE
        $itemDeleteMethod = $dryviqServer + "v1/connections/$connectionId/files/$($item.source.id)"
        Write-host "Request: " $itemDeleteMethod
        $response = Invoke-RestMethod -Method Delete $itemDeleteMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"
        Write-host "Successfully Deleted item" + $item.source.name " as " $item.owner
    }
    catch
    {
        $exMsg = $_.Exception.Message
        $line = $_.Exception.InvocationInfo.ScriptLineNumber
        $st = $_.ScriptStackTrace
        Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host "File Owner: " $item.owner " | ID: " $item.source.id -ForegroundColor Red
        Write-Host "An error occurred while deleting item: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
        Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
    }
}
 

<#
.DESCRIPTION
    Deletes Items On Behalf of the File's Owner
.INPUTS
    dryviqServer                            =   SkySync server host and port
    dryviqAdminUser                         =   SkySync admin username
	dryviqAdminUserPassword                 =   SkySync admin user password
    jobsToDeleteCsv			                =   Input list of jobs to process deletions. Column: JobIDGuid
    transscriptPath			                =   Path to write Transcript file
    numberOfThreads			                =   Number of items to delete in parallel
    maxBatchSize                            =   Maximum number of jobs to retrieve failed items for, prior to deleting items
    restrictDeletionToEmailAddressFormat	=   OPTIONAL: #optional. if specified, restricts deletion attempt to only owners matching the specified email address format.
    
    
.OUTPUTS
    CSV file in relative directory
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $dryviqServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'DeleteFileParallel.ps1' $dryviqServer=http://DESKTOP-9BHVIFS:9090/ $connectionId="46a08dd47b674b46bd8108314a1f2f51"
#>

Param(
    [string]$dryviqServer = "http://localhost:9090/",
    [string]$dryviqAdminUser = "admin",
    [string]$dryviqAdminUserPassword = 'P@ssword!',
    $jobsToDeleteCsv = ".\migrationReport.csv", 
    [string]$transscriptPath = ".\DeleteItems_transscript_" + (Get-Date).tostring("yyyyMMdd_hhmmss") + ".txt",
    [int]$numberOfThreads = 25,
    [int]$maxBatchSize = 10,
    [string]$restrictDeletionToEmailAddressFormat = "*skysynch.com" #Optional: if specified, restricts deletion attempt to only owners matching the specified email address format.
)

Get-ChildItem .\ | Unblock-File -Confirm:$false
. .\Invoke-Parallel.ps1

function get-skysync-access-token
{
    param( [string] $dryviqServer)
    $accessRequestUrl = $dryviqServer + "connect/token"

    $accessRequestBody = @{
        grant_type = "password"
        scope      = "offline_access profile roles"
        resource   = $dryviqServer
        username   = $dryviqAdminUser
        password   = $dryviqAdminUserPassword
    }

    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
    return $accessRequestResult.access_token
}

function get-request-header
{
    param( [string]$accessToken )
    $requestHeader = @{
        Authorization = "Bearer " + $accessToken
        Accept        = "application/json"
    }
    return $requestHeader
}

function get-request-header-with-impersonation
{
    param( [string]$accessToken, [string]$username )
    $requestHeader = @{
        Authorization  = "Bearer " + $accessToken
        Accept         = "application/json"
        "X-Connect-As" = $username
    }
    return $requestHeader
}

function get-job-failed-to-delete-items($jobId, $dryviqServer)
{
    $offset = 0
    $totalItems = @()
    $maxItemsPerRequest = 1000
    $hasMore = $true

    $accessToken = get-skysync-access-token $dryviqServer
    $authHeader = get-request-header $accessToken

    Write-Host "Retrieving failed items for job $jobId" 
    #Retrieve permission failures where the item exists on the destination
    while ($hasMore)
    {
        $failedItemsMethod = $dryviqServer + "v1/transfers/$jobId/items?fields=last_failure,source.path,source.name,source.id,transfer.source.impersonate_as,transfer.source.connection.id&destination_exists=1&audit_categories=a4bdd7af71f6490c817155b4d1dabe51&limit=$maxItemsPerRequest&offset=$offset"
        $response = Invoke-RestMethod -Method Get $failedItemsMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"

        $totalItems += $response.item
        $hasMore = $response.meta.has_more

        if ($hasMore) #make additional item requests as necessary
        {
            $offset += $maxItemsPerRequest
        }

    }

    $itemsToDelete = @()
    #filter out any permission failures that were not delete ItemOperation
    foreach ($item in $totalItems)
    {
        if (($null -ne $item.last_failure.message) -and $item.last_failure.message -like "*PortalArchitects.Connectors.Transfers.DeleteItemOperation*")
        {
            $itemsToDelete += $item
        }
    }

    Write-Host "Identified $($itemsToDelete.Count) items to delete from job for user $($item.transfer.source.impersonate_as.email)"
    return $itemsToDelete
}

function get-file-owner($item, $connectionId)
{
    $accessToken = get-skysync-access-token $dryviqServer
    $authHeader = get-request-header-with-impersonation $accessToken $item.transfer.source.impersonate_as.email

    $getItemMethod = $dryviqServer + "v1/connections/$connectionId/files/$($item.source.id)?fields=owner"
    $response = Invoke-RestMethod -Method Get $getItemMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"

    return $item | Add-Member -NotePropertyName owner -NotePropertyValue $response.item.owner.email
}

Function Add-ToDeleteFilesReport
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$dryviqServer,
        [Parameter(Mandatory)]
        [string]$jobId
    )

    Try
    {
        $formattedJobCompletedDate = ([datetime]::Now).Tostring('yyyy-MM-dd HH:mm')
        "" | select-object -Property `
        @{Name = "Host"; Expression = { $dryviqServer } }, `
        @{Name = "FormattedJobCompletedDate"; Expression = { $formattedJobCompletedDate } },
        @{Name = "JobIDGuid"; Expression = { $jobId } } | Export-Csv -path .\deleteFilesReport.csv -Append
    }
    Catch
    {
        Write-Host "An unexpected error occurred: $($_.Exception.Message)"
    }
}

function DeleteItemBatch()
{
    $itemsToDelete  | Invoke-Parallel -ImportVariables -ImportFunctions -Throttle $numberOfThreads -RunspaceTimeout 28800 -ScriptBlock {
        $item = $_

        try
        {
            #retrieve file owner and add to item 
            get-file-owner $item $item.transfer.source.connection.id

            if ($null -eq $item.owner)
            {
                continue
            }

            if (![string]::IsNullOrEmpty($restrictDeletionToEmailAddressFormat))
            {
                if (!($item.owner -like $restrictDeletionToEmailAddressFormat))
                {
                    continue
                }
            }

            Write-Host "Deleting item $($item.source.name) from owner's account: $($item.owner) having Platform Item ID: $($item.source.id)"
            $accessToken = get-skysync-access-token $dryviqServer
            $authHeader = get-request-header-with-impersonation $accessToken $item.owner
    
            ##DELETE FILE
            $itemDeleteMethod = $dryviqServer + "v1/connections/$($item.transfer.source.connection.id)/files/$($item.source.id)"
            Write-Host "Request: $itemDeleteMethod"
            $response = Invoke-RestMethod -Method Delete $itemDeleteMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"
            Write-Host "Successfully Deleted item $($item.source.name) as $item.owner"
        }
        catch
        {
            $exMsg = $_.Exception.Message
            $line = $_.Exception.InvocationInfo.ScriptLineNumber
            $st = $_.ScriptStackTrace
            Write-Host "File Owner:  $($item.owner) | ID: $($item.source.id)"  
            Write-Host "An error occurred while deleting item: ${exMsg}. Line ${line}. ${st}" 
        }
    }
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Start-Transcript -Path $transscriptPath

$jobsFromCsv = Import-Csv -Path $jobsToDeleteCsv
$jobs = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
foreach($job in $jobsFromCsv)
{
    $jobs.add($job)
}

#jobs processed prior to committing a batch. reset once batch is committed.
$jobBatch = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
#items to delete. reset once batch is committed.
$itemsToDelete = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))

for ($i = 0; $i -lt $jobs.Count; $i++) 
{ 
    $job = $jobs[$i]
    $jobBatch += $job

    #retrieve job failed items
    try
    {
        $failedItems = get-job-failed-to-delete-items $job.JobIDGuid $dryviqServer
        $itemsToDelete += $failedItems
    }
    catch
    {
        $exMsg = $_.Exception.Message
        $line = $_.Exception.InvocationInfo.ScriptLineNumber
        $st = $_.ScriptStackTrace
        Write-Host "Failed to Get failed items to delete for JobID: $($job.JobIdGuid)" 
        Write-Host "Exception Message: ${exMsg}. Line ${line}. ${st}" 
    }

    #Commit batch of items once maxBatchSize is reached or final job is processed
    $isLastItem = $i -eq ($jobs.Count - 1);
    if ($jobBatch.Count % $maxBatchSize -eq 0 -or $isLastItem)
    {
        DeleteItemBatch
        #clear jobs and affected items from memory
        $jobBatch = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
        $itemsToDelete = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
    }
        
    Add-ToDeleteFilesReport `
        -dryviqServer $dryviqServer `
        -jobId $job.JobIDGuid `
}


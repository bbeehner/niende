Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
 
#Variables for Site URL and Library Name
$WebURL="https://sharepoint.company.com/sites/sales"
$LibraryName="Library Name"
 
#Get Site and Library
$Web = Get-SPWeb $WebURL
$DocLib = $Web.Lists.TryGetList($LibraryName)
 
#Get all Checked out files
$CheckedOutFiles = $DocLib.Items | Where-Object { $_.File.CheckOutStatus -ne "None"}
 
#Check in All Checked out Files in the library
ForEach($item in $CheckedOutFiles)
{
    #If you want to update fields
    #$item["Field"] = "value"
    #$item.SystemUpdate()
  
    #check in file programmatically    
    #$item.TakeoverCheckout()
    $DocLib.GetItemById($item.Id).file.CheckIn("Checked in by Admin")
    write-host "File:'$($item.Name)' has been checked in!"       
}
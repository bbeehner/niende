#
#
# Script to move items to subfolders to clean up 10k in a folder limitation
#
#

#region Variables

$targetFolder       = "\\jpinto\test$"  # Must be set to "\\{unc_path}" or "{C:\}" path, using a UNC path will map a drive within PowerShell
$targetFolderCount  = 1000              # Set to 9000, you can set this to 9999 but it leaves a small margin for future adds to folder

$reportOnly         = $false           # Must be set to $true to make a report of what will move, this will export to a CSV 
$reportCSV          = ".\FolderingReport.csv" # A report will be created either way, this must have a value

$runFolderEstimate  = $true            # This option will display folder counts projections if you selected DATE or FOLDER
$separateBy         = "LastWriteTime"   # CreationTime, LastAccessTime or LastWriteTime (recommended)

$folderBy           = "NAMED_FOLDERS"   # Valid choices are "DATED_FOLDERS" and "NAMED_FOLDERS"
$folderName         = "FOLDERCLEANING"      # Valid Case Sensitve choices for $folderName are "yyyy", "yyyy-MM", "yyyy-MM-dd", OR the "CUSTOM FOLDER NAME" this custom folder will get _0001, _0002, etc appended to it

#endregion

#region Preferences

Clear-Host
Push-Location $PSScriptRoot
$VerbosePreference      = "SilentlyContinue" # This should be "Continue" to show or "SilentlyContinue" to hide
$ErrorActionPreference  = "Stop" # Needs to be at Stop for function parameter validation 

# map a drive if this is a unc path
if ($targetFolder.StartsWith('\\')){

    Get-PSDrive Z -ErrorAction SilentlyContinue | Remove-PSDrive
    New-PSDrive -Name "Z" -Root $targetFolder -PSProvider "FileSystem" | Out-Null
    if (Get-PSDrive Z){
        $targetFolder = "Z:\"
    } 
    else { 
        Write-Host "Network location could not be mapped. Check path and permissions." -ForegroundColor Red
        Exit
    }
    Push-Location $PSScriptRoot
}

#endregion

#region Functions

function Start-DryvIQTranscript {

    try { Stop-Transcript -ErrorAction SilentlyContinue -WarningAction SilentlyContinue } catch {}
    $ScriptPath = $($MyInvocation.PSScriptRoot)
    New-Item -Path $ScriptPath -Name "logs" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    $logname = "log-$((Split-Path $MyInvocation.PSCommandPath -Leaf).Replace('.ps1','')).$(Get-Date -Format yyyy-MM-dd)"
    Start-Transcript -path "$ScriptPath\logs\$($logname).txt" -append
    Write-Host "`r`n"
    
}

function Stop-DryvIQTranscript {

    Write-Host "`r`n `r`n"
    try { Stop-Transcript -ErrorAction SilentlyContinue -WarningAction SilentlyContinue } catch {}

}

function Set-MoveItemToFoldering {
    [CmdletBinding()]
    Param (
    [ValidateNotNullOrEmpty()][Object]$item,
    [ValidateNotNullOrEmpty()][bool]$reportOnly,
    [ValidateNotNullOrEmpty()][ValidateScript({ if ($_ -match ".csv") { $true } else { Write-Host "File must be a CSV file." -ForegroundColor Red; Exit }})][string]$reportCSV, 
    [ValidateNotNullOrEmpty()][ValidateSet("CreationTime","LastAccessTime","LastWriteTime")][string]$separateBy,
    [ValidateNotNullOrEmpty()][ValidateSet("DATED_FOLDERS","NAMED_FOLDERS")][string]$folderBy,
    [ValidateNotNullOrEmpty()][string]$targetFolder,
    [ValidateNotNullOrEmpty()][string]$folderName
    )  

    Write-Host "Processing `$item.FullName:" $item.FullName
    if ($separateBy -eq "CreationTime"){ Write-Host "`$item.CreationTime:" ($item.CreationTime).ToString("yyyy-MM-dd") }
    if ($separateBy -eq "LastAccessTime"){ Write-Host "`$item.LastAccessTime:" ($item.LastAccessTime).ToString("yyyy-MM-dd") }
    if ($separateBy -eq "LastWriteTime"){ Write-Host "`$item.LastWriteTime" ($item.LastWriteTime).ToString("yyyy-MM-dd") }
    
    if ($folderBy -eq "DATED_FOLDERS" -and ($folderName -ne "yyyy" -and $folderName -ne "yyyy-MM" -and $folderName -ne "yyyy-MM-dd")){
            Write-Host "`$folderBy is set to DATE, however `$folderName is not set to a valid option of `"yyyy`", `"yyyy-MM`" OR `"yyyy-MM-dd`"" -ForegroundColor Red
            Exit
    }

    if ($folderBy -eq "DATED_FOLDERS" -and ($folderName -eq "yyyy" -or $folderName -eq "yyyy-MM" -or $folderName -eq "yyyy-MM-dd")){
        

        $reportYear     = $item.($($separateBy)).ToString("yyyy")
        $reportMonth    = $item.($($separateBy)).ToString("MM")
        $reportDay      = $item.($($separateBy)).ToString("dd")


        $reportValues = New-Object System.Object

        $reportValues | Add-Member -Type NoteProperty -Name Source -Value $item.FullName -Force


        if ($folderName -eq "yyyy"){
            $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$item.FullName" -Force
        }
        if ($folderName -eq "yyyy-MM"){
            $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$reportMonth\$item.FullName" -Force
        }        
        if ($folderName -eq "yyyy-MM-dd"){
            $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$reportMonth\$reportDay\$item.FullName" -Force
        }
        
        $reportValues | Add-Member -Type NoteProperty -Name TimeStamp -Value "$((Get-Date).ToString("MM/dd/yyyy HH:mm:ss"))" -Force
        $reportValues | Add-Member -Type NoteProperty -Name TransferMode -Value "Scanned" -Force
        
        $reportValues | Export-Csv -Path "$reportCSV" -NoTypeInformation -Force -NoClobber -Append

        
        if ($reportOnly -eq $false){
            Write-Host "Moving item:" $Item.FullName
            # New-Item -Path $ScriptPath -Name "logs" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

            $reportValues | Add-Member -Type NoteProperty -Name Source -Value "$item.FullName" -Force
            $reportValues | Add-Member -Type NoteProperty -Name TimeStamp -Value "$((Get-Date).ToString("MM/dd/yyyy HH:mm:ss"))" -Force
            $reportValues | Add-Member -Type NoteProperty -Name TransferMode -Value "Moved" -Force

            if ($folderName -eq "yyyy"){
                $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$item.FullName" -Force
                New-Item -Path "$PSScriptRoot" -Name "$reportYear" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                Move-Item -Path "$item.FullName" -Destination "$PSScriptRoot\$reportYear"
                if ($?){
                    $reportValues | Export-Csv -Path "$reportCSV" -NoTypeInformation -Force -NoClobber -Append
                }
            }
            if ($folderName -eq "yyyy-MM"){
                $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$reportMonth\$item.FullName" -Force
                New-Item -Path "$PSScriptRoot" -Name "$reportYear" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                New-Item -Path "$PSScriptRoot\$reportYear" -Name "$reportMonth" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                Move-Item -Path "$item.FullName" -Destination "$PSScriptRoot\$reportYear"
                if ($?){
                    $reportValues | Export-Csv -Path "$reportCSV" -NoTypeInformation -Force -NoClobber -Append
                }
            }        
            if ($folderName -eq "yyyy-MM-dd"){
                $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$reportYear\$reportMonth\$reportDay\$item.FullName" -Force
                New-Item -Path "$PSScriptRoot" -Name "$reportYear" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                New-Item -Path "$PSScriptRoot\$reportYear"-Name "$reportMonth" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                New-Item -Path "$PSScriptRoot\$reportYear\$reportMonth" -Name "$reportDay" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                Move-Item -Path "$item.FullName" -Destination "$PSScriptRoot\$reportYear\$reportMonth"
                if ($?){
                    $reportValues | Export-Csv -Path "$reportCSV" -NoTypeInformation -Force -NoClobber -Append
                }
            }
        }
    }


    if ($folderBy -eq "NAMED_FOLDERS"){

        if ($reportOnly -eq $false){


            $reportValues = New-Object System.Object
            $reportValues | Add-Member -Type NoteProperty -Name Source -Value $item.FullName -Force
            $reportValues | Add-Member -Type NoteProperty -Name TimeStamp -Value "$((Get-Date).ToString("MM/dd/yyyy HH:mm:ss"))" -Force
            $reportValues | Add-Member -Type NoteProperty -Name TransferMode -Value "Moved" -Force
            $reportValues | Add-Member -Type NoteProperty -Name Destination -Value "\$folderName\$($item.Name)" -Force

            
            Write-Host "Running: Move-Item -Path "$($item.FullName)" -Destination `"$targetFolder\$folderName\$($item.Name)`" -Force"
                                 Move-Item -Path "$($item.FullName)" -Destination "$targetFolder\$folderName\$($item.Name)" -Force

            if ($?){
                $reportValues | Export-Csv -Path "$reportCSV" -NoTypeInformation -Force -NoClobber -Append
            }
        }

    }
   

}
#endregion

Start-DryvIQTranscript

#region Script Logic

$contents       = Get-ChildItem -Path $targetFolder -File

if ($contentsCount -ge $targetFolderCount){
    $contentsCount  = $contents.Count / $targetFolderCount
}
if ($contentsCount -le $targetFolderCount){
    $contentsCount  = ($contents.Count / $targetFolderCount).ToString("#.##")
}
if ($contentsCount -le 1){
    $contentsCount  = 1
}

Write-Host "Total number of files to process: $($contents.Count)"

if ($runFolderEstimate -eq $true){ 

    Write-Host "NAMED_FOLDERS needed:`r`n======================================================================"
    Write-Host "Total number of custom named folders needed at $($targetFolderCount) per folder: $([math]::Ceiling($contentsCount))`r`n"
    
    Write-Host "`r`nDATE_FOLDERING needed:" `"$separateBy`" "(check for anything over $targetFolderCount):`r`n======================================================================"
    Write-Host "Grouping the items by year:"
    $contents  | Group-Object {$_.($($separateBy)).ToString("yyyy")} | Sort-Object Name | Format-Table Name,Count -auto
    Write-Host "Grouping the items by year-month:"
    $contents  | Group-Object {$_.($($separateBy)).ToString("yyyy-MM")} | Sort-Object Name | Format-Table Name,Count -auto
    Write-Host "Grouping the items by year-month-day:"
    $contents  | Group-Object {$_.($($separateBy)).ToString("yyyy-MM-dd")} | Sort-Object Name | Format-Table Name,Count -auto

}

$itemCount      = 0     # The total number of the files in the target folder                                                        214k
$folderJump     = 0     # This will be reset after hitting the $targetFolderCount, this triggers the folder append rename               
$folderingCount = 1     # This is the append count 

ForEach ($item in $contents){

    if ($reportOnly -eq $false){
        if ($folderBy -eq "DATED_FOLDERS"){

            $itemCount++
            Write-Host "`r`nProcessing item number:" $itemCount "of" $contents.count
            Set-MoveItemToFoldering -item $item -reportOnly $reportOnly -reportCSV $reportCSV -separateBy $separateBy -folderBy $folderBy -targetFolder $targetFolder -folderName $folderName
            Write-Host "`r`n"

        }

        if ($folderBy -eq "NAMED_FOLDERS"){

            # Check counts and change -foldername to new generated folder name 
            $itemCount++ 
            $folderJump++

            if ($folderJump-eq $targetFolderCount) {
                $folderJump = 0
                $folderingCount++
                $folderAppend = $folderingCount.ToString('0000')
                $finalFolderName = "$($folderName)_$($folderAppend)"  
                New-Item -Path "$targetFolder" -Name "$finalFolderName" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
                
                # Check for folder exists already, this is for reruns, count folder contents move $folderjump to that number increase folderingCount if over the number already DO UNTIL we find a free folder

            }            

            # TODO check folder count, in case of disconnect. 
            
  
            Write-Host "Processing File for folder:" $finalFolderName
    
            
            Write-Host "`r`nProcessing item number:" $itemCount "of" $contents.count
            Set-MoveItemToFoldering -item $item -reportOnly $reportOnly -reportCSV $reportCSV -separateBy $separateBy -folderBy $folderBy -targetFolder $targetFolder -folderName $finalFolderName
            Write-Host "`r`n"

        }
    }

}

#endregion

#region Post Execution Clean up

Get-PSDrive Z -ErrorAction SilentlyContinue | Remove-PSDrive
Stop-DryvIQTranscript

#endregion




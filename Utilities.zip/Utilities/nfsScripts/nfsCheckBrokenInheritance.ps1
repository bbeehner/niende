Clear-Host
Push-Location $PSSCriptRoot


# Variables
$dirPath 			= "C:\Temp" # Your directory path
$exportFilePath 	= ".\BrokenInheritanceList.txt" # Your export file path
$processFiles 		= $true  # Process files
$processFolders 	= $true # Process folders

# Check if export file already exists. If it does, remove it.
if (Test-Path $exportFilePath) {
    Remove-Item $exportFilePath
}

# Get all items (folders and files) recursively
$items 				= Get-ChildItem $dirPath -Recurse -Force

foreach ($item in $items) {
    # Check if item is a file and if processFiles is set to true
    if ($item.PSIsContainer -eq $false -and $processFiles -eq $true) {
        # Get ACL of file
        $acl = Get-Acl -Path $item.FullName

        # Check if inheritance is broken
        if ($acl.AreAccessRulesProtected -eq $true) {
            # If inheritance is broken, append the item's path to the export file
            $item.FullName | Out-File -Append -FilePath $exportFilePath
        }
    }

    # Check if item is a directory and if processFolders is set to true
    if ($item.PSIsContainer -eq $true -and $processFolders -eq $true) {
        # Get ACL of directory
        $acl = Get-Acl -Path $item.FullName

        # Check if inheritance is broken
        if ($acl.AreAccessRulesProtected -eq $true) {
            # If inheritance is broken, append the item's path to the export file
            $item.FullName | Out-File -Append -FilePath $exportFilePath
        }
    }
}

Write-Host "Completed. Please check the export file at $exportFilePath" -ForegroundColor Cyan


Clear-Host

try {net use Z: /DELETE} catch {} 
NET USE Z: "\\sscloud\share$" /persistent:no

Push-Location Z:\
if ($?){
    $itemsToProcess = Get-ChildItem -Path *.* -Recurse -ErrorAction SilentlyContinue  #| Where-Object {$_.Name -eq 'NAME OF FILE FOR TESTING ONLY 1 FILE.EXT'}
   
    ForEach ($item in $itemsToProcess) {
		Write-Host "Processing ownership change for $($item.fullname)" -ForegroundColor Cyan
        $ACL = Get-ACL $item
		if ($?){
			$Group = New-Object System.Security.Principal.NTAccount("Builtin", "Administrators")
			$ACL.SetOwner($Group)
			Set-Acl -Path $item -AclObject $ACL
		}
    }
}

Push-Location $PSScriptRoot


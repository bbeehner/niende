# Clear the PowerShell console and set the script root location
Clear-Host
Push-Location $PSScriptRoot

# Define the root directory you want to scan
$rootDir = "C:\"

# Define the output CSV file path
$outputFile = ".\NFSItemCountReport.csv"

# Define the minimum item count for folders at depth x
$minItemCountDepth01 = 100000
$minItemCountDepth02 = 50000
$minItemCountDepth03 = 50000
$minItemCountDepth04 = 1000
$minItemCountDepth05 = 1000
$minItemCountDepth06 = 1000
$minItemCountDepth07 = 1000
$minItemCountDepth08 = 1000
$minItemCountDepth09 = 1000
$minItemCountDepth10 = 1000

# Define the folder level to exclude from the report, i.e 3 will exclude level 3 and all levels below that. 
$excludeFolderLevels = 3

# Create an array to hold the results
$results = @()

# Define a function to get the folder depth
function Get-FolderDepth ($path) {
    $depth = ($path -split '\\').Count - 1
    return $depth
}

# Define a function to count the items in a folder
function Get-ItemCount ($path) {
    $items = Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Measure-Object | Select-Object -ExpandProperty Count
    return $items
}

# Loop through all top level folders in the root directory
try {
Get-ChildItem -Path $rootDir -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    
    # Get the item count for the top level folder
    $items = Get-ItemCount $_.FullName
    $depth = Get-FolderDepth $_.FullName
    # Check if the top level folder meets the criteria for export
    if ($items -ge $minItemCountDepth01 -and $depth -eq 1) {

        # Check if the folder level is excluded from the report
        if ($depth -lt $excludeFolderLevels) {

            # Create an object to hold the results and add it to the array
            Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($items))..."
            $result = New-Object -TypeName PSObject -Property @{
                folder_path = $_.FullName
                folder_level = $depth
                item_count = $items
            }
            $results += $result
            
            # If the top level folder is at depth 2, check subfolders for export
            if (Get-FolderDepth $_.FullName -eq 2 -and $items -ge $minItemCountDepth02) {
                Get-ChildItem -Path $_.FullName -Directory -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                    # Get the item count for the subfolder
                    $subItems = Get-ItemCount $_.FullName
                    
                    # Check if the folder level is excluded from the report
                    $depth = Get-FolderDepth $_.FullName 
                    if ($depth -lt $excludeFolderLevels){
                    
                        if ($subItems -ge $minItemCountDepth02 -and $depth -eq 2){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult
                        }
                        
                        if ($subItems -ge $minItemCountDepth03 -and $depth -eq 3){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth04 -and $depth -eq 4){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth05 -and $depth -eq 5){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth06 -and $depth -eq 6){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth07 -and $depth -eq 7){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth08 -and $depth -eq 8){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth09 -and $depth -eq 9){
                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult                        
                        }
                        if ($subItems -ge $minItemCountDepth10 -and $depth -eq 10){

                                # Create an object to hold the results and add it to the array
                                Write-Host "Processing $($_.FullName) (folder_level: $($depth) / count: $($subItems))..."
                                $subResult = New-Object -TypeName PSObject -Property @{
                                    folder_path = $_.FullName
                                    folder_level = $depth
                                    item_count = $subItems
                                }
                                $results += $subResult
                        }
                    }     
                }
            }
        }
    }
}
} catch {
    Write-Host "Error. If you have mapped a drive in the OS it might not be visible through a PowerShell Session running as Administrator."
}

# Export the results to a CSV file
$results | Export-Csv -Path $outputFile -NoTypeInformation -Force

#$results | Select-Object folder_path, folder_level, item_count | Export-Csv -Path $outputFile -NoTypeInformation -Force
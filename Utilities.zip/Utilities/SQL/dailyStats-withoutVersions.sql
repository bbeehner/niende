-- new Daily Stats allows for us to remove the versions from the thruput reporting
-- these numbers should be closer to what the UI reports, although there are 
-- still some slaight differences in the item counts.  The Size looks to be
-- accurate
--
-- Daily

SELECT  CONVERT(VARCHAR,A.RECORDEDON,102)                                                                                                     AS [DATE]
       ,COUNT(A.TRANSFERITEMID)                                                                                                               AS ITEMS
       ,CAST(SUM(A.BYTES)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))                                                                       AS [TOTAL GB]
       ,CAST(SUM(A.BYTES)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4))                                                                AS [TOTAL TB]
       ,CAST(AVG(A.BYTES)/ (1024.0 * 1024.0) AS NUMERIC(10,4))                                                                                AS [AVERAGE MB]
       ,CONVERT(DECIMAL(10,2),(MAX(A.RECORDEDON) - MIN(A.RECORDEDON)))*24*60                                                                  AS [TRANSFER MINUTES]
       ,CAST((SUM(BYTES)/ (1024.0 * 1024.0 * 1024.0)/NULLIF((CONVERT(FLOAT,MAX(A.RECORDEDON) - MIN(A.RECORDEDON)) * 24),0)) AS NUMERIC(10,4)) AS [GB PER HOUR]
       ,GETDATE() LASTRUN
FROM SCHEDULEDJOBS SJ
		INNER JOIN TRANSFERJOBS TJ
		ON TJ.JOBID = SJ.JOBID
		INNER JOIN TRANSFERITEMS TI (NOLOCK)
		ON TI.TRANSFERID = TJ.ID
		INNER JOIN
		(	SELECT  ID
				   ,TRANSFERITEMID
				   ,DATEADD(HOUR,-5,DATEADD(S,RECORDEDON,'1970-01-01'))              AS RECORDEDON
				   ,BYTES
				   ,ROW_NUMBER() OVER (PARTITION BY TRANSFERITEMID ORDER BY ID DESC) AS ROWNUM
			FROM DBO.TRANSFERAUDITLOG (NOLOCK)
			WHERE TYPE IN (3001)
			AND BYTES IS NOT NULL
		) A
		ON A.TRANSFERITEMID = TI.ID
WHERE TJ.USESIMULATIONMODE = 0
		AND SJ.ISACTIVE = 1
		AND (SJ.DELETEPENDING IS NULL OR SJ.DELETEPENDING = 0)
		AND A.ROWNUM = 1
GROUP BY  CONVERT(VARCHAR,RECORDEDON,102)
ORDER BY [DATE] DESC

--
--
--  Hourly
--
--

SELECT  CONVERT(VARCHAR,A.RECORDEDON,102)                                                                                                     AS [DATE]
       ,DATEPART(HOUR, A.RECORDEDON)																										  AS [HOUR] 
       ,COUNT(A.TRANSFERITEMID)                                                                                                               AS ITEMS
       ,CAST(SUM(A.BYTES)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))                                                                       AS [TOTAL GB]
       ,CAST(SUM(A.BYTES)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4))                                                                AS [TOTAL TB]
       ,CAST(AVG(A.BYTES)/ (1024.0 * 1024.0) AS NUMERIC(10,4))                                                                                AS [AVERAGE MB]
       ,GETDATE() LASTRUN
FROM SCHEDULEDJOBS SJ
		INNER JOIN TRANSFERJOBS TJ
		ON TJ.JOBID = SJ.JOBID
		INNER JOIN TRANSFERITEMS TI (NOLOCK)
		ON TI.TRANSFERID = TJ.ID
		INNER JOIN
		(	SELECT  ID
				   ,TRANSFERITEMID
				   ,DATEADD(HOUR,-5,DATEADD(S,RECORDEDON,'1970-01-01'))              AS RECORDEDON
				   ,BYTES
				   ,ROW_NUMBER() OVER (PARTITION BY TRANSFERITEMID ORDER BY ID DESC) AS ROWNUM
			FROM DBO.TRANSFERAUDITLOG (NOLOCK)
			WHERE TYPE IN (3001)
			AND BYTES IS NOT NULL
		) A
		ON A.TRANSFERITEMID = TI.ID
WHERE TJ.USESIMULATIONMODE = 0
		AND SJ.ISACTIVE = 1
		AND (SJ.DELETEPENDING IS NULL OR SJ.DELETEPENDING = 0)
		AND A.ROWNUM = 1
GROUP BY  CONVERT(VARCHAR,RECORDEDON,102), DATEPART(HOUR, A.RECORDEDON)
ORDER BY [DATE] DESC, 2 DESC
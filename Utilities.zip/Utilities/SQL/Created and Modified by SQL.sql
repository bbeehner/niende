select ti.id, ti.SourcePath
, tsmcreator.SourceName as CreatedBy, tsmcreator.SourceDisplayName as CreatedByDisplayName
, tsmmodifier.SourceName as ModifiedBy, tsmmodifier.SourceDisplayName as ModifiedByDisplayName
from transferitems ti
inner join transferpermissions tpcreator on (tpcreator.TransferItemID = ti.ID and tpcreator.AuditTrail = 'created-by')
inner join transferpermissions tpmodifier on (tpmodifier.TransferItemID = ti.ID and tpmodifier.AuditTrail = 'modified-by')
inner join TransferSecurityMaps tsmcreator on tsmcreator.id = tpcreator.SecurityMapID
inner join TransferSecurityMaps tsmmodifier on tsmmodifier.id = tpmodifier.SecurityMapID

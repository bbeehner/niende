DECLARE @sql varchar(4000) =
'
USE [?];

SELECT 
 DB_NAME() AS DatabaseName,
 OBJECT_NAME(i.OBJECT_ID) AS TableName, 
 i.name AS IndexName, 
 ips.fragment_count AS FragCount,
 ips.page_count AS PageCount,
 ips.index_type_desc AS IndexType, 
 ips.avg_fragmentation_in_percent AS AvgFragPer
 FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) ips 
  INNER JOIN sys.indexes i  
   ON ((i.object_id = ips.object_id) AND (i.index_id = ips.index_id))
  WHERE ((ips.avg_fragmentation_in_percent > 20) AND (ips.page_count > 500))
  ORDER BY ips.avg_fragmentation_in_percent DESC;
';

EXEC sp_MSforeachdb @sql;

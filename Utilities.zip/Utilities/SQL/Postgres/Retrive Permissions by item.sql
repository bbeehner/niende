select --t.message  from transferauditlog t 
	distinct TransferItems.ID
	, ScheduledJobs.JobID
	, ScheduledJobs.Name JobName        
	, TransferAuditLog.Message

	, substring(TransferAuditLog.Message,position('[' in TransferAuditLog.Message), (position(']' in TransferAuditLog.Message) - position('[' in TransferAuditLog.Message))) MappedUser

	, TransferItems.SourceID
	, TransferItems.SourceName
--	, TransferItems.SourceCaption
	, TransferItems.SourcePath
--	, TransferItems.ItemStatus

	, case when 
	  TransferItems.SourceType = 'f' 
	  Then 'File' Else 'Directory' 
	  End as SourceType

	, TransferItems.SourceBytes
	, to_timestamp(TransferItems.SourceCreatedOn) as "SourceCreatedOnDate"
	, to_timestamp(TransferItems.SourceModifiedOn) as  "SourceModifiedOnDate"


FROM            
	TransferAuditLog INNER JOIN
	TransferItems ON TransferAuditLog.TransferItemID = TransferItems.ID INNER JOIN
	TransferJobs ON TransferAuditLog.TransferID = TransferJobs.ID INNER JOIN
	ScheduledJobs ON TransferJobs.JobID = ScheduledJobs.JobID

WHERE 
	TransferAuditLog.Message like '%permissions to Account%' 
	and ScheduledJobs.CategoryID in (-1)  and ScheduledJobs.IsActive = 1 --and TransferItems.ItemStatus not in (0,1,2,3,4,5,6)
order by 
	transferitems.SourceName



	-- RETRY
SELECT sj.JobID, sj.name, COUNT(ti.id) NumRetryItems 
FROM TransferItems ti
       INNER JOIN ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 3
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.JobID, sj.name
ORDER BY 2 DESC

--FLAGGED
SELECT sj.name, COUNT(ti.id) NumRetryItems 
FROM TransferItems ti
       INNER JOIN ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 4
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.name
ORDER BY 2 DESC

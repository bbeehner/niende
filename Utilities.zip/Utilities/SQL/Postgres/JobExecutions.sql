select * from JobCategories

--Job Executions per node
SELECT INSTANCE_NAME, count(*) as running_jobs FROM QRTZ_FIRED_TRIGGERS group by INSTANCE_NAME
SELECT sj.Name, sj.ConventionDiscriminator, sj.JobID, sj.ID, qz.INSTANCE_NAME, qz.TRIGGER_NAME, qz.TRIGGER_GROUP FROM QRTZ_FIRED_TRIGGERS qz 
left join ScheduledJobs sj on qz.JOB_NAME = sj.JobID --and sj.CategoryID = 5 order by sj.ID
order by qz.INSTANCE_NAME


--Initial Run By Category
select sj.ID, sj.JobID, sj.Name, sj.ConventionDiscriminator, to_timestamp(je.StartTime) as "StartTime", to_timestamp(je.EndTime) as "EndTime", je.ExecutionTime, 
to_timestamp(je.ExecutionTime), -- -  as "TotalTimeInDaysHoursMinsSecs",
CASE 
	WHEN je.ExecutionStatus = 0 THEN 'Running'
	WHEN je.ExecutionStatus = 1 THEN 'Failing'
	WHEN je.ExecutionStatus = 2 THEN 'Failed' 
	WHEN je.ExecutionStatus = 3 THEN 'Completed' 
	WHEN je.ExecutionStatus = 4 THEN 'Cancelled'
	WHEN je.ExecutionStatus = 5 THEN 'Failed to Start'
	WHEN je.ExecutionStatus = 6 THEN 'Warn' 
	WHEN je.ExecutionStatus = 7 THEN 'No Changes' 
END as ExecutionStatus,
CASE 
	WHEN je.ExecutionPhase = 0 THEN 'Pending'
	WHEN je.ExecutionPhase = 1 THEN 'Initializing'
	WHEN je.ExecutionPhase = 2 THEN 'Determing Changes' 
	WHEN je.ExecutionPhase = 3 THEN 'Executing' 
	WHEN je.ExecutionPhase = 4 THEN 'Finalizing'
	WHEN je.ExecutionPhase = 5 THEN 'Complete'	
END as ExecutionPhase
from JobExecutions je 
	inner join ScheduledJobs sj 
	on	je.JobID = sj.ID
where sj.CategoryID = -1 --17
	and je.PreviousID is NULL 
	--and je.ExecutionStatus = 0
	--and je.EndTime is NULL
--order by je.ExecutionTime desc
order by je.StartTime asc
--order by je.JobID
--order by je.JobID

 --Latest Run By Category
 select sj.ID, sj.JobID, sj.Name, sj.ConventionDiscriminator, REPLACE(tj.SourcePath,'/','') source_email, tj.DestinationAccountEmail destination_email, sj.CancelPending, sj.DeletePending,
 to_timestamp(je.StartTime) as "StartTime", to_timestamp(je.EndTime) as "EndTime", je.ExecutionTime, je.PreviousID,
 --CONVERT(NVARCHAR, je.ExecutionTime/1000/60/60/24) + ':' + CONVERT(VARCHAR, to_timestamp(ms,je.ExecutionTime,0),114) TotalTimeInDaysHoursMinsSecs,
--CONVERT(VARCHAR, to_timestamp(ms,je.ExecutionTime,0),114) TotalTimeInHoursMinsSecs,
CASE 
	WHEN je.ExecutionStatus = 0 THEN 'Running'
	WHEN je.ExecutionStatus = 1 THEN 'Failing'
	WHEN je.ExecutionStatus = 2 THEN 'Failed' 
	WHEN je.ExecutionStatus = 3 THEN 'Completed' 
	WHEN je.ExecutionStatus = 4 THEN 'Cancelled'
	WHEN je.ExecutionStatus = 5 THEN 'Failed to Start'
	WHEN je.ExecutionStatus = 6 THEN 'Warn' 
	WHEN je.ExecutionStatus = 7 THEN 'No Changes' 
END as ExecutionStatus,
CASE 
	WHEN je.ExecutionPhase = 0 THEN 'Pending'
	WHEN je.ExecutionPhase = 1 THEN 'Initializing'
	WHEN je.ExecutionPhase = 2 THEN 'Determing Changes' 
	WHEN je.ExecutionPhase = 3 THEN 'Executing' 
	WHEN je.ExecutionPhase = 4 THEN 'Finalizing'
	WHEN je.ExecutionPhase = 5 THEN 'Complete'	
END as ExecutionPhase
from JobExecutions je 
	inner join ScheduledJobs sj 
	on	je.JobID = sj.ID
	inner join TransferJobs tj
		on tj.ID = sj.ID
where sj.CategoryID = 17 --and sj.Name not like '%PAUSED%' 
	and je.ID in (select max(j.ID) from JobExecutions j where j.JobID = sj.ID)
	--and je.ExecutionStatus in (2)
	--and CancelPending is not null
	--and je.PreviousID is null
	--and sj.ID = 13146	
order by je.JobId
--order by je.StartTime
--order by destination_email


select sj.* 
from ScheduledJobs sj inner join QRTZ_TRIGGERS qt on sj.JobID = qt.JOB_NAME
where qt.TRIGGER_STATE = 'PAUSED'

select * from QRTZ_SIMPLE_TRIGGERS

--Last Recorded On
select to_timestamp(RecordedOn) as "LastRecordedOn", i.SourcePath, a.Message, a.* 
from TransferAuditLog a inner join TransferItems  i on a.TransferItemID = i.ID and i.TransferID = a.TransferID
--where a.TransferID = 8962
where a.TransferID in (select ID from ScheduledJobs where CategoryID = -1)
and Type = 3001 
order by RecordedOn desc

--Pending Destination Batches
select SUM(DestinationBatchesPending) PendingBatches, SUM(DestinationFilesPending) PendingFiles, SUM(DestinationVersionsPending) PendingVersions
from JobExecutions where JobID in (select ID from ScheduledJobs where CategoryID = 5) and (DestinationBatchesPending > 0)

select * from JobExecutions where JobID in (8000) and (DestinationBatchesPending > 0)


--Rate Limits
select * from JobExecutions where JobID in (select ID from ScheduledJobs where JobID = 'a9b72e20032541fdb7a0ce5c804d2e7b') and (SourceRateLimits > 0 or DestinationRateLimits > 0)
select * from JobExecutions where JobID in (select ID from ScheduledJobs where CategoryID = 11) and (SourceRateLimits > 0 or DestinationRateLimits > 0)


select * from QRTZ_FIRED_TRIGGERS where JOB_NAME = '3fb3e8428de44d31bcf5603844385b84'
select * from QRTZ_TRIGGERS where JOB_NAME = '3fb3e8428de44d31bcf5603844385b84'

--Running Job Details
select
	sj.ID,
	sj.JobID,
	sj.Name,
	to_timestamp(je.StartTime) as "StartTime",
	to_timestamp(je.EndTime) as "EndTime",
	qt.JOB_NAME
from
	JobExecutions je
inner join ScheduledJobs sj 
		on
	je.JobID = sj.ID
left join QRTZ_FIRED_TRIGGERS qt
		on
	sj.JobID = qt.JOB_NAME
where
	sj.CategoryID = -1
	--and je.PreviousID is NULL
	--and je.EndTime is NULL
	--and je.DestinationBatchesPending > 0
	and je.ExecutionStatus = 0
	--and qt.JOB_NAME is NULL
	--order by je.StartTime
order by
	je.JobID

select je.JobId, sj.Name, count(1) 
from JobExecutions je inner join ScheduledJobs sj on je.JobID = sj.ID
where sj.CategoryID = -1
group by je.JobId, sj.Name order by count(1) desc


--Job Executions by JobID
select sj.ID, sj.JobID, sj.Name,
	to_timestamp(je.StartTime) as "StartTime",
	to_timestamp(je.EndTime) as "EndTime", je.*
from JobExecutions je 
	inner join ScheduledJobs sj 
		on	je.JobID = sj.ID	
where --sj.CategoryID = 5 and 
sj.ID = 13146
order by je.ID desc
--order by je.JobID



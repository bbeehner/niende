SELECT TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') as Date,
		/*TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') AS HOURPROCESSED,*/
       COUNT(a.TransferItemID) AS Items,
       COUNT(DISTINCT(a.ExecutionID)) as JobRuns,
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS "Total GB",
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS "Total TB"
FROM TransferAuditLog AS a 
       INNER JOIN TransferItems as ti
              ON a.TransferItemID = ti.ID
       INNER JOIN ScheduledJobs as sj
              ON ti.TransferID = sj.ID AND ti.DestinationType = 'f' 
              INNER JOIN TransferJobs as tj on tj.id = sj.id
              WHERE tj.usesimulationmode = 0  -- AND sj.CategoryID = '2' 
GROUP BY TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') /*,
		 TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') */
ORDER BY Date DESC /*, 2 DESC */


/* with 3001 and 3002 and cat ID  */

SELECT TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') as Date,
		/*TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') AS HOURPROCESSED,*/
       COUNT(a.TransferItemID) AS Items,
       COUNT(DISTINCT(a.ExecutionID)) as JobRuns,
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS "Total GB",
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS "Total TB"
FROM TransferAuditLog AS a 
       INNER JOIN TransferItems as ti
              ON a.TransferItemID = ti.ID
       INNER JOIN ScheduledJobs as sj
              ON ti.TransferID = sj.ID AND ti.DestinationType = 'f'
              INNER JOIN TransferJobs as tj on tj.id = sj.id
			  WHERE a.type in (3001,3002) -- AND sj.CategoryID = '2' 
                       AND tj.usesimulationmode = 0
GROUP BY TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') /*,
		 TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') */
ORDER BY Date DESC /*, 2 DESC */

/* For Auto Scale Environment by Job  */

SELECT TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') as Date,
		/*TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') AS HOURPROCESSED,*/
       COUNT(a.TransferItemID) AS Items,
       COUNT(DISTINCT(a.ExecutionID)) as JobRuns,
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS "Total GB",
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS "Total TB"
FROM TransferAuditLog AS a 
       INNER JOIN TransferItems as ti
              ON a.TransferItemID = ti.ID
       INNER JOIN ScheduledJobs as sj
              ON ti.TransferID = sj.ID AND ti.DestinationType = 'f'
			  WHERE a.type in (3001,3002) and sj.JObID = '76b0039cc8b24c529307a9cff53f246a'
GROUP BY TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') /*,
		 TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') */
ORDER BY Date DESC /*, 2 DESC */
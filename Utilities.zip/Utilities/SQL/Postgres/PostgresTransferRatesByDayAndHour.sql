SELECT TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY') as Date,
		TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24') AS HOURPROCESSED,
       COUNT(a.TransferItemID) AS Items,
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS "Total GB",
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS "Total TB"
FROM TransferAuditLog AS a 
       INNER JOIN TransferItems as ti
              ON a.TransferItemID = ti.ID
       INNER JOIN ScheduledJobs as sj
              ON ti.TransferID = sj.ID AND ti.DestinationType = 'f' 
              INNER JOIN TransferJobs as tj on tj.id = sj.id
              WHERE tj.usesimulationmode = 0 -- AND sj.CategoryID = '2' 
GROUP BY TO_CHAR(TO_TIMESTAMP(a.recordedon), 'mm/dd/YYYY'), 
		 TO_CHAR(TO_TIMESTAMP(a.recordedon), 'HH24')
ORDER BY Date DESC, 2 DESC
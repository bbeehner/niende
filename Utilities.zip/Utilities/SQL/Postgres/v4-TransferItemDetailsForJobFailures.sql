--TransferItems Details for specific Job Failures for Most Recent Execution
--JobCategory can be specified to identify files across Pilot/Waves or TransferID can be specified to identify failure items for a specific job while undergoing remediation efforts

DROP TABLE IF EXISTS JobFailuresTemp;


SELECT jc.Name as Category, al.TransferID, j.Name,tj.SourceAccountEmail, MAX(al.executionid) LastExecutionID, al.Type, al.Message
into table JobFailuresTemp
	FROM TransferAuditLog al
		INNER JOIN (SELECT jobid, MAX(id) LatestExecutionID FROM JobExecutions GROUP BY jobid) e
			ON al.ExecutionID = e.LatestExecutionID
		--INNER JOIN SkySyncV4.dbo.JobExecutions  e
		--	ON al.ExecutionID = e.ID
		INNER JOIN ScheduledJobs j
			ON al.TransferID = j.ID
		INNER JOIN JobCategories jc
			ON j.CategoryID = jc.ID
		INNER JOIN TransferJobs tj
			ON j.id = tj.id		
	WHERE type BETWEEN 5000 AND 5999
	AND j.CategoryID = 5 --Wave 2
	--AND message LIKE 'The item could not be located within%' --Optional
	--AND message NOT LIKE 'A file or folder%' --Optional
	--AND al.TransferID = 580 --Filter by specific Job ID
	GROUP BY jc.Name, al.TransferID, j.Name,tj.SourceAccountEmail, al.Type, al.Message
	ORDER BY j.Name, TransferID, LastExecutionID

--All Failures sorted by TransferID	
SELECT * FROM JobFailuresTemp order by Name, TransferID, LastExecutionID;

--All failures sorted by Failure Message
SELECT * FROM JobFailuresTemp order by Message;

--Retrieve All Transfer Items discovered through Job Failures to verify their current state i.e. in Retry, Remediation, Pending OR Success, Processed, Skipped etc. to assist with manual remediation
SELECT DISTINCT
sj.CategoryID,
sj.Name,
ti.TransferID,
ti.SourceName,
ti.SourcePath,
ti.SourceType,
ti.SourceBytes,
ti.SourceETag,
ti.DestinationPath,
ti.DestinationType,
ti.DestinationBytes,
ti.DestinationVersion,
ti.DestinationExists,
ti.IsSourceToDestination,
CASE WHEN ItemStatus = 0 THEN 'None'
WHEN ItemStatus = 1 THEN 'Success'
WHEN ItemStatus = 2 THEN 'Processed' 
WHEN ItemStatus = 3 THEN 'Retry' 
WHEN ItemStatus = 4 THEN 'Remediation'
WHEN ItemStatus = 5 THEN 'Skipped'
WHEN ItemStatus = 6 THEN 'Pending' 
END as ItemStatus
FROM TransferItems ti 
INNER JOIN ScheduledJobs sj 
	ON ti.TransferID = sj.ID
INNER JOIN TransferAuditLog tal 
	ON ti.ID = tal.TransferItemID
INNER JOIN JobFailuresTemp
ON tal.TransferID = JobFailuresTemp.TransferID AND  tal.ExecutionID = JobFailuresTemp.LastExecutionID and tal.Message = JobFailuresTemp.Message
ORDER BY sj.CategoryID, ti.TransferID




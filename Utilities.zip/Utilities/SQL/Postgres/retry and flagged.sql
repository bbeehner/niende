
	-- RETRY
SELECT sj.JobID, sj.name, COUNT(ti.id) NumRetryItems 
FROM TransferItems ti
       INNER JOIN ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 3
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.JobID, sj.name
ORDER BY 2 DESC

--FLAGGED
SELECT sj.name, COUNT(ti.id) NumRetryItems 
FROM TransferItems ti
       INNER JOIN ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 4
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.name
ORDER BY 2 DESC
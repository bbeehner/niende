-- Items on destination, missing from source
select 
		sj.name JobName , tj.SourceAccountEmail , tj.DestinationAccountUserName   --    , ti.ParentID   --   , ti.TransferID  --    , ti.IsTransferRoot
      , ti.IsContainer, ti.SourceID  , ti.SourceName  , ti.SourcePath  , ti.SourceType  , ti.SourceBytes  , ti.SourceVersion  , ti.SourceHash
      , ti.SourceCreatedOn  , ti.SourceModifiedOn  , ti.SourceLockedOn  , ti.SourceLockedByID  , ti.SourceLockedByName  , ti.SourceLockedByEmail  , ti.SourceExists  , ti.DestinationID
      , ti.DestinationName  , ti.DestinationCaption  , ti.DestinationPath  , ti.DestinationType  , ti.DestinationBytes  , ti.DestinationVersion  , ti.DestinationCreatedOn
      , ti.DestinationModifiedOn  , ti.DestinationLockedOn  , ti.DestinationLockedByID  , ti.DestinationLockedByName  , ti.DestinationLockedByEmail , ti.DestinationExists , ti.IsSourceToDestination
      , ti.CategoryID , ti.RetriedCount , ti.RetriedExecutionID , ti.ItemStatus , ti.ProcessingStatus , ti.TransferredOn, ti.LastUpdatedOn , ti.Extension, ti.PathDepth, ti.ContentCategoryID
      , ti.SourceVersions , ti.SourceStorage , ti.DestinationVersions , ti.DestinationStorage

from TransferItems ti
inner join transferjobs tj on ti.TransferID = tj.id
inner join scheduledjobs sj on sj.jobid = tj.jobid
--where sj.CategoryID = 22 and isTransferRoot = 0
where tj.JobID = 'f746a4af95314d87bf2940bea9414090' and IsTransferRoot = 0
and SourceID is null and DestinationID is not null and ItemStatus<>5 --ItemStatus <>5  
order by sj.Name, destinationpath


-- Items on source, missing from destination

select 
		sj.name JobName , tj.SourceAccountEmail , tj.DestinationAccountUserName    --   , ti.ParentID      , ti.TransferID  --    , ti.IsTransferRoot
      , ti.IsContainer, ti.SourceID  , ti.SourceName  , ti.SourcePath  , ti.SourceType  , ti.SourceBytes  , ti.SourceVersion  , ti.SourceHash
      , ti.SourceCreatedOn  , ti.SourceModifiedOn  , ti.SourceLockedOn  , ti.SourceLockedByID  , ti.SourceLockedByName  , ti.SourceLockedByEmail  , ti.SourceExists  , ti.DestinationID
      , ti.DestinationName  , ti.DestinationCaption  , ti.DestinationPath  , ti.DestinationType  , ti.DestinationBytes  , ti.DestinationVersion  , ti.DestinationCreatedOn
      , ti.DestinationModifiedOn  , ti.DestinationLockedOn  , ti.DestinationLockedByID  , ti.DestinationLockedByName  , ti.DestinationLockedByEmail , ti.DestinationExists , ti.IsSourceToDestination
      , ti.CategoryID , ti.RetriedCount , ti.RetriedExecutionID , ti.ItemStatus , ti.ProcessingStatus , ti.TransferredOn, ti.LastUpdatedOn , ti.Extension, ti.PathDepth, ti.ContentCategoryID
      , ti.SourceVersions , ti.SourceStorage , ti.DestinationVersions , ti.DestinationStorage

from TransferItems ti
inner join transferjobs tj on ti.TransferID = tj.id
inner join scheduledjobs sj on sj.jobid = tj.jobid
--where sj.CategoryID = -1
Where tj.JobID = 'f746a4af95314d87bf2940bea9414090' --'6518574acc974a3e81921cd92c31f45b'--'12b32881eff94f0c9ed2bb3252fb68f0'
and DestinationID is null and SourceID is not null and itemstatus <> 5 and isTransferRoot = 0
order by sj.Name, destinationpath

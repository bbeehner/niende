select sj.ID, sj.JobID, sj.Name,
to_timestamp(je.StartTime) as "Start time", 
to_timestamp(je.EndTime) as "End Time", 
je.*
from JobExecutions je 
	inner join ScheduledJobs sj 
		on	je.JobID = sj.ID	
--where 
--sj.ID = 5795
order by je.ID desc

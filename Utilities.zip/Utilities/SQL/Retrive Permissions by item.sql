SELECT
	distinct TransferItems.ID
	, ScheduledJobs.JobID
	, ScheduledJobs.Name JobName        
	, TransferAuditLog.Message

	, substring(TransferAuditLog.Message,CHARINDEX('[',TransferAuditLog.Message,1) + 1 , (CHARINDEX(']',TransferAuditLog.Message,1) - CHARINDEX('[',TransferAuditLog.Message,1))-1) MappedUser

	, TransferItems.SourceID
	, TransferItems.SourceName
--	, TransferItems.SourceCaption
	, TransferItems.SourcePath
--	, TransferItems.ItemStatus

	, case when 
	  TransferItems.SourceType = 'f' 
	  Then 'File' Else 'Directory' 
	  End as SourceType

	, TransferItems.SourceBytes
	, DateAdd(SECOND,TransferItems.SourceCreatedOn,'1970-01-01') SourceCreatedOnDate
	, DateAdd(SECOND,TransferItems.SourceModifiedOn,'1970-01-01') SourceModifiedOnDate


FROM            
	TransferAuditLog INNER JOIN
	TransferItems ON TransferAuditLog.TransferItemID = TransferItems.ID INNER JOIN
	TransferJobs ON TransferAuditLog.TransferID = TransferJobs.ID INNER JOIN
	ScheduledJobs ON TransferJobs.JobID = ScheduledJobs.JobID

WHERE 
	TransferAuditLog.Message like '%permissions to Account%' 
	and ScheduledJobs.CategoryID in (12)  and ScheduledJobs.IsActive = 1 --and TransferItems.ItemStatus not in (0,1,2,3,4,5,6)
order by 
	transferitems.SourceName



	-- RETRY
SELECT sj.JobID, sj.name, COUNT(ti.id) NumRetryItems 
FROM SkySyncV4.dbo.TransferItems ti
       INNER JOIN SkySyncV4.dbo.ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 3
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.JobID, sj.name
ORDER BY 2 DESC

--FLAGGED
SELECT sj.name, COUNT(ti.id) NumRetryItems 
FROM SkySyncV4.dbo.TransferItems ti
       INNER JOIN SkySyncV4.dbo.ScheduledJobs sj
       ON sj.id = ti.TransferID
WHERE ItemStatus = 4
AND sj.CategoryID IN (5, 8, 9, 10)
GROUP BY sj.name
ORDER BY 2 DESC

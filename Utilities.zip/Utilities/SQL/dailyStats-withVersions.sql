----------------------------------------------------------------------------------
--Get daily status
-----------------------------------------------------------------------------------
SELECT CONVERT(VARCHAR, RecordedOn, 102) AS [Date], COUNT(TransferItemID) AS Items,  
       COUNT(DISTINCT(ExecutionID)) as JobRuns,
       CAST(SUM(bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS [Total GB],
       CAST(SUM(bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS [Total TB],
       CAST(AVG(bytes)/ (1024.0 * 1024.0) AS NUMERIC(10,4)) AS [Average MB],
       CONVERT(DECIMAL(10,2),(MAX(RecordedOn) - MIN(RecordedOn)))*24*60 as [Transfer Minutes],
       CAST((SUM(bytes)/ (1024.0 * 1024.0 * 1024.0)/NullIf((CONVERT(FLOAT, MAX(RecordedOn) - MIN(RecordedOn)) * 24),0)) AS NUMERIC(10,4)) AS [GB Per Hour],
       GETDATE() LastRun
FROM (SELECT TransferItemID, ExecutionID, DATEADD(HOUR, -5, DATEADD(S, RecordedOn, '1970-01-01')) /*DATEADD(S, RecordedOn, '1970-01-01')*/ AS RecordedOn, bytes 
              from dbo.TransferAuditLog (nolock) 
              WHERE type in (3001,3002)) a
       INNER JOIN dbo.TransferItems ti 
              ON ti.ID = a.TransferItemID 
       INNER JOIN dbo.ScheduledJobs sj 
              ON ti.TransferID = sj.ID /*AND ti.DestinationType = 'f'*/ --AND sj.CategoryID = 5
       INNER JOIN dbo.TransferJobs tj
		ON tj.JobID = sj.JobID AND tj.UseSimulationMode = 0
GROUP BY CONVERT(VARCHAR, RecordedOn, 102)
ORDER BY [Date] DESC

----------------------------------------------------------------------------------
--Get hourly status
-----------------------------------------------------------------------------------
SELECT CONVERT(VARCHAR, a.RecordedOn, 102) AS [Date], DATEPART(HOUR, a.RecordedOn) HourProcessed,
       COUNT(DISTINCT(ExecutionID)) as JobRuns, 
       COUNT(a.TransferItemID) AS Items,  
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4)) AS [Total GB],
       CAST(SUM(a.bytes)/ (1024.0 * 1024.0 * 1024.0 * 1024) AS NUMERIC(10,4)) AS [Total TB],
       CAST(AVG(a.bytes)/ (1024.0 * 1024.0) AS NUMERIC(10,4)) AS [Average MB]
FROM (SELECT TransferItemID, ExecutionID, DATEADD(HOUR, -5, DATEADD(S, RecordedOn, '1970-01-01')) AS /*DATEADD(S, RecordedOn, '1970-01-01')*/ RecordedOn, bytes 
              from dbo.TransferAuditLog (nolock) 
              WHERE type in (3001,3002)) a
       INNER JOIN dbo.TransferItems ti 
              ON ti.ID = a.TransferItemID 
       INNER JOIN dbo.ScheduledJobs sj 
              ON ti.TransferID = sj.ID AND ti.DestinationType = 'f' --AND sj.Name LIKE ('Pilot 100%')
GROUP BY CONVERT(VARCHAR, RecordedOn, 102), DATEPART(HOUR, a.RecordedOn)
ORDER BY [Date] DESC, 2 DESC

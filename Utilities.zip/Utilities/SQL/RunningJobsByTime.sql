DECLARE @UTC_OFFSET INTEGER

SET @UTC_OFFSET = - 5 --EDT  -- -5 for EST  

SELECT q.TRIGGER_GROUP
	,sj.JobID
	,CASE 
		WHEN (sj.ConventionDiscriminator IS NOT NULL)
			THEN sj.Name + ' ---> /' + sj.ConventionDiscriminator
		ELSE sj.name
		END AS JobName
	, tj.SourceAccountEmail
	,CASE 
		WHEN (tj.DestinationAccountUserName IS NOT NULL)
			THEN tj.DestinationAccountUserName
		ELSE 'SPO Destination'
		END AS DestinationAccountUserName

	,sj.NumberOfExecutions
	,sj.CategoryID
	,c.name Cat_Name
	--,q.INSTANCE_NAME  -- the can be meaningless now with the new look
	,nl.node_address  -- use this if you are populating the "Node_Lookup" table - which is manually added
	,DATEADD(hour, @UTC_OFFSET, CAST((q.FIRED_TIME - 599266080000000000) / 10000000 / 24 / 60 / 60 AS DATETIME)) FiredTime
	,DATEDIFF(MINUTE, DATEADD(MINUTE, 0, CAST((q.FIRED_TIME - 599266080000000000) / 10000000 / 24 / 60 / 60 AS DATETIME)), Getdate()) AS RunTimeMin
	--,q.STATE  -- This is mainly "Executing" - so I removed it.
	, je.NewDestinationFiles as NewDestinationFiles
    , je.FoldersToDestination as NewDestinationFolders
	, je.NewDestinationBytes as NewDestinationBytes
	, je.SourceRateLimits as SourceRateLimits
	, je.DestinationRateLimits as DestinationRateLimits
	, je.DestinationRateLimits as DestinationRateLimits
	, je.DestinationBatchesPending as DestinationBatchesPending

FROM QRTZ_FIRED_TRIGGERS Q
inner JOIN ScheduledJobs SJ ON sj.JobID = Q.JOB_NAME
inner join TransferJobs tj on sj.id = tj.ID
inner join JobExecutions je on je.ID = sj.CurrentExecutionID
inner JOIN JobCategories c ON c.ID = sj.CategoryID
LEFT JOIN node_lookup nl ON q.INSTANCE_NAME = nl.name  -- use this if you are populating the "Node_Lookup" table - which is manually added
ORDER BY RunTimeMin -- Node_Address --RunTimeMin 
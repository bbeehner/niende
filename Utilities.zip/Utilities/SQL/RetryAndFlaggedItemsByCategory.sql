WITH TransferFailureMessage_CTE (ID, Type, Message, RecordedOn)
            AS
            (
            SELECT i.ID, a.Type, a.Message, a.RecordedOn
            FROM TransferItems i with(nolock) 
	            JOIN TransferAuditLog a with(nolock)  ON i.ID = a.TransferItemID
				-- --3 = Flagged, 4 = Retry for itemStatus
            WHERE i.ItemStatus IN(3,4)
	            AND a.ID = (SELECT Max(l.ID)
				            FROM TransferAuditLog l
				            WHERE l.TransferItemID = i.ID
					            AND l.Type >= 5000)
            )

            SELECT 
	            job.Name AS JobName,
	            transfer.JobID,
	            job_category.Name as JobCategory,
	            transfer.ID as TransferID,
	            SourceConnection.Name AS SourceConnectionName,
	            DestinationConnection.Name as DestinationConnectionName,
	            content_category.Name AS ContentCategoryName,
	            audit_category.Name AS CategoryName,
                audit_category.Description AS CategoryDescription,
                TransferItems.ID,
	            TransferItems.SourceName,
	            TransferItems.SourcePath,
	            TransferItems.SourceType,
	            TransferItems.SourceBytes,
	            TransferItems.SourceETag,
	            TransferItems.DestinationPath,
	            TransferItems.DestinationType,
	            TransferItems.DestinationBytes,
	            TransferItems.DestinationVersion,
	            TransferItems.DestinationExists,
	            TransferItems.IsSourceToDestination,
				-- TransferItems.ItemStatus,
				 CASE   
					WHEN TransferItems.ItemStatus = 3 THEN 'Flagged'
				   WHEN TransferItems.ItemStatus = 4 THEN 'Retry'  
				 END as ItemStatus,
	            tfm.Message,
				DATEADD(S, tfm.RecordedOn, '1970-01-01') RecordedOn
            FROM TransferItems with(nolock) 
            LEFT JOIN TransferAuditCategories audit_category with(nolock) ON (TransferItems.CategoryID=audit_category.ID) 
            LEFT JOIN ContentCategories content_category with(nolock) ON (TransferItems.ContentCategoryID=content_category.ID) 
            LEFT JOIN ScheduledJobs job with(nolock) ON (TransferItems.TransferID=job.ID)
            LEFT JOIN TransferJobs transfer with(nolock) ON (TransferItems.TransferID=transfer.ID)
            LEFT JOIN JobCategories job_category with(nolock) ON job_category.ID = job.CategoryID
            LEFT JOIN Connections DestinationConnection with(nolock) ON (transfer.DestinationConnectionID=DestinationConnection.ID)
            LEFT JOIN Connections SourceConnection with(nolock) ON (transfer.SourceConnectionID=SourceConnection.ID)
            LEFT JOIN TransferFailureMessage_CTE tfm on tfm.ID = TransferItems.ID
			WHERE   --3 = Flagged, 4 = Retry for itemStatus
	                (TransferItems.ItemStatus in (3,4)) AND job_category.ID in (8)
					and 
					job.CancelPending is null and job.DeletePending is null
                   ORDER BY
	                job.Name, tfm.RecordedOn ASC



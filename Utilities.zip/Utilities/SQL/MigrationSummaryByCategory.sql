BEGIN
	--DECLARE @jobSearch nvarchar(255) = 'Wave-6';
	DECLARE @jobCategoryID bigint = 6;

	SET NOCOUNT ON;

	--if (charindex('%',@jobSearch) = 0)
	--begin
	--	set @jobSearch = '%' + @jobSearch + '%'
	--end

	/******	Item State Enumeration		  *******
			0 = none,
			1 = Transferred/Success, 
			2 = Transferred/Revised (Processed), 
			3 = Retry, 
			4 = Flagged, 
			5 = Ignored/Skipped, 
			6 = pending
	*********************************************/
	
	declare @tempTable table(
	[ID] bigint NOT NULL,
	[JobId] [nvarchar](40) NOT NULL,
	[JobName] [nvarchar](2000) NOT NULL,
	[SourceTotalCount] [int] NULL,
	[SourceTotalBytes] bigint NULL,
	[TotalMigItemsPCT] [decimal](5, 2) NULL,
	[TotalMigSizePCT] [decimal](5, 2) NULL,
	[SuccessTotalCount] [int] NULL,
	[SuccessTotalBytes] bigint NULL,
	[SuccessRevTotalCount] [int] NULL,
	[SuccessRevTotalBytes] bigint NULL,
	[IgnoredTotalCount] [int] NULL,
	[IgnoredTotalBytes] bigint NULL,
	[PendingTotalCount] [int] NULL,
	[PendingTotalBytes] bigint NULL,
	[RetryTotalCount] [int] NULL,
	[RetryTotalBytes] bigint NULL,
	[FlaggedTotalCount] [int] NULL,
	[FlaggedTotalBytes] bigint NULL,
	[NoneTotalCount] [int] NULL,
	[NoneTotalBytes] bigint NULL
)

insert into @tempTable
select a.ID, a.JobId, a.JobName, a.TotalIdentified as SourceTotalCount, a.SourceTotalBytes, 0, 0
	   ,b1.TotalIdentified as SuccessTotalCount, b1.DestBytes as SuccessTotalBytes
	   ,b2.TotalIdentified as SuccessRevTotalCount, b2.DestBytes as SuccessRevTotalBytes
	   ,c.TotalIdentified as IgnoredTotalCount, c.SourceTotalBytes as IgnoredTotalBytes
	   ,d.TotalIdentified as PendingTotalCount, d.SourceTotalBytes as PendingTotalBytes
	   ,e.TotalIdentified as RetryTotalCount, e.SourceTotalBytes as RetryTotalBytes
	   ,f.TotalIdentified as FlaggedTotalCount, f.SourceTotalBytes as FlaggedTotalBytes
	   ,g.TotalIdentified as NoneTotalCount, g.SourceTotalBytes as NoneTotalBytes
from
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
		, sum(DestinationBytes) as DestBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID)
)
group by sj.ID, tj.JobId, sj.Name
) a left outer join

-- Join in items that were migrated successfully - NO REVISION NEEDED)
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(DestinationBytes) as DestBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 1)
)
group by sj.ID, tj.JobId, sj.Name
) b1 on b1.ID = a.ID left outer join

-- Join in items that were migrated successfully - AFTER REVISION
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(DestinationBytes) as DestBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 2)
)
group by sj.ID, tj.JobId, sj.Name
) b2 on b2.ID = a.ID left outer join

-- Join in Items that are in Skipped/Ignored State
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 5)
)
group by sj.ID, tj.JobId, sj.Name
) c on c.ID = a.ID left outer join

-- Join in Items that are in Pending State
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 6)
)
group by sj.ID, tj.JobId, sj.Name
) d on d.ID = a.ID left outer join

-- Join in Items that are in Retry State
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 3)
)
group by sj.ID, tj.JobId, sj.Name
) e on e.ID = a.ID left outer join

-- Join in Items that are in Flagged State
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 4)
)
group by sj.ID, tj.JobId, sj.Name
) f on f.ID = a.ID left outer join

-- Join in Items that are in "None" State
(
SELECT sj.ID, tj.JobId, sj.Name as JobName, count(TransferId) as TotalIdentified
		, sum(SourceBytes) as SourceTotalBytes
FROM dbo.TransferItems ti with (nolock)
INNER JOIN dbo.TransferJobs tj with (nolock) ON (ti.TransferId = tj.ID)
INNER JOIN dbo.ScheduledJobs sj with (nolock)	ON (tj.ID = sj.ID)
WHERE 
(
	(sj.CategoryID = @jobCategoryID) AND
	(ti.ItemStatus = 0)
)
group by sj.ID, tj.JobId, sj.Name
) g on g.ID = a.ID

order by a.ID

update @tempTable set SourceTotalCount = 0 where SourceTotalCount is null
update @tempTable set [SourceTotalBytes] = 0 where [SourceTotalBytes] is null
update @tempTable set [SuccessTotalCount] = 0 where [SuccessTotalCount] is null
update @tempTable set [SuccessTotalBytes] = 0 where [SuccessTotalBytes] is null
update @tempTable set [SuccessRevTotalCount] = 0 where [SuccessRevTotalCount] is null
update @tempTable set [SuccessRevTotalBytes] = 0 where [SuccessRevTotalBytes] is null
update @tempTable set [IgnoredTotalCount] = 0 where [IgnoredTotalCount] is null
update @tempTable set [IgnoredTotalBytes] = 0 where [IgnoredTotalBytes] is null
update @tempTable set [PendingTotalCount] = 0 where [PendingTotalCount] is null
update @tempTable set [PendingTotalBytes] = 0 where [PendingTotalBytes] is null
update @tempTable set [RetryTotalCount] = 0 where [RetryTotalCount] is null
update @tempTable set [RetryTotalBytes] = 0 where [RetryTotalBytes] is null
update @tempTable set [FlaggedTotalCount] = 0 where [FlaggedTotalCount] is null
update @tempTable set [FlaggedTotalBytes] = 0 where [FlaggedTotalBytes] is null
update @tempTable set [NoneTotalCount] = 0 where [NoneTotalCount] is null
update @tempTable set [NoneTotalBytes] = 0 where [NoneTotalBytes] is null
--update @tempTable set [TotalMigItemsPCT] = 100*((SuccessTotalCount+SuccessRevTotalCount+IgnoredTotalCount)/(SourceTotalCount*1.0))
--update @tempTable set [TotalMigSizePCT] = 100*(((SuccessTotalBytes+SuccessRevTotalBytes+IgnoredTotalBytes)*1.0)/SourceTotalBytes*1.0) where SourceTotalBytes > 0
--update @tempTable set [TotalMigSizePCT] = 100 where SourceTotalBytes = 0 and (SuccessTotalBytes+IgnoredTotalBytes) = 0
--update @tempTable set [TotalMigSizePCT] = 100 where [TotalMigSizePCT] > 100


select ID, JobId, JobName --, TotalMigItemsPCT, TotalMigSizePCT
		, SourceTotalCount, SuccessTotalCount, SuccessRevTotalCount, IgnoredTotalCount, PendingTotalCount, RetryTotalCount, FlaggedTotalCount, NoneTotalCount
		, convert(decimal(10,3),(SourceTotalBytes/1024.0/1024.0/1024.0)) as SourceTotalGB
		, convert(decimal(10,3),(SuccessTotalBytes/1024.0/1024.0/1024.0)) as SuccessTotalGB
		, convert(decimal(10,3),(SuccessRevTotalBytes/1024.0/1024.0/1024.0)) as SuccessRevTotalGB
		, convert(decimal(10,3),(IgnoredTotalBytes/1024.0/1024.0/1024.0)) as IgnoredTotalGB
		, convert(decimal(10,3),(PendingTotalBytes/1024.0/1024.0/1024.0)) as PendingTotalGB
		, convert(decimal(10,3),(RetryTotalBytes/1024.0/1024.0/1024.0)) as RetryTotalGB
		, convert(decimal(10,3),(FlaggedTotalBytes/1024.0/1024.0/1024.0)) as FlaggedTotalGB
		, convert(decimal(10,3),(NoneTotalBytes/1024.0/1024.0/1024.0)) as NoneTotalGB
from @tempTable
--order by JobName
order by ID
    
END

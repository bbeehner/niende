select sj.ID, sj.JobID, sj.Name,
DATEADD(HOUR, -4, DATEADD(S, je.StartTime, '1970-01-01')) StartTime, 
DATEADD(HOUR, -4, DATEADD(S, je.EndTime, '1970-01-01')) EndTime, je.*
from JobExecutions je 
	inner join ScheduledJobs sj 
		on	je.JobID = sj.ID	
where 
sj.ID = 5795 -- need to get this based on job id cross reference, this is the shedueled jobs id, not the job id
order by je.ID desc

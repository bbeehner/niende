 <#
.DESCRIPTION
    Updates Folder Permissions
.INPUTS
    skysyncServer               =   SkySync server host and port
    skysyncAdminUser            =   SkySync admin username
	skysyncAdminUserPassword    =   SkySync admin user password
    connectionId				=	Connection ID where items reside
    transscriptPath				=	Path to write Transcript file
    inputFilePath				=	Input CSV of permissions
    
.OUTPUTS
    CSV file in relative directory
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'UpdateFolderPermissions.ps1' $skysyncServer=http://DESKTOP-9BHVIFS:9090/ $connectionId="46a08dd47b674b46bd8108314a1f2f51"
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
    [string]$skysyncAdminUser = "admin",
    [string]$skysyncAdminUserPassword = 'Skyme1100!',
    [string]$connectionId = "46a08dd47b674b46bd8108314a1f2f51",
    [string]$transscriptPath = ".\UpdateFolderPermissions_transscript_" + (Get-Date).tostring("yyyyMMdd_hhmmss") + ".txt",
    [string]$inputFilePath = ".\folder-list.csv"
)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function GetRequestBody($folder) {

    $requestBodyTemplate = '[
        {
            "access": "allow",
            "rights": "{accessLevel}",
            "sid": {
                "username": "{username}",
                "type": "account"
            }
        }
    ]'

    $requestBody = $requestBodyTemplate -replace "{accessLevel}", $folder.rights
    $requestBody = $requestBody -replace "{username}", $folder.account_username

    return $requestBody
}

Start-Transcript -Path $transscriptPath

$startTime = "{0:G}" -f (Get-date)
Write-Host "*** Script started on $startTime ***" -f Blue -b DarkYellow

$foldersToUpdate = Import-Csv -Path $inputFilePath
Write-Host "Identified" $foldersToUpdate.count "folders to update."

foreach($folder in $foldersToUpdate)
{   
    try {
        Write-Host "Updating Permissions for user: " $folder.account_username " Path: " $folder.folder_path
        #get skysync access token
        $accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
        $authHeader = get-request-header $accessToken

        $requestBody = GetRequestBody $folder
        Write-host $requestBody

        $folderPermissionUpdateMethod = $skysyncServer + "v1/connections/$connectionId/folders/permissions?path=" + $folder.folder_path
        $response = Invoke-RestMethod -Method Put $folderPermissionUpdateMethod -Headers $authHeader -Body $requestBody -ContentType "application/json" # -Proxy 'http://localhost:8888'  
    }
    catch{
        $exMsg = $_.Exception.Message
        $line = $_.Exception.InvocationInfo.ScriptLineNumber
        $st = $_.ScriptStackTrace
        Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host "User:" $folder.account_username "| Path:" $folder.folder_path -ForegroundColor Red
        Write-Host "An error occurred while updating folder permissions: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
        Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
    }
}
 

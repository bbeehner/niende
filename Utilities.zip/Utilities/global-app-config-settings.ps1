cd 'C:\Program Files\SkySync'

#------------------------------------------------------------------------
# GLOBAL APPLICATION SETTINGS
#------------------------------------------------------------------------
# set concurrent jobs
.\skysync.exe config set performance:concurrent_transfers 16 --in-database #default 6

#set parallel writes
.\skysync.exe config set performance:parallel_writes:requested 10 --in-database #default 

#audit log level (application logging)
.\skysync.exe config set logging:level 'info' --in-database # default info

#logs to keep in file system (note relationship to log publish job)
.\skysync.exe config set logging:retention_days 365 --in-database # default 21

#------------------------------------------------------------------------
# GLOBAL JOB SETTINGS
#------------------------------------------------------------------------
#set job audit level (audit log in database)
.\skysync.exe config set audit_level 'trace'  --in-database # default info (none, trace, debug, info, warn, error)

#set job rentention days (audit log in database)
.\skysync.exe config set jobs:retention:duration:count 365 --in-database
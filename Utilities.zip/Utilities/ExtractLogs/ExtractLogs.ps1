Clear-Host
Push-Location $PSScriptRoot

# Define the source and destination directories
$sourceDir = "C:\ProgramData\SkySync\V4\logs\"
$destDir = Resolve-Path ".\ExtractedLogs" # Change to your desired directory

# Specify the JOBID
$jobId = "ba763a88aa6345329ef644efc77c94d0" # Change to the desired JOB ID


# Function to extract files from zip
function Extract-LogFiles {
    param (
        [string]$zipPath,
        [string]$fileName,
        [string]$newFileName
    )
    $tempFolder = [System.IO.Path]::GetTempPath() + [System.IO.Path]::GetRandomFileName()
    Write-Host "Extracting $fileName from $zipPath to $tempFolder"
    Expand-Archive -Path $zipPath -DestinationPath $tempFolder
    $logFile = Get-ChildItem -Path $tempFolder -Recurse | Where-Object { $_.Name -eq $fileName }

    if ($null -eq $logFile) {
        Write-Host "File $fileName not found in $zipPath"
    }
    else {
        Move-Item -Path $logFile.FullName -Destination $destDir -Force
        Rename-Item -Path (Join-Path -Path $destDir -ChildPath $fileName) -NewName $newFileName
    }

    Remove-Item -Path $tempFolder -Recurse
}

# Create the destination directory if it doesn't exist
if (!(Test-Path -Path $destDir)) {
    New-Item -Path $destDir -ItemType Directory
}

# Loop through folders and extract logs
Get-ChildItem -Path $sourceDir | ForEach-Object {
    $itemPath = $_.FullName
    $logFileName = "Log" + $jobId + ".txt"

    if ($_ -is [System.IO.DirectoryInfo]) {
        $newFileName = [System.Environment]::MachineName + "." + $_.Name + ".Job" + $jobId + ".txt"
        $logFilePath = Join-Path -Path $itemPath -ChildPath $logFileName

        if (Test-Path -Path $logFilePath) {
            Write-Host "Copying $logFilePath to $destDir"
            Copy-Item -Path $logFilePath -Destination (Join-Path -Path $destDir -ChildPath $newFileName)
        }
    }
    elseif ($_.Name -match "\d{8}\.zip") {
		$newFileName = [System.Environment]::MachineName + "." + ($_.Name -replace "\.zip", "") + ".Job" + $jobId + ".txt"
		Extract-LogFiles -zipPath $itemPath -fileName $logFileName -newFileName $newFileName
    }
}

Write-Host "Log extraction completed."

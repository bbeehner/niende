Clear-Host
Push-Location $PSScriptRoot

#region Check Folder Exists
if (-Not (Test-Path "C:\ProgramData\SkySync\v4\Logs")) {
    Write-Host "Folder does not exist!"
    return
}
#endregion

#region Share Folder
$shareName = "logs$"
$folderPath = "C:\ProgramData\SkySync\v4\Logs"
$description = "Logs Share"

$Acl = New-Object System.Security.AccessControl.DirectorySecurity
$permission = "Everyone","Read","Allow"
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission
$Acl.SetAccessRule($accessRule)
Set-Acl $folderPath $Acl

$share = New-SmbShare -Name $shareName -Path $folderPath -Description $description -FullAccess "Administrators" -ReadAccess "Everyone"

if ($null -eq $share) {
    Write-Host "Failed to create share!"
    return
}
Write-Host "Share created successfully."
#endregion

#region Set NTFS Permissions
$Acl = Get-Acl -Path $folderPath
$permission = "Everyone","Read","Allow"
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $permission
$Acl.AddAccessRule($accessRule)
Set-Acl -Path $folderPath -AclObject $Acl

Write-Host "NTFS permissions set successfully."
#endregion

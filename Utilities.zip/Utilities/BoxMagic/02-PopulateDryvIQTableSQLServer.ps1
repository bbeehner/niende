Clear-Host
Push-Location $PSScriptRoot
$VerbosePreference = "Silently Continue" # Set to "Continue" to show all verbose messages and "Silently Continue" to not show verbose messages

#region variables

#$boxReportPath                  = "C:\Users\Administrator\Desktop\Wheaton Box Reports\20221020-Wheaton-Box(Full-Folder-and-File-Tree-Sample)"
$boxReportPath                  = "C:\Users\Administrator\Desktop\Box Reports\WHEATON BOX REPORTS\20221020-Wheaton-Box(Full-Folder-and-File-Tree)\"

$tableNameforDryvIQReport       = "box_data_dryviq"

$sqlDatabase                    = "box_data_w"
$sqlServer                      = "localhost"
$sqlUser                        = "sa"
$sqlPass                        = "Skyme1100!"


#endregion 


#region PowerShell settings

Clear-Host
Push-Location $PSScriptRoot

$checkPolicy = Get-ExecutionPolicy
if ($checkPolicy -eq "Restricted")
{
    Write-Host "`r`n Error: PowerShell Execution Policy is set to `"Restricted`", Please run PowerShell as an Administrator, then run `"Set-ExecutionPolicy Unrestricted`"" -ForegroundColor Red
	[System.Console]::Read()
	exit		
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue

if ((Get-Module -ListAvailable -Name SQLPS) -or (Get-Module -ListAvailable -Name SqlServer)) {} else {
    Write-Host "Installing Module SqlServer" -ForegroundColor Cyan
    Install-Module SqlServer -Force -ErrorAction SilentlyContinue
}

#endregion



#region functions
# function Get-FileExtension {
#     param (
#         [Parameter(Mandatory = $true)]
#         [string]$FileName
#     )

#     # Check for a rename with multiple extensions
#     if ($FileName -match '^(.*)\.[a-z]{3,4}\.[a-z]{3,4}$') {
#         return ($FileName -replace '^(.*)\.(.+?)\.([a-z]{3,4})$', '$2.$3').ToLower()
#     }

#     # Check for a standard extension
#     if ($FileName -match '^(.*)\.([a-z]{3,4})$') {
#         return $Matches[2].ToLower()
#     }

#     # No extension found
#     return $null
# }

function Get-FileExtension {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FileName
    )

    if ($FileName -match '\.([A-Za-z0-9]{2,5})$') {
        return $Matches[1].ToLower()
    }
    else {
        return $null
    }
}

#endregion




#region ScriptLogic



# Import the CSV file

$csvDepot = Get-ChildItem "$boxReportPath\*.csv"

foreach ($csv in $csvDepot){

    Write-Host "Importing CSV: $($csv.Name)" -ForegroundColor Cyan
    $csvData = Import-Csv -LiteralPath $csv.FullName 

    # Specify the batch size
    $batchSize = 1

    # Specify the starting row number
    $counter = 0

    # Build the query string
    Write-Host "Building the SQL Query for: $($csv.Name)" -ForegroundColor Cyan
    $queryString = "INSERT INTO [$tableNameforDryvIQReport] ("
    $queryString += "Owner_Name, Owner_Login, Path, Path_ID, Item_Name, Item_ID, Item_Type, File_Extension, Size, Size_GB_This_Level, Size_GB_This_Level_Recursive, Size_Bytes, Size_KB, Size_MB, Size_GB, Created, Last_Modified, Uploaded, Data_Retention_Policy, Path_ID_Level_01, Path_ID_Level_02, Path_ID_Level_03, Path_ID_Level_04, Path_ID_Level_05, Path_ID_Level_06, Path_ID_Level_07, Path_ID_Level_08, Path_ID_Level_09, Path_ID_Level_10, Path_ID_Level_11, Path_ID_Level_12, Path_ID_Level_13, Path_ID_Level_14, Path_ID_Level_15, Path_ID_Level_16, Path_ID_Level_17, Path_ID_Level_18, Path_ID_Level_19, Path_ID_Level_20, Path_ID_Level_21, Path_ID_Level_22, Path_ID_Level_23, Path_ID_Level_24, Path_ID_Level_25, Path_ID_Level_26, Path_ID_Level_27, Path_ID_Level_28, Path_ID_Level_29, Path_ID_Level_30, Path_ID_Level_31, Path_ID_Level_32, Path_ID_Level_33, Path_ID_Level_34, Path_ID_Level_35, Path_ID_Level_36, Path_ID_Level_37, Path_ID_Level_38, Path_ID_Level_39, Path_ID_Level_40, Path_ID_Level_41, Path_ID_Level_42, Path_ID_Level_43, Path_ID_Level_44, Path_ID_Level_45, Path_ID_Level_46, Path_ID_Level_47, Path_ID_Level_48, Path_ID_Level_49, Path_ID_Level_50, Path_ID_Level_51, Path_ID_Level_52, Path_ID_Level_53, Path_ID_Level_54, Path_ID_Level_55, Path_ID_Level_56, Path_ID_Level_57, Path_ID_Level_58, Path_ID_Level_59, Path_ID_Level_60, Path_ID_Level_61, Path_ID_Level_62, Path_ID_Level_63, Path_ID_Level_64, Path_ID_Level_65, Path_ID_Level_66, Path_ID_Level_67, Path_ID_Level_68, Path_ID_Level_69, Path_ID_Level_70, Path_ID_Level_71, Path_ID_Level_72, Path_ID_Level_73, Path_ID_Level_74, Path_ID_Level_75, Path_ID_Level_76, Path_ID_Level_77, Path_ID_Level_78, Path_ID_Level_79, Path_ID_Level_80, Path_ID_Level_81, Path_ID_Level_82, Path_ID_Level_83, Path_ID_Level_84, Path_ID_Level_85, Path_ID_Level_86, Path_ID_Level_87, Path_ID_Level_88, Path_ID_Level_89, Path_ID_Level_90, Path_ID_Level_91, Path_ID_Level_92, Path_ID_Level_93, Path_ID_Level_94, Path_ID_Level_95, Path_ID_Level_96, Path_ID_Level_97, Path_ID_Level_98, Path_ID_Level_99, Item_Count_This_Level_Folders, Item_Count_This_Level_Files, Item_Count_This_Level, Item_Count_Recursive, is_BoxNote, Char_Count_Path, Char_Count_ItemName, Folder_Level)"
    $queryString += "VALUES "

    # Loop through the CSV data in batches of $batchSize
    while ($counter -lt $csvData.Count) {
    # Get the current batch of data
    $batch = $csvData[$counter..($counter + $batchSize - 1)]
  
    # Increment the counter by the batch size
    $counter += $batchSize
  
    # Loop through the current batch of data
    foreach ($batchRow in $batch) {

    #region Insert Properties

    $rv_Owner_Name_Edit                   = $batchRow.Owner_Name.Replace("'","''")
    $rv_Owner_Name                        = if ($batchRow.Owner_Name){ "'$($rv_Owner_Name_Edit)'" } else { "NULL" }

    $rv_Owner_Login                       = if ($batchRow.Owner_Login){ "'$($batchRow.Owner_Login)'" } else { "NULL" }

    $rv_Path_Edit                         = $batchRow.Path.Replace("'","''")
    $rv_Path_Edit                         = $rv_Path_Edit.Replace('$','`$')
    $rv_Path                              = if ($batchRow.Path){ "'$rv_Path_Edit'" } else { "NULL" }

    $rv_Path_ID                           = if ($batchRow.Path_ID){ "'$($batchRow.Path_ID)'" } else { "NULL" }

    if ($rv_Path_ID -eq "'0/'"){
        $rv_Path_ID = "'0/$($batchRow.Owner_Login.ToUpper())'"
    }

    $rv_Item_Name_Edit                    = $batchRow.Item_Name.Replace("'","''")
    $rv_Item_Name_Edit                    = $rv_Item_Name_Edit.Replace('$','`$')
    $rv_Item_Name                         = if ($batchRow.Item_Name){ "'$($rv_Item_Name_Edit)'" } else { "NULL" }

    $rv_File_Extension                    = "NULL"

    if ($batchRow.Item_Type -eq 'File'){
         $rv_File_Extension =  "'$(Get-FileExtension $batchRow.Item_Name)'" 
    }

    $rv_Item_ID                           = if ($batchRow.Item_ID){ "'$($batchRow.Item_ID)'" } else { "NULL" }
    $rv_Item_Type                         = if ($batchRow.Item_Type){ "'$($batchRow.Item_Type)'" } else { "NULL" }

    $rv_Size_This_level                   = "NULL"
    $rv_Size_This_Level_Recursive         = "NULL"

    $rv_Size                              = if ($batchRow.Size){ "'$($batchRow.Size)'" } else { "NULL" }
    $rv_Size_Bytes                        = "NULL"
    $rv_Size_KB                           = "NULL"
    $rv_Size_MB                           = "NULL"
    $rv_Size_GB                           = "NULL"

    if ($batchRow.Size -match 'B' -and $batchRow.Size -notmatch 'KB' -and $batchRow.Size -notmatch 'MB' -and $batchRow.Size -notmatch 'GB' -and $batchRow.Size -notmatch 'TB'){
        $rv_Size_Stripped                     = $batchRow.Size.Replace('B','')

        $rv_Size_KB                            = [double]$rv_Size_Stripped / 1024
        $rv_Size_KB                           = "{0:F4}" -f $rv_Size_KB
        
        $rv_Size_MB                           = [double]$rv_Size_Stripped / 1024 / 1024
        $rv_Size_MB                           = "{0:F4}" -f $rv_Size_MB

        $rv_Size_GB                           = [double]$rv_Size_Stripped / 1024 / 1024 / 1024
        $rv_Size_GB                           = "{0:F4}" -f $rv_Size_GB

        $rv_Size_Bytes                        = "{0:F4}" -f [double]$rv_Size_Stripped   
    }

    if ($batchRow.Size -match 'KB'){
        $rv_Size_Stripped                     = $batchRow.Size.Replace('KB','')
    
        $rv_Size_KB                           = "{0:F4}" -f [double]$rv_Size_Stripped
        
        $rv_Size_MB                           = [double]$rv_Size_Stripped / 1024
        $rv_Size_MB                           = "{0:F4}" -f $rv_Size_MB

        $rv_Size_GB                           = [double]$rv_Size_Stripped / 1024 / 1024
        $rv_Size_GB                           = "{0:F4}" -f $rv_Size_GB

        $rv_Size_Bytes                        = [double]$rv_Size_Stripped * 1024

    }

    if ($batchRow.Size -match 'MB'){
        $rv_Size_Stripped                     = $batchRow.Size.Replace('MB','')

        $rv_Size_KB                           = [double]$rv_Size_Stripped * 1024 
        $rv_Size_KB                           = "{0:F4}" -f $rv_Size_KB

        $rv_Size_MB                           = "{0:F4}" -f [double]$rv_Size_Stripped

        $rv_Size_GB                           = [double]$rv_Size_Stripped / 1024
        $rv_Size_GB                           = "{0:F4}" -f $rv_Size_GB

        $rv_Size_Bytes                        = [double]$rv_Size_Stripped * 1024 * 1024
    }

    if ($batchRow.Size -match 'GB'){
        $rv_Size_Stripped                     = $batchRow.Size.Replace('GB','')

        $rv_Size_KB                           = [double]$rv_Size_Stripped * 1024 * 1024
        $rv_Size_KB                           = "{0:F4}" -f $rv_Size_KB

        $rv_Size_MB                           = [double]$rv_Size_Stripped * 1024
        $rv_Size_MB                           = "{0:F4}" -f $rv_Size_MB

        $rv_Size_GB                           = "{0:F4}" -f [double]$rv_Size_Stripped

        $rv_Size_Bytes                        = [double]$rv_Size_Stripped * 1024 * 1024 * 1024
    }

    $rv_Created                           = if ($batchRow.Created){ "'$($batchRow.Created)'" } else { "NULL" }
    $rv_Last_Modified                     = if ($batchRow.Last_Modified){ "'$($batchRow.Last_Modified)'" } else { "NULL" }
    $rv_Uploaded                          = if ($batchRow.Uploaded){ "'$($batchRow.Uploaded)'" } else { "NULL" }
    $rv_Data_Retention_Policy             = if ($batchRow.Data_Retention_Policy){ $batchRow.Data_Retention_Policy } else { "NULL" }

    $path_id_split                        = $batchRow.path_id.Split("/")

    $rv_Path_ID_Level_01                  = if ($path_id_split[1]){ $path_id_split[1] } else { "NULL" } 
    $rv_Path_ID_Level_02                  = if ($path_id_split[2]){ $path_id_split[2] } else { "NULL" }
    $rv_Path_ID_Level_03                  = if ($path_id_split[3]){ $path_id_split[3] } else { "NULL" }
    $rv_Path_ID_Level_04                  = if ($path_id_split[4]){ $path_id_split[4] } else { "NULL" }
    $rv_Path_ID_Level_05                  = if ($path_id_split[5]){ $path_id_split[5] } else { "NULL" }
    $rv_Path_ID_Level_06                  = if ($path_id_split[6]){ $path_id_split[6] } else { "NULL" }
    $rv_Path_ID_Level_07                  = if ($path_id_split[7]){ $path_id_split[7] } else { "NULL" }
    $rv_Path_ID_Level_08                  = if ($path_id_split[8]){ $path_id_split[8] } else { "NULL" }
    $rv_Path_ID_Level_09                  = if ($path_id_split[9]){ $path_id_split[9] } else { "NULL" }
    $rv_Path_ID_Level_10                  = if ($path_id_split[10]){ $path_id_split[10] } else { "NULL" }
    $rv_Path_ID_Level_11                  = if ($path_id_split[11]){ $path_id_split[11] } else { "NULL" }
    $rv_Path_ID_Level_12                  = if ($path_id_split[12]){ $path_id_split[12] } else { "NULL" }
    $rv_Path_ID_Level_13                  = if ($path_id_split[13]){ $path_id_split[13] } else { "NULL" }
    $rv_Path_ID_Level_14                  = if ($path_id_split[14]){ $path_id_split[14] } else { "NULL" }
    $rv_Path_ID_Level_15                  = if ($path_id_split[15]){ $path_id_split[15] } else { "NULL" }
    $rv_Path_ID_Level_16                  = if ($path_id_split[16]){ $path_id_split[16] } else { "NULL" }
    $rv_Path_ID_Level_17                  = if ($path_id_split[17]){ $path_id_split[17] } else { "NULL" }
    $rv_Path_ID_Level_18                  = if ($path_id_split[18]){ $path_id_split[18] } else { "NULL" }
    $rv_Path_ID_Level_19                  = if ($path_id_split[19]){ $path_id_split[19] } else { "NULL" }
    $rv_Path_ID_Level_20                  = if ($path_id_split[20]){ $path_id_split[20] } else { "NULL" }
    $rv_Path_ID_Level_21                  = if ($path_id_split[21]){ $path_id_split[21] } else { "NULL" }
    $rv_Path_ID_Level_22                  = if ($path_id_split[22]){ $path_id_split[22] } else { "NULL" }
    $rv_Path_ID_Level_23                  = if ($path_id_split[23]){ $path_id_split[23] } else { "NULL" }
    $rv_Path_ID_Level_24                  = if ($path_id_split[24]){ $path_id_split[23] } else { "NULL" }
    $rv_Path_ID_Level_25                  = if ($path_id_split[25]){ $path_id_split[25] } else { "NULL" }
    $rv_Path_ID_Level_26                  = if ($path_id_split[26]){ $path_id_split[26] } else { "NULL" }
    $rv_Path_ID_Level_27                  = if ($path_id_split[27]){ $path_id_split[27] } else { "NULL" }
    $rv_Path_ID_Level_28                  = if ($path_id_split[28]){ $path_id_split[28] } else { "NULL" }
    $rv_Path_ID_Level_29                  = if ($path_id_split[29]){ $path_id_split[29] } else { "NULL" }
    $rv_Path_ID_Level_30                  = if ($path_id_split[30]){ $path_id_split[30] } else { "NULL" }
    $rv_Path_ID_Level_31                  = if ($path_id_split[31]){ $path_id_split[31] } else { "NULL" }
    $rv_Path_ID_Level_32                  = if ($path_id_split[32]){ $path_id_split[32] } else { "NULL" }
    $rv_Path_ID_Level_33                  = if ($path_id_split[33]){ $path_id_split[33] } else { "NULL" }
    $rv_Path_ID_Level_34                  = if ($path_id_split[34]){ $path_id_split[34] } else { "NULL" }
    $rv_Path_ID_Level_35                  = if ($path_id_split[35]){ $path_id_split[35] } else { "NULL" }
    $rv_Path_ID_Level_36                  = if ($path_id_split[36]){ $path_id_split[36] } else { "NULL" }
    $rv_Path_ID_Level_37                  = if ($path_id_split[37]){ $path_id_split[37] } else { "NULL" }
    $rv_Path_ID_Level_38                  = if ($path_id_split[38]){ $path_id_split[38] } else { "NULL" }
    $rv_Path_ID_Level_39                  = if ($path_id_split[39]){ $path_id_split[39] } else { "NULL" }
    $rv_Path_ID_Level_40                  = if ($path_id_split[40]){ $path_id_split[40] } else { "NULL" }
    $rv_Path_ID_Level_41                  = if ($path_id_split[41]){ $path_id_split[41] } else { "NULL" }
    $rv_Path_ID_Level_42                  = if ($path_id_split[42]){ $path_id_split[42] } else { "NULL" }
    $rv_Path_ID_Level_43                  = if ($path_id_split[43]){ $path_id_split[43] } else { "NULL" }
    $rv_Path_ID_Level_44                  = if ($path_id_split[44]){ $path_id_split[44] } else { "NULL" }
    $rv_Path_ID_Level_45                  = if ($path_id_split[45]){ $path_id_split[45] } else { "NULL" }
    $rv_Path_ID_Level_46                  = if ($path_id_split[46]){ $path_id_split[46] } else { "NULL" }
    $rv_Path_ID_Level_47                  = if ($path_id_split[47]){ $path_id_split[47] } else { "NULL" }
    $rv_Path_ID_Level_48                  = if ($path_id_split[48]){ $path_id_split[48] } else { "NULL" }
    $rv_Path_ID_Level_49                  = if ($path_id_split[49]){ $path_id_split[48] } else { "NULL" }
    $rv_Path_ID_Level_50                  = if ($path_id_split[50]){ $path_id_split[50] } else { "NULL" }
    $rv_Path_ID_Level_51                  = if ($path_id_split[51]){ $path_id_split[51] } else { "NULL" }
    $rv_Path_ID_Level_52                  = if ($path_id_split[52]){ $path_id_split[52] } else { "NULL" }
    $rv_Path_ID_Level_53                  = if ($path_id_split[53]){ $path_id_split[53] } else { "NULL" }
    $rv_Path_ID_Level_54                  = if ($path_id_split[54]){ $path_id_split[54] } else { "NULL" }
    $rv_Path_ID_Level_55                  = if ($path_id_split[55]){ $path_id_split[55] } else { "NULL" }
    $rv_Path_ID_Level_56                  = if ($path_id_split[56]){ $path_id_split[56] } else { "NULL" }
    $rv_Path_ID_Level_57                  = if ($path_id_split[57]){ $path_id_split[57] } else { "NULL" }
    $rv_Path_ID_Level_58                  = if ($path_id_split[58]){ $path_id_split[58] } else { "NULL" }
    $rv_Path_ID_Level_59                  = if ($path_id_split[59]){ $path_id_split[59] } else { "NULL" }
    $rv_Path_ID_Level_60                  = if ($path_id_split[60]){ $path_id_split[60] } else { "NULL" }
    $rv_Path_ID_Level_61                  = if ($path_id_split[61]){ $path_id_split[61] } else { "NULL" }
    $rv_Path_ID_Level_62                  = if ($path_id_split[62]){ $path_id_split[62] } else { "NULL" }
    $rv_Path_ID_Level_63                  = if ($path_id_split[63]){ $path_id_split[63] } else { "NULL" }
    $rv_Path_ID_Level_64                  = if ($path_id_split[64]){ $path_id_split[64] } else { "NULL" }
    $rv_Path_ID_Level_65                  = if ($path_id_split[65]){ $path_id_split[65] } else { "NULL" }
    $rv_Path_ID_Level_66                  = if ($path_id_split[66]){ $path_id_split[66] } else { "NULL" }
    $rv_Path_ID_Level_67                  = if ($path_id_split[67]){ $path_id_split[67] } else { "NULL" }
    $rv_Path_ID_Level_68                  = if ($path_id_split[68]){ $path_id_split[68] } else { "NULL" }
    $rv_Path_ID_Level_69                  = if ($path_id_split[69]){ $path_id_split[69] } else { "NULL" }
    $rv_Path_ID_Level_70                  = if ($path_id_split[70]){ $path_id_split[70] } else { "NULL" }
    $rv_Path_ID_Level_71                  = if ($path_id_split[71]){ $path_id_split[71] } else { "NULL" }
    $rv_Path_ID_Level_72                  = if ($path_id_split[72]){ $path_id_split[72] } else { "NULL" }
    $rv_Path_ID_Level_73                  = if ($path_id_split[73]){ $path_id_split[73] } else { "NULL" }
    $rv_Path_ID_Level_74                  = if ($path_id_split[74]){ $path_id_split[74] } else { "NULL" }
    $rv_Path_ID_Level_75                  = if ($path_id_split[75]){ $path_id_split[75] } else { "NULL" }
    $rv_Path_ID_Level_76                  = if ($path_id_split[76]){ $path_id_split[76] } else { "NULL" }
    $rv_Path_ID_Level_77                  = if ($path_id_split[77]){ $path_id_split[77] } else { "NULL" }
    $rv_Path_ID_Level_78                  = if ($path_id_split[78]){ $path_id_split[78] } else { "NULL" }
    $rv_Path_ID_Level_79                  = if ($path_id_split[79]){ $path_id_split[79] } else { "NULL" }
    $rv_Path_ID_Level_80                  = if ($path_id_split[80]){ $path_id_split[80] } else { "NULL" }
    $rv_Path_ID_Level_81                  = if ($path_id_split[81]){ $path_id_split[81] } else { "NULL" }
    $rv_Path_ID_Level_82                  = if ($path_id_split[82]){ $path_id_split[82] } else { "NULL" }
    $rv_Path_ID_Level_83                  = if ($path_id_split[83]){ $path_id_split[83] } else { "NULL" }
    $rv_Path_ID_Level_84                  = if ($path_id_split[84]){ $path_id_split[84] } else { "NULL" }
    $rv_Path_ID_Level_85                  = if ($path_id_split[85]){ $path_id_split[85] } else { "NULL" }
    $rv_Path_ID_Level_86                  = if ($path_id_split[86]){ $path_id_split[86] } else { "NULL" }
    $rv_Path_ID_Level_87                  = if ($path_id_split[87]){ $path_id_split[87] } else { "NULL" }
    $rv_Path_ID_Level_88                  = if ($path_id_split[88]){ $path_id_split[88] } else { "NULL" }
    $rv_Path_ID_Level_89                  = if ($path_id_split[89]){ $path_id_split[89] } else { "NULL" }
    $rv_Path_ID_Level_90                  = if ($path_id_split[90]){ $path_id_split[90] } else { "NULL" }
    $rv_Path_ID_Level_91                  = if ($path_id_split[91]){ $path_id_split[91] } else { "NULL" }
    $rv_Path_ID_Level_92                  = if ($path_id_split[92]){ $path_id_split[92] } else { "NULL" }
    $rv_Path_ID_Level_93                  = if ($path_id_split[93]){ $path_id_split[93] } else { "NULL" }
    $rv_Path_ID_Level_94                  = if ($path_id_split[94]){ $path_id_split[94] } else { "NULL" }
    $rv_Path_ID_Level_95                  = if ($path_id_split[95]){ $path_id_split[95] } else { "NULL" }
    $rv_Path_ID_Level_96                  = if ($path_id_split[96]){ $path_id_split[96] } else { "NULL" }
    $rv_Path_ID_Level_97                  = if ($path_id_split[97]){ $path_id_split[97] } else { "NULL" }
    $rv_Path_ID_Level_98                  = if ($path_id_split[98]){ $path_id_split[98] } else { "NULL" }
    $rv_Path_ID_Level_99                  = if ($path_id_split[99]){ $path_id_split[99] } else { "NULL" }
    $rv_Item_Count_This_Level_Folders     = "NULL"
    $rv_Item_Count_This_Level_Files       = "NULL"
    $rv_Item_Count_This_Level             = "NULL"
    $rv_Item_Count_Recursive              = "NULL"
    $rv_isBoxNote                         = "NULL"
    $rv_Char_Count_Path                   = if ($batchRow.Path) { $batchRow.Path.Length } else { "NULL" }
    $rv_Char_Count_ItemName               = if ($batchRow.Item_Name) { $batchRow.Item_Name.Length } else { "NULL" }

    $rv_Folder_Level                      = "NULL"
    if ($batchRow.Item_Type -eq 'File') { $rv_Folder_Level = $path_id_split.Count - 2}
    if ($batchRow.Item_Type -eq 'File' -and $rv_Folder_Level -eq -1) { $rv_Folder_Level = 0 }
    if ($batchRow.Item_Type -eq 'File' -and $rv_Folder_Level -eq -2) { $rv_Folder_Level = 0 }
    if ($batchRow.Item_Type -eq 'Folder') { $rv_Folder_Level = $path_id_split.Count - 2}

    $queryString += "("
    $queryString += "$rv_Owner_Name,"
    $queryString += "$rv_Owner_Login,"
    $queryString += "$rv_Path,"
    $queryString += "$rv_Path_ID,"
    $queryString += "$rv_Item_Name,"
    $queryString += "$rv_Item_ID,"
    $queryString += "$rv_Item_Type,"
    $queryString += "$rv_File_Extension,"
    $queryString += "$rv_Size,"
    $queryString += "$rv_Size_This_level,"
    $queryString += "$rv_Size_This_Level_Recursive,"
    $queryString += "$rv_Size_Bytes,"
    $queryString += "$rv_Size_KB,"
    $queryString += "$rv_Size_MB,"
    $queryString += "$rv_Size_GB,"
    $queryString += "$rv_Created,"
    $queryString += "$rv_Last_Modified,"
    $queryString += "$rv_Uploaded,"
    $queryString += "$rv_Data_Retention_Policy,"
    $queryString += "$rv_Path_ID_Level_01,"
    $queryString += "$rv_Path_ID_Level_02,"
    $queryString += "$rv_Path_ID_Level_03,"
    $queryString += "$rv_Path_ID_Level_04,"
    $queryString += "$rv_Path_ID_Level_05,"
    $queryString += "$rv_Path_ID_Level_06,"
    $queryString += "$rv_Path_ID_Level_07,"
    $queryString += "$rv_Path_ID_Level_08,"
    $queryString += "$rv_Path_ID_Level_09,"
    $queryString += "$rv_Path_ID_Level_10,"
    $queryString += "$rv_Path_ID_Level_11,"
    $queryString += "$rv_Path_ID_Level_12,"
    $queryString += "$rv_Path_ID_Level_13,"
    $queryString += "$rv_Path_ID_Level_14,"
    $queryString += "$rv_Path_ID_Level_15,"
    $queryString += "$rv_Path_ID_Level_16,"
    $queryString += "$rv_Path_ID_Level_17,"
    $queryString += "$rv_Path_ID_Level_18,"
    $queryString += "$rv_Path_ID_Level_19,"
    $queryString += "$rv_Path_ID_Level_20,"
    $queryString += "$rv_Path_ID_Level_21,"
    $queryString += "$rv_Path_ID_Level_22,"
    $queryString += "$rv_Path_ID_Level_23,"
    $queryString += "$rv_Path_ID_Level_24,"
    $queryString += "$rv_Path_ID_Level_25,"
    $queryString += "$rv_Path_ID_Level_26,"
    $queryString += "$rv_Path_ID_Level_27,"
    $queryString += "$rv_Path_ID_Level_28,"
    $queryString += "$rv_Path_ID_Level_29,"
    $queryString += "$rv_Path_ID_Level_30,"
    $queryString += "$rv_Path_ID_Level_31,"
    $queryString += "$rv_Path_ID_Level_32,"
    $queryString += "$rv_Path_ID_Level_33,"
    $queryString += "$rv_Path_ID_Level_34,"
    $queryString += "$rv_Path_ID_Level_35,"
    $queryString += "$rv_Path_ID_Level_36,"
    $queryString += "$rv_Path_ID_Level_37,"
    $queryString += "$rv_Path_ID_Level_38,"
    $queryString += "$rv_Path_ID_Level_39,"
    $queryString += "$rv_Path_ID_Level_40,"
    $queryString += "$rv_Path_ID_Level_41,"
    $queryString += "$rv_Path_ID_Level_42,"
    $queryString += "$rv_Path_ID_Level_43,"
    $queryString += "$rv_Path_ID_Level_44,"
    $queryString += "$rv_Path_ID_Level_45,"
    $queryString += "$rv_Path_ID_Level_46,"
    $queryString += "$rv_Path_ID_Level_47,"
    $queryString += "$rv_Path_ID_Level_48,"
    $queryString += "$rv_Path_ID_Level_49,"
    $queryString += "$rv_Path_ID_Level_50,"
    $queryString += "$rv_Path_ID_Level_51,"
    $queryString += "$rv_Path_ID_Level_52,"
    $queryString += "$rv_Path_ID_Level_53,"
    $queryString += "$rv_Path_ID_Level_54,"
    $queryString += "$rv_Path_ID_Level_55,"
    $queryString += "$rv_Path_ID_Level_56,"
    $queryString += "$rv_Path_ID_Level_57,"
    $queryString += "$rv_Path_ID_Level_58,"
    $queryString += "$rv_Path_ID_Level_59,"
    $queryString += "$rv_Path_ID_Level_60,"
    $queryString += "$rv_Path_ID_Level_61,"
    $queryString += "$rv_Path_ID_Level_62,"
    $queryString += "$rv_Path_ID_Level_63,"
    $queryString += "$rv_Path_ID_Level_64,"
    $queryString += "$rv_Path_ID_Level_65,"
    $queryString += "$rv_Path_ID_Level_66,"
    $queryString += "$rv_Path_ID_Level_67,"
    $queryString += "$rv_Path_ID_Level_68,"
    $queryString += "$rv_Path_ID_Level_69,"
    $queryString += "$rv_Path_ID_Level_70,"
    $queryString += "$rv_Path_ID_Level_71,"
    $queryString += "$rv_Path_ID_Level_72,"
    $queryString += "$rv_Path_ID_Level_73,"
    $queryString += "$rv_Path_ID_Level_74,"
    $queryString += "$rv_Path_ID_Level_75,"
    $queryString += "$rv_Path_ID_Level_76,"
    $queryString += "$rv_Path_ID_Level_77,"
    $queryString += "$rv_Path_ID_Level_78,"
    $queryString += "$rv_Path_ID_Level_79,"
    $queryString += "$rv_Path_ID_Level_80,"
    $queryString += "$rv_Path_ID_Level_81,"
    $queryString += "$rv_Path_ID_Level_82,"
    $queryString += "$rv_Path_ID_Level_83,"
    $queryString += "$rv_Path_ID_Level_84,"
    $queryString += "$rv_Path_ID_Level_85,"
    $queryString += "$rv_Path_ID_Level_86,"
    $queryString += "$rv_Path_ID_Level_87,"
    $queryString += "$rv_Path_ID_Level_88,"
    $queryString += "$rv_Path_ID_Level_89,"
    $queryString += "$rv_Path_ID_Level_90,"
    $queryString += "$rv_Path_ID_Level_91,"
    $queryString += "$rv_Path_ID_Level_92,"
    $queryString += "$rv_Path_ID_Level_93,"
    $queryString += "$rv_Path_ID_Level_94,"
    $queryString += "$rv_Path_ID_Level_95,"
    $queryString += "$rv_Path_ID_Level_96,"
    $queryString += "$rv_Path_ID_Level_97,"
    $queryString += "$rv_Path_ID_Level_98,"
    $queryString += "$rv_Path_ID_Level_99,"
    $queryString += "$rv_Item_Count_This_Level_Folders,"
    $queryString += "$rv_Item_Count_This_Level_Files,"
    $queryString += "$rv_Item_Count_This_Level,"
    $queryString += "$rv_Item_Count_Recursive,"
    $queryString += "$rv_isBoxNote,"
    $queryString += "$rv_Char_Count_Path,"
    $queryString += "$rv_Char_Count_ItemName,"
    $queryString += "$rv_Folder_Level),"

    #endregion

}

    # Remove the trailing comma
    $queryString = $queryString.Trim().TrimEnd(",")


    # Execute the query
    Invoke-Sqlcmd -ServerInstance $sqlServer -Database $sqlDatabase -Username $sqlUser -Password $sqlPass -Query $queryString
    if ($?) {} else {
        # We know about root level duplicates, we do not want these going to the logs
        if ($Error[0].Exception.Message -notmatch 'duplicate' -and $batchSize -eq '1'){
        $Error[0].Exception.Message | Out-File .\ErrorLog.$($csv.Name.Replace('.csv','')).txt -Append
        $queryString | Out-File .\ErrorLog.$($csv.Name.Replace('.csv','')).txt -Append
       }
        $Error[0].Exception.Message
        $queryString
    }
    
    # Write a message indicating that the data has been inserted
    Write-Output "Inserted data for rows $($counter - $batchSize + 1) to $counter of ($($csvData.Count)) for: $($csv.Name)"
        
     # Reset the query string for the next batch
    $queryString = "INSERT INTO [$tableNameforDryvIQReport] ("
    $queryString += "Owner_Name, Owner_Login, Path, Path_ID, Item_Name, Item_ID, Item_Type, File_Extension, Size, Size_GB_This_Level, Size_GB_This_Level_Recursive, Size_Bytes, Size_KB, Size_MB, Size_GB, Created, Last_Modified, Uploaded, Data_Retention_Policy, Path_ID_Level_01, Path_ID_Level_02, Path_ID_Level_03, Path_ID_Level_04, Path_ID_Level_05, Path_ID_Level_06, Path_ID_Level_07,
    Path_ID_Level_08, Path_ID_Level_09, Path_ID_Level_10, Path_ID_Level_11, Path_ID_Level_12, Path_ID_Level_13, Path_ID_Level_14, Path_ID_Level_15, Path_ID_Level_16, Path_ID_Level_17, Path_ID_Level_18, Path_ID_Level_19, Path_ID_Level_20, Path_ID_Level_21, Path_ID_Level_22, Path_ID_Level_23, Path_ID_Level_24, Path_ID_Level_25, Path_ID_Level_26, Path_ID_Level_27, Path_ID_Level_28, Path_ID_Level_29,
    Path_ID_Level_30, Path_ID_Level_31, Path_ID_Level_32, Path_ID_Level_33, Path_ID_Level_34, Path_ID_Level_35, Path_ID_Level_36, Path_ID_Level_37, Path_ID_Level_38, Path_ID_Level_39, Path_ID_Level_40, Path_ID_Level_41, Path_ID_Level_42, Path_ID_Level_43, Path_ID_Level_44, Path_ID_Level_45, Path_ID_Level_46, Path_ID_Level_47, Path_ID_Level_48, Path_ID_Level_49, Path_ID_Level_50, Path_ID_Level_51,
    Path_ID_Level_52, Path_ID_Level_53, Path_ID_Level_54, Path_ID_Level_55, Path_ID_Level_56, Path_ID_Level_57, Path_ID_Level_58, Path_ID_Level_59, Path_ID_Level_60, Path_ID_Level_61, Path_ID_Level_62, Path_ID_Level_63, Path_ID_Level_64, Path_ID_Level_65, Path_ID_Level_66, Path_ID_Level_67, Path_ID_Level_68, Path_ID_Level_69, Path_ID_Level_70, Path_ID_Level_71, Path_ID_Level_72, Path_ID_Level_73,
    Path_ID_Level_74, Path_ID_Level_75, Path_ID_Level_76, Path_ID_Level_77, Path_ID_Level_78, Path_ID_Level_79, Path_ID_Level_80, Path_ID_Level_81, Path_ID_Level_82, Path_ID_Level_83, Path_ID_Level_84, Path_ID_Level_85, Path_ID_Level_86, Path_ID_Level_87, Path_ID_Level_88, Path_ID_Level_89, Path_ID_Level_90, Path_ID_Level_91, Path_ID_Level_92, Path_ID_Level_93, Path_ID_Level_94, Path_ID_Level_95,
    Path_ID_Level_96, Path_ID_Level_97, Path_ID_Level_98, Path_ID_Level_99, Item_Count_This_Level_Folders, Item_Count_This_Level_Files, Item_Count_This_Level, Item_Count_Recursive, is_BoxNote, Char_Count_Path, Char_Count_ItemName, Folder_Level)"
    $queryString += "VALUES "
    
}
}



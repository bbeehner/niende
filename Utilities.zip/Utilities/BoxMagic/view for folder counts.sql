
USE [box_data]
Select TOP (1000) t1.Path_ID, t1.Path_ID_Level_01, t1.Path_ID_Level_02, t1.Path_ID_Level_03, t1.Item_Type, t1.Folder_Level, Count(t2.Path_ID) AS Total_Item_Count
,SUM(t2.Size_GB) AS Folder_GB
FROM [dbo].[221020_box_data_dryviq] as t1
LEFT JOIN [dbo].[221020_box_data_dryviq] AS t2 ON t2.Path_ID like t1.Path_ID + '%'
WHERE t1.Item_Type = 'Folder'
--AND t1.Path_ID like '%164888989409%'
AND t1.Path_ID not like '%@%'
GROUP BY t1.Path_ID, t1.Path_ID_Level_01, t1.Path_ID_Level_02, t1.Path_ID_Level_03, t1.Item_Type, t1.Folder_Level
--HAVING Count(t2.Path_ID) > 10
--ORDER BY COUNT(*) DESC
--ORDER BY Path_ID ASC
--ORDER BY Folder_Level ASC
ORDER BY Path_ID, COUNT(*) ASC

-- filter t1 by using where 
-- filter t2 by using having



--TODO
-- ====================================
-- first verify folder structure
-- execution plan (ctrl + m) check for slowness then improve query

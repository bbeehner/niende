
USE [box_data_w]
Select TOP (1000) t1.Path, t1.Path_ID, t1.Item_Type, t1.Folder_Level, Count(t2.Path_ID) AS Total_Item_Count,SUM(t2.Size_GB) AS Folder_GB
FROM [dbo].[box_data_dryviq] as t1
LEFT JOIN [dbo].[box_data_dryviq] AS t2 ON t2.Path_ID like t1.Path_ID + '%'
WHERE t1.Item_Type = 'Folder'
--AND t1.Path_ID like '%120662880411%'
AND t1.Path_ID not like '%@%'
AND (t1.Folder_Level = '1' OR t1.Folder_Level = '2')
GROUP BY t1.Path, t1.Path_ID, t1.Item_Type, t1.Folder_Level
--HAVING Count(t2.Path_ID) > 10
HAVING Count(t2.Path_ID) > 10
--ORDER BY COUNT(*) DESC
--ORDER BY Path_ID ASC
--ORDER BY Folder_Level ASC
ORDER BY Path_ID, COUNT(*) ASC, Folder_Level

-- filter t1 by using where 
-- filter t2 by using having


--TODO
-- ====================================
-- first verify folder structure
-- execution plan (ctrl + m) check for slowness then improve query

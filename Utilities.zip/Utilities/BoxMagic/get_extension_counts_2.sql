SELECT 
  CASE 
    WHEN file_extension IN ('jpg', 'jpeg', 'tif', 'tiff', 'png', 'bmp', 'gif', 'ico', 'jpe', 'pcx', 'wpg', 'eps', 'emf', 'svg', 'heic', 'hdr', 'svh') THEN 'IMAGE_FILES'
	WHEN file_extension IN ('mp4', 'wav', 'mov', 'ram', 'mid', 'aif', 'aiff', 'avi', 'flv', 'vob', 'mpg', 'mp3', 'wmv', 'wma', 'mpeg', 'fla', 'mp4', 'cda', 'mus', 'nlm', 'wmf', 'm4a', 'c5i', 'asf', 'm4p') THEN 'MEDIA_FILES'
    WHEN file_extension IN ('doc', 'docx', 'xlsx', 'xls', 'txt', 'msg', 'pdf', 'wpd', 'wps', 'rtf', 'csv', 'ppt', 'pptx', 'dxf', 'dwg', 'psd', 'glsx', 'eml', 'vcf', 'dot', 'xlt', 'vsd', 'vsdx', 'log', 'p65', 'nb', 'spc', 'xps') THEN 'DOCUMENTS'
	WHEN file_extension IN ('exe', 'pdb', 'dat', 'cab', 'bat', 'ps1', 'ini', 'bin', 'mdb', 'dbf', 'accdb', 'sh', 'jar', 'acc', 'sql', 'pkg', 'mac', 'pos', 'py', 'db') THEN 'EXECUTABLE_FILES'
	WHEN file_extension IN ('sys', 'dll', 'inf', 'com', 'ovl', 'cfg', 'tmp', 'vxd', 'ttf', 'pfb', 'fon', 'mon', 'mno', 'asv', 'lib', 'class', 'wir', 'sce', 'c5i', 'c5v', 'nsx') THEN 'SYSTEM_FILES'
	WHEN file_extension IN ('zip', 'tar', 'gz', 'rar', 'pst', 'bak', 'dwf', '001', '002', '003', '004', '005', '006', '007', '008', '009', '001b', 'idt') THEN 'ARCHIVE_FILES'
	WHEN file_extension IN ('htm', 'html', 'xml', 'xsl', 'url', 'ashx', 'asp', 'aspx', 'cgi', 'jsp', 'css', 'java', 'swf', 'chm', 'php', 'ihtml', 'js', 'hlp') THEN 'WEB_FILES'
	WHEN file_extension IN ('') THEN 'NO_EXTENSION'
    --ELSE file_extension 
	ELSE 'OTHER'
  END AS category,
  COUNT(*) AS count
FROM [221020_box_data_dryviq]
WHERE item_type = 'File'
GROUP BY 
  CASE 
    WHEN file_extension IN ('jpg', 'jpeg', 'tif', 'tiff', 'png', 'bmp', 'gif', 'ico', 'jpe', 'pcx', 'wpg', 'eps', 'emf', 'svg', 'heic', 'hdr', 'svh') THEN 'IMAGE_FILES'
	WHEN file_extension IN ('mp4', 'wav', 'mov', 'ram', 'mid', 'aif', 'aiff', 'avi', 'flv', 'vob', 'mpg', 'mp3', 'wmv', 'wma', 'mpeg', 'fla', 'mp4', 'cda', 'mus', 'nlm', 'wmf', 'm4a', 'c5i', 'asf', 'm4p') THEN 'MEDIA_FILES'
    WHEN file_extension IN ('doc', 'docx', 'xlsx', 'xls', 'txt', 'msg', 'pdf', 'wpd', 'wps', 'rtf', 'csv', 'ppt', 'pptx', 'dxf', 'dwg', 'psd', 'glsx', 'eml', 'vcf', 'dot', 'xlt', 'vsd', 'vsdx', 'log', 'p65', 'nb', 'spc', 'xps') THEN 'DOCUMENTS'
	WHEN file_extension IN ('exe', 'pdb', 'dat', 'cab', 'bat', 'ps1', 'ini', 'bin', 'mdb', 'dbf', 'accdb', 'sh', 'jar', 'acc', 'sql', 'pkg', 'mac', 'pos', 'py', 'db') THEN 'EXECUTABLE_FILES'
	WHEN file_extension IN ('sys', 'dll', 'inf', 'com', 'ovl', 'cfg', 'tmp', 'vxd', 'ttf', 'pfb', 'fon', 'mon', 'mno', 'asv', 'lib', 'class', 'wir', 'sce', 'c5i', 'c5v', 'nsx') THEN 'SYSTEM_FILES'
	WHEN file_extension IN ('zip', 'tar', 'gz', 'rar', 'pst', 'bak', 'dwf', '001', '002', '003', '004', '005', '006', '007', '008', '009', '001b', 'idt') THEN 'ARCHIVE_FILES'
	WHEN file_extension IN ('htm', 'html', 'xml', 'xsl', 'url', 'ashx', 'asp', 'aspx', 'cgi', 'jsp', 'css', 'java', 'swf', 'chm', 'php', 'ihtml', 'js', 'hlp') THEN 'WEB_FILES'
	WHEN file_extension IN ('') THEN 'NO_EXTENSION'
    --ELSE file_extension 
	ELSE 'OTHER'
  END

UNION ALL

SELECT 'TOTAL FILE COUNT', COUNT(*) AS count
FROM [221020_box_data_dryviq]
WHERE Item_Type = 'File'

ORDER BY count DESC;


SELECT file_extension, COUNT(*) AS count
FROM [221020_box_data_dryviq]
WHERE item_type = 'File'
GROUP BY file_extension
ORDER BY count DESC;
/****** Script for SelectTopNRows command from SSMS  ******/
DELETE FROM [box_data].[dbo].[221020_box_data_dryviq]
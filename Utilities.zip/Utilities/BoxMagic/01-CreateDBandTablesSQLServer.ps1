
Clear-Host
Push-Location $PSScriptRoot
$VerbosePreference = "Silently Continue" # Set to "Continue" to show all verbose messages and "Silently Continue" to not show verbose messages

#region variables

$boxReportPath                  = "C:\Users\Administrator\Desktop\Box Reports\WHEATON BOX REPORTS\20221020-Wheaton-Box(Full-Folder-and-File-Tree)\"
#$boxReportPath                  = "C:\Users\Administrator\Desktop\Wheaton Box Reports\20221020-Wheaton-Box(Full-Folder-and-File-Tree)\"

$createDatabase                 = $true
$databaseName                   = "box_data_w"

$createTableBox                 = $true
$tableNameforBoxReports         = "box_data_oem"

$createTableDryvIQ              = $true
$tableNameforDryvIQReport       = "box_data_dryviq"
$viewNameforDryvIQReport        = "box_data_dryviq_view"

$sqlServer                      = "localhost"
$sqlUser                        = "sa"
$sqlPass                        = "Skyme1100!"
$sqlService                     = "NT Service\MSSQLSERVER" #what is the account running the SQL Server?


#endregion 



#region PowerShell settings

Clear-Host
Push-Location $PSScriptRoot

$checkPolicy = Get-ExecutionPolicy
if ($checkPolicy -eq "Restricted")
{
    Write-Host "`r`n Error: PowerShell Execution Policy is set to `"Restricted`", Please run PowerShell as an Administrator, then run `"Set-ExecutionPolicy Unrestricted`"" -ForegroundColor Red
	[System.Console]::Read()
	exit		
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -ErrorAction SilentlyContinue

if ((Get-Module -ListAvailable -Name SQLPS) -or (Get-Module -ListAvailable -Name SqlServer)) {} else {
    Write-Host "Installing Module SqlServer" -ForegroundColor Cyan
    Install-Module SqlServer -Force -ErrorAction SilentlyContinue
}

#endregion



#region functions


#endregion




#region ScriptLogic

# set NTFS security for account running SQL. It needs these permissions to import the CSV files.

Write-Host "Setting NTFS Security for the Reports folder" -ForegroundColor Cyan
$acl = Get-Acl $boxReportPath
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("$sqlService","Modify","ContainerInherit,ObjectInherit","None","Allow")
$acl.SetAccessRule($rule)
$acl | Set-Acl -Path $boxReportPath


# create database

if ($createDatabase -eq $true){
    Write-Host "Creating Database $($databaseName)..." -ForegroundColor Cyan
    $dbSQL = Get-Content -Path ".\create_box_data_database.sql" -Raw
    $dbSQL = $dbSQL.Replace('DBNAME_REPLACE',$databaseName) 
    Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $dbSQL -ErrorAction SilentlyContinue
}
else {
    Write-Host "Checking for Database..." -ForegroundColor Cyan
    $sqlQuery = "SELECT COUNT(*) FROM sys.databases WHERE name = '$databaseName'"
    $result = Invoke-Sqlcmd -Query $sqlQuery -Database "master" -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass -ErrorAction SilentlyContinue

    # $result
    # exit

    if ($result[0] -eq 0) {
        Write-Host "Error: The database '$databaseName' does not exist. You must set `$createDatabase to `$true if you want this script to create the database" -ForegroundColor Red
        exit
    } else {
        Write-Host "The database '$databaseName' exists. Proceeding..." -ForegroundColor Cyan
    }
}



# create Tables

Write-Host "Creating Table $($tableNameforBoxReports)..." -ForegroundColor Cyan
$eSQL = Get-Content -Path ".\create_box_data_oem_table.sql" -Raw
$eSQL = $eSQL.Replace('TABLENAME_REPLACE',$tableNameforBoxReports) 
$eSQL = $eSQL.Replace('DBNAME_REPLACE',$databaseName) 
Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $eSQL -ErrorAction SilentlyContinue

Write-Host "Creating Table $($tableNameforDryvIQReport)..." -ForegroundColor Cyan
$dSQL = Get-Content -Path ".\create_box_data_dryviq_table.sql" -Raw
$dSQL = $dSQL.Replace('TABLENAME_REPLACE',$tableNameforDryvIQReport) 
$dSQL = $dSQL.Replace('DBNAME_REPLACE',$databaseName) 
Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $dSQL -ErrorAction SilentlyContinue

# Write-Host "Creating View $($viewNameforDryvIQReport)..." -ForegroundColor Cyan
# $vSQL = Get-Content -Path ".\create_box_data_dryviq_table_view.sql" -Raw
# $vSQL = $vSQL.Replace('TABLENAME_REPLACE',$tableNameforDryvIQReport) 
# $vSQL = $vSQL.Replace('VIEWNAME_REPLACE',$viewNameforDryvIQReport) 
# $vSQL = $vSQL.Replace('DBNAME_REPLACE',$databaseName) 
# Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $vSQL -ErrorAction SilentlyContinue

# load data

$boxReportPaths = Get-ChildItem $boxReportPath

foreach ($report in $boxReportPaths){

    $text = $null
    $text = Get-Content $($report.FullName)
    if ($text -and $text[0] -notmatch "_"){
        Write-Host "Adding underscores to CSV header for: $($report.Name)..." -ForegroundColor Cyan
        $text[0] = $text[0] -replace " ", "_"
        $text | Set-Content $($report.FullName) -Force
    }

    # Debug:
    # $report | Get-Member

    $qSQL = "
    USE [DBNAME_REPLACE]
    GO
    BULK INSERT [dbo].[TABLENAME_REPLACE]
    FROM '$($report.FullName)'
    WITH (
        FORMAT = 'CSV', 
        DATAFILETYPE = 'char', 
        FIRSTROW = 2, 
        FIELDTERMINATOR = ',', 
        ROWTERMINATOR='\n', 
        BATCHSIZE=50000, 
        MAXERRORS=0 );
    GO
    "

    # Data insert OEM Table
    $oSQL = $qSQL.Replace('TABLENAME_REPLACE',$tableNameforBoxReports) 
    $oSQL = $oSQL.Replace('DBNAME_REPLACE',$databaseName) 
    Write-Host "Inserting Data into $($tableNameforBoxReports) for: $($report.Name)..." -ForegroundColor Cyan
    Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $oSQL #-ErrorAction SilentlyContinue

    # Data insert DryvIQ Table
    $rSQL = $qSQL.Replace('TABLENAME_REPLACE',$viewNameforDryvIQReport) 
    $rSQL = $rSQL.Replace('DBNAME_REPLACE',$databaseName) 
    # Write-Host "Inserting Data into $($tableNameforDryvIQReport) via view $($viewNameforDryvIQReport) for: $($report.Name)..." -ForegroundColor Cyan
    # Invoke-Sqlcmd -ServerInstance $sqlServer -Username $sqlUser -Password $sqlPass $rSQL #-ErrorAction SilentlyContinue

}





#endregion


USE [DBNAME_REPLACE]
GO

/****** Object:  Table [dbo].[TABLENAME_REPLACE] ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TABLENAME_REPLACE]') AND type in (N'U'))
DROP TABLE [dbo].[TABLENAME_REPLACE]
GO

/****** Object:  Table [dbo].[TABLENAME_REPLACE] ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TABLENAME_REPLACE](
	[Owner_Name] [nvarchar](max) NULL,
	[Owner_Login] [nvarchar](max) NULL,
	[Path] [nvarchar](max) NULL, 
	[Path_ID] [nvarchar](max) NOT NULL,
	[Item_Name] [nvarchar](max) NULL,
	[Item_ID] [float] NULL,
	[Item_Type] [nvarchar](max) NULL,
	[Size] [nvarchar](max) NULL,
	[Created] [nvarchar](25) NULL,
	[Last_Modified] [nvarchar](25) NULL,
	[Uploaded] [nvarchar](25) NULL,
	[Data_Retention_Policy] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO




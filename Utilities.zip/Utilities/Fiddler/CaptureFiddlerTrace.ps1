 <#
.DESCRIPTION
    Turns on / off the capturing of fiddler traces in skySync
	 
.INPUTS
    skysyncServer               =   Url to access SkySync environment.
    skysyncAdminUser            =   administrator username to access SkySync
    skysyncAdminUserPassword    =   administrator password to access SkySync
    enable                      =   if $true, will start Fiddler trace. If $false, will turn off Fiddler trace.
.OUTPUTS
    None
.NOTES
    * Script obtains Auth Token from SkySync API. 
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer to use fqdn/IP and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address

        * Dependencies: Server SkySyncInstallationDirectory or SkySyncConfigurationDirectory must have: "net" :  {	"fiddler":	{	"enable" : true	}  }
    
.EXAMPLE
    .\'CaptureFiddlerTrace.ps1' $skysyncServer=http://DESKTOP-9BHVIFS:9090/ $skysyncAdminUser=admin $skysyncAdminUserPassword='password'
#>

Param(
	[string]$skysyncServer = "http://10.0.1.4:9090/",
    [string]$skysyncAdminUser = "admin",
    [string]$skysyncAdminUserPassword = 'Skyme1100!',
    [bool]$enable = $false
)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

$requestBody = 
'
{
    "status": <enable>
}
'

try {
    #negotiate TLS1.2 for to support https requests
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
    $authHeader = get-request-header $accessToken
# - made change because results were coming back with True instead of true.
    $fiddlerValue = $enable.ToString().ToLower()
    $requestBody = $requestBody -replace "<enable>", $fiddlerValue
    
    $requestMethod = $skysyncServer + "v1/diagnostics/fiddler"
    $response = Invoke-RestMethod $requestMethod -Headers $authHeader -Method Post -Body $requestBody -ContentType 'application/json; charset=utf-8'# -Proxy 'http://localhost:8888'
}
catch{
    $exMsg = $_.Exception.Message
    $line = $_.Exception.InvocationInfo.ScriptLineNumber
    $st = $_.ScriptStackTrace
    Write-Host "An error occurred while updating the Fiddler Capture status: ${exMsg}. Line ${line}. ${st}"
    return
} 

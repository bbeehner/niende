<#
.DESCRIPTION
    Downloads Items On Behalf of the File's Owner
.INPUTS
    dryviqServer                            =   SkySync server host and port
    dryviqAdminUser                         =   SkySync admin username
	dryviqAdminUserPassword                 =   SkySync admin user password
    connectionId			                =   Connection ID where items reside
    platformItemId                          =   Item ID to Downlaod
    transscriptPath			                =   Path to write Transcript file
    impersonateUser                     	=   OPTIONAL: file owner's user email address.
    fileDownloadLocation                    =   Location to download the file to.
    
.OUTPUTS
    CSV file in relative directory
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $dryviqServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'UpdateFolderPermissions.ps1' $dryviqServer=http://DESKTOP-9BHVIFS:9090/ $connectionId="46a08dd47b674b46bd8108314a1f2f51"
#>

Param(
    [string]$dryviqServer = "http://localhost:9090/",
    [string]$dryviqAdminUser = "admin",
    [string]$dryviqAdminUserPassword = 'P@ssword!',
    [string]$connectionId = "d27fd627f35744998dcd4e30d45fe6d1",
    [string]$platformItemId = "822024754361",
    [string]$transscriptPath = ".\DownloadItems_transscript_" + (Get-Date).tostring("yyyyMMdd_hhmmss") + ".txt",
    [string]$impersonateUser = "user@company.com",
    $fileDownloadLocation = ".\" 
)

function get-skysync-access-token
{
    param( [string] $dryviqServer, [string] $dryviqAdminUser, [string] $dryviqAdminUserPassword )
    $accessRequestUrl = $dryviqServer + "connect/token"

    $accessRequestBody = @{
        grant_type = "password"
        scope      = "offline_access profile roles"
        resource   = $dryviqServer
        username   = $dryviqAdminUser
        password   = $dryviqAdminUserPassword
    }

    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
    return $accessRequestResult.access_token
}

function get-request-header
{
    param( [string]$accessToken )
    $requestHeader = @{
        Authorization = "Bearer " + $accessToken
        Accept        = "application/json"
    }
    return $requestHeader
}

function get-request-header-with-impersonation
{
    param( [string]$accessToken, [string]$username )
    $requestHeader = @{
        Authorization  = "Bearer " + $accessToken
        Accept         = "application/json"
        "X-Connect-As" = $username
    }
    return $requestHeader
}

function get-file-name
{
    $accessToken = get-skysync-access-token $dryviqServer $dryviqAdminUser $dryviqAdminUserPassword
    $authHeader = get-request-header-with-impersonation $accessToken $impersonateUser

    $getItemMethod = $dryviqServer + "v1/connections/$connectionId/files/$platformItemId" 
    $response = Invoke-RestMethod -Method Get $getItemMethod -Headers $authHeader -ContentType "application/json; charset=utf-8"

    return $response.item.name
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Start-Transcript -Path $transscriptPath

$startTime = "{0:G}" -f (Get-date)
Write-Host "*** Script started on $startTime ***" -f Blue -b DarkYellow
 
try
{
    $fileName = get-file-name
    $fileDownloadPath = $fileDownloadLocation + $fileName
    
    Write-Host "retrieving item " $fileName " from owner's account: " $impersonateUser " having Platform Item ID: " $platformItemId -ForegroundColor Yellow

    $accessToken = get-skysync-access-token $dryviqServer $dryviqAdminUser $dryviqAdminUserPassword
    $authHeader = get-request-header-with-impersonation $accessToken $impersonateUser

    ##Download FILE contents
    $getItemMethod = $dryviqServer + "v1/connections/$connectionId/files/$platformItemId/content"
    Invoke-WebRequest -URI $getItemMethod -Headers $authHeader -OutFile $fileDownloadPath
    Write-host "Successfully downloaded item " $fileName -ForegroundColor Green
}
catch
{
    $exMsg = $_.Exception.Message
    $line = $_.Exception.InvocationInfo.ScriptLineNumber
    $st = $_.ScriptStackTrace
    Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
    Write-Host "File Owner: " $impersonateUser " | ID: " $platformItemId -ForegroundColor Red
    Write-Host "An error occurred while downloading item: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
    Write-Host "------------------------------------------------------------------------------------" -ForegroundColor Red
}
 

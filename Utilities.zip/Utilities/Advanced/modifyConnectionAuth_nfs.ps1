<#
.DESCRIPTION
    Updates Connection Authentication info for NFS Connections
.INPUTS
    skysyncServer               =   SkySync server host and port
    skysyncAdminUser            =   SkySync admin username
	skysyncAdminUserPassword    =   SkySync admin user password
	connectionName				=	Connection name search criteria. If unspecified, all connections are selected.
	connectionPlatform			=	Platform ID of Connection(s) to update
	connectionUsername			=	New Connection Username
	connectionPassword			=	New Connection Password
.OUTPUTS
    None
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'ModifyConneectionAuth_NFS.ps1' $skysyncServer=http://localhost:9090/
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
    [string]$skysyncAdminUser = "admin",
	[string]$skysyncAdminUserPassword = 'P@ssword',
	[string]$connectionName = "skysynclocal",
	[string]$connectionPlatform = 'nfs',
	[string]$connectionUsername = '{user account name}',
	[string]$connectionPassword = '{user account password}'

)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#get skysync access token
$accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
$authHeader = get-request-header $accessToken

$totalconnections = @()
$offset = 0 
$maxconnectionsPerRequest = 1000

try {
	$hasMore = $true
	while ($hasMore)
	{
		#retrieve all connections to export
		$connectionsRequestMethod = $skysyncServer + "v1/connections?platform=$connectionPlatform&pools=0&fields=id&limit=$maxConnectionsPerRequest&offsset=$offset&q=$connectionName"
		$connectionsResponse = Invoke-RestMethod $connectionsRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

		$totalconnections += $connectionsResponse.connections
		$hasMore = $connectionsResponse.meta.has_more

		if($hasMore) #make additional job requests as necessary
		{
			$offset += $maxconnectionsPerRequest
		}
	}

	Write-Host "identified" $totalconnections.count "connections to update"

	foreach ($connection in $totalconnections)
	{ 
		$connectionDetailsMethod = $skysyncServer + "v1/connections/$($connection.id)?fields=auth,name"
		$connectionDetailsResponse = Invoke-RestMethod $connectionDetailsMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

		$requestBody = '{

			"name": "{name}",
		
			"platform": {
		
			"id": "{id}"
		
			},
		
			"auth": {
		
			"uri":"{uri}",
		
			"username":"{username}",
		
			"password":"{password}"
		
			}
		}'
		
		$connectionNameEncoded = $connectionDetailsResponse.connection.name -replace [Regex]::Escape("\"), "\\"
		$connectionUriEncoded = $connectionDetailsResponse.connection.auth.uri -replace [Regex]::Escape("\"), "\\"
		
		$requestBody = $requestBody -replace "{name}", $connectionNameEncoded
		$requestBody = $requestBody -replace "{username}", $connectionUsername
		$requestBody = $requestBody -replace "{password}", $connectionPassword
		$requestBody = $requestBody -replace "{id}", $connectionPlatform
		$requestBody = $requestBody -replace "{uri}", $connectionUriEncoded
		
		$connectionEndpoint = $skysyncServer + "v1/connections/" + $connection.id
		$connectionResponse = Invoke-RestMethod $connectionEndpoint -Method Patch -Headers $authHeader -ContentType 'application/json; charset=utf-8' -Body $requestBody  #-Proxy 'http://localhost:8888'
		write-host 'Updated connection auth for connection:' $connectionResponse.connection.id '-' $connectionResponse.connection.name
		
	}
}
catch {
	$exMsg = $_.Exception.Message
	$line = $_.Exception.InvocationInfo.ScriptLineNumber
	$st = $_.ScriptStackTrace
	Write-Host "An error occurred while enabling connections: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
	return
}

# https://docs.microsoft.com/en-us/mem/configmgr/core/plan-design/security/enable-tls-1-2-client#configure-for-strong-cryptography
# https://learn.microsoft.com/en-us/dotnet/framework/network-programming/tls#schusestrongcrypto

#region Check to see if Shell is running as Administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator"))
{
    Write-Host "ERROR: You do not have Administrator rights to run this script! Please run PowerShell as an Administrator then run the script again."
    Read-Host "Press any key to exit..."
    exit
}
#endregion  


# Check to see if folder exist in registry
# Protocols
$regLocations= (
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client",
# "HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server",
"HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2",
"HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client",
"HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server")


foreach ($regLocation in $regLocations){

    Get-Item -Path $regLocation -ErrorAction SilentlyContinue | Out-Null
    if ($?){

    }
    else {
        New-Item -Path $regLocation -Force -Confirm:$false -ErrorAction Inquire
    }
}



#region Deployment Entries

# # Disable Multi-Protocol Unified Hello - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable Multi-Protocol Unified Hello - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable PCT 1.0 - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable PCT 1.0 - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable SSL 2.0 - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable SSL 2.0 - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable SSL 3.0 - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable SSL 3.0 - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable TLS 1.0 - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable TLS 1.0 - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable TLS 1.1 - Client
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# # Disable TLS 1.1 - Server
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
# New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# Enable TLS 1.2 - Client
New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

# Enable TLS 1.2 - Server
New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name 'Enabled' -PropertyType 'DWord' -Value '1' -Force -Confirm:$false
New-ItemProperty -path 'HKLM:\\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name 'DisabledByDefault' -PropertyType 'DWord' -Value '0' -Force -Confirm:$false

#region



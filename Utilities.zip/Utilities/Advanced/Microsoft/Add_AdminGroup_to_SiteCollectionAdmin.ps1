﻿#$namedUserList is the list of test users whose data will be transferred - NOTE - PREFERRED METHOD IS TO USE A GROUP (BELOW) - $namedTransferAdminList
#$namedUserList = "user1@company.com","user2@company.com","user3@company.com"

Write-Host -ForegroundColor DarkYellow "Please select a csv with users"
[System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
Out-Null
$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.initialDirectory = "c:\Temp"
$OpenFileDialog.filter = "All files (*.csv)| *.csv"
$OpenFileDialog.ShowDialog() | Out-Null
$csv = $OpenFileDialog.filename

if (-Not [string]::IsNullOrWhiteSpace($csv))
{
    $namedUserList = Import-csv $csv
}
else{
    Write-Host -ForegroundColor red "Cancelling, no csv selected"
               Break;
}


#namedTransferAdminList is the list of tennant admin accounts that will be used as a user pool to execute the transfer
# EDIT THIS LIST! Add in one or more users who will be configured as the transfer accounts (will become site collection admins for the user site collections in the list above)
$namedTransferAdminList = "c:0-.f|rolemanager|s-1-5-21-XXXXXXXXXX-XXXXXXXXXX-XXXXXXXXX-XXXXXXXXX"

$siteAdminUrl = "https://companyname-admin.sharepoint.com"

$sitePersonalBaseUrl = "https://companyname-my.sharepoint.com/personal/"

#Authenticate Directly with MSFT
Connect-SPOService -Url $siteAdminUrl

foreach ($strUser in $namedUserList."Account ID")
{
Write-host -ForegroundColor Cyan "Working on user:"$strUser
               $domain = $strUser.Split("@")
               $domain = $domain[1].replace(".","_")
               $sitePersonalSuffix = "_" + $domain 


     $intPos = $strUser.IndexOf("@")

     $strUser = $strUser.SubString(0, $intPos)

     $strUser = $strUser.replace(".","_")

     $strSite = $sitePersonalBaseUrl + $strUser

     $strSite = $strSite + $sitePersonalSuffix
                 

     foreach ($objAdminEmail in $namedTransferAdminList){

        Write-Host $objAdminEmail

        Write-Host $strSite

        Set-SPOUser -Site $strSite -LoginName $objAdminEmail -IsSiteCollectionAdmin $true

        Write-Host ""

     }

}

#	When to use this script? - If a client is using vanity O365 url and also when you go to impersonate ODFB users, ODFB users fail to load.
#	What is this script doing? This script is basically bypassing the vanity url.
#	============================================================================	
#	STEPS TO EXECUTE THE SCRIP
#   1. Configure the ODFB and/or SPO connection like you would normally configure.
#	2. Set connectors:hide_authentication_details to false.
#	(.\skysync.exe config set connectors:hide_authentication_details false --in-database)
#	3. Restart the SkySync Manager service. 
#	4. Update the Param below and Run the script.
#	5. Restart the SkySync Manager service just to be safe. 
#	============================================================================	

Param(
  #skysync credentials
  [string]$skysyncServer = "http://localhost:9090/",
  [string]$skysyncAdminUser = "SkySyncPDCAdmin",
  [string]$skysyncAdminUserPassword = "ToTheOneDrive2021!"
)

function get-onedrive-connections {
  param( [string] $accessToken, [string] $skysyncServer)
  $connectionRequestHeaders = get-request-header $accessToken
  $connectionRequestUrl = $skysyncServer + "v1/connections?platforms=onedrive-business-graph,office365-graph&pools=0&active=1"
  $connectionRequestResult = Invoke-RestMethod -Method 'Get' -Uri $connectionRequestUrl -Headers $connectionRequestHeaders
  return $connectionRequestResult.connections
}

function get-onedrive-connection {
  param( [string] $accessToken, [string] $skysyncServer, [string] $connectionId)
  $connectionRequestHeaders = get-request-header $accessToken
  $connectionRequestUrl = $skysyncServer + "v1/connections/" + $connectionId + "?fields=auth"
  $connectionRequestResult = Invoke-WebRequest -Method 'Get' -Uri $connectionRequestUrl -Headers $connectionRequestHeaders
  return $connectionRequestResult
}


function patch-onedrive-connection {
  param( [string] $accessToken, [string] $skysyncServer, [string] $connectionId, $body)
  $connectionRequestHeaders = get-request-header $accessToken
  $connectionRequestUrl = $skysyncServer + "v1/connections/" + $connectionId

  $bodyTemplate = '{
        "auth": {auth}
    }'

  $requestBody = $bodyTemplate -replace "{auth}", $body

  $connectionRequestResult = Invoke-RestMethod -Method Patch  -Uri $connectionRequestUrl -Headers $connectionRequestHeaders -ContentType 'application/json' -Body $requestBody
  return $connectionRequestResult | ConvertTo-Json
}



function get-request-header {
  param( [string]$accessToken )
  $requestHeader = @{
    Authorization = "Bearer " + $accessToken
    Accept        = "application/json"
  }
  return $requestHeader
}

function get-skysync-access-token {
  param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
  $accessRequestUrl = $skysyncServer + "connect/token"

  $accessRequestBody = @{
    grant_type = "password"
    scope      = "offline_access profile roles"
    resource   = $skysyncServer
    username   = $skysyncAdminUser
    password   = $skysyncAdminUserPassword
  }

  $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
  return $accessRequestResult.access_token
}

$accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword


$connections = get-onedrive-connections $accessToken $skysyncServer


foreach ($connection in $connections) {

  $result = get-onedrive-connection $accessToken $skysyncServer $connection.ID
  $result2 = $result | ConvertFrom-Json 

  Add-Member -InputObject $result2.connection.auth -NotePropertyName "office365"  -NotePropertyValue $True
 
  $result2.connection.auth.initialized = $False
  $result2.connection.auth.office365 = $True

  $result3 = $result2.connection.auth | ConvertTo-Json 

Write-Host $connection.ID
  patch-onedrive-connection $accessToken $skysyncServer $connection.ID  $result3
}
﻿

# this script needs: https://www.microsoft.com/en-us/download/details.aspx?id=35588 

try {Stop-Transcript} catch {}
Start-Transcript -Path .\LogFile.txt -Append

Clear-Host
Push-Location $PSScriptRoot
$users = Import-Csv -Path ".\ListofUsers.csv"

$siteAdminUrl = "https://REPLACE-admin.sharepoint.com"
$sitePersonalBaseUrl = "https://REPLACE-my.sharepoint.com/personal/"
$adminAccount  = "ServiceAccount@DOMAIN.com"

Connect-SPOService -Url $siteAdminUrl

# $users.destination_username is the column from the CSV containing the one drive accounts in email format
foreach ($userEmail in $users.destination_username) 
{
Write-host -ForegroundColor Cyan "Working on user:"$userEmail
               $domain = $userEmail.Split("@")
               $domain = $domain[1].replace(".","_")
               $sitePersonalSuffix = "_" + $domain 


     $intPos = $userEmail.IndexOf("@")

     $userEmail = $userEmail.SubString(0, $intPos)

     $userEmail = $userEmail.replace(".","_")

     $strSite = $sitePersonalBaseUrl + $userEmail

     $strSite = $strSite + $sitePersonalSuffix
               
        Write-Host "Processing OneDrive for $($strSite)"
        Write-Host "Processing command: Set-SPOUser -Site $($strSite) -LoginName $($adminAccount) -IsSiteCollectionAdmin `$true"
                                        Set-SPOUser -Site $strSite -LoginName $($adminAccount) -IsSiteCollectionAdmin $true

   

}


try {Stop-Transcript} catch {}
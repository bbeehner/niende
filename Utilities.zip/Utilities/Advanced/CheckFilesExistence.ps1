﻿<#
.DESCRIPTION
    Uses SkySync APIs to Determine whether item(s) exist
.INPUTS
    skysyncServer               =   SkySync server host and port
    skysyncAdminUser            =   SkySync admin username
	skysyncAdminUserPassword    =   SkySync admin user password
    sourceConnectionId			=	Source Platform Connection ID
    destinationConnectionId		=	Destiination Platform Connection ID
    inputFileDirectory			=	Directory of input file(s)
.OUTPUTS
    None
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'CheckFilesExistence.ps1' $skysyncServer=http://localhost:9090/
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
	[string]$skysyncAdminUser = "admin",
	[string]$skysyncAdminUserPassword = 'P@ssword',
	[string]$sourceConnectionId = "dd664c8141b1416f946c5b427a115e7f",
    [string]$destinationConnectionId = "af695449bba14f6887d89a7c497178e9",
    $inputFileDirectory = ".\FileExistence\CSV"	
)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
$authHeader = get-request-header $accessToken

$output = @()
function CheckFileExists($file)
{
    #-- Uncomment For Source Info --
    #  $sourceAccount = $file.SourceAccount
    #  $destinationAccount = $file.DestinationAccount
    #  $sourceFileId = $file.SourceFileId
     $destinationPath = $file.DestinationPath
     
     #-- Uncomment for Source Info
     ## Verify Source File Exists
     <# try
     {
        #$versionsEndpoint = $skysyncServer + "v1/connections/$sourceConnectionId/files/$sourceFileId/versions"
		$sourceFilesEndpoint = $skysyncServer + "v1/connections/$sourceConnectionId/files/$sourceFileId"
        $sourceFilesResponse = Invoke-RestMethod $sourceFilesEndpoint -Method GET -Headers $authHeader #-Proxy 'http://localhost:8888'
        #$versions = $versionsResponse.versions
        $file.SourceExists = $true

        $returnMessage = "Source File $sourceFileId already exists"
        Write-Host $returnMessage -ForegroundColor Green
     }
     catch
     {
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host $_.Exception.Response.StatusCode.value__ -ForegroundColor Red
        
        $responseCode = $_.Exception.Response.StatusCode.value__
        if($responseCode -eq "404")
        {
            $file.SourceExists = $false
        
            $returnMessage = "Source File $sourceFileId does not exist"
            Write-Host $returnMessage -ForegroundColor Yellow
        }
        else
        {
            $file.SourceExists = $null
        
            $returnMessage = "Internal Server Error in checking the source file $sourceFileId"
            Write-Host $returnMessage -ForegroundColor Red
        }

        $FailureMsg = "SourceFailure" + " - " + $_.Exception.Message + " - " + $responseCode
        Add-Content .\CSV\CheckFileExists\CheckFileExistsFailure$(Get-Date -Format yyyyMMdHH).txt "`n$FailureMsg"
     } #>

     ## Verify Destination File Exists
     try
     {
        $filesEndpoint =$skysyncServer + "v1/connections/$destinationConnectionId/files?path=$destinationPath"
        $filesResponse = Invoke-RestMethod $filesEndpoint -Method GET -Headers $authHeader #-Proxy 'http://localhost:8888'
        #$versions = $versionsResponse.versions
        $file.DestinationExists = $true

        $returnMessage = "Destination File $destinationPath already exists"
        Write-Host $returnMessage -ForegroundColor Green
     }
     catch
     {
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host $_.Exception.Response.StatusCode.value__ -ForegroundColor Red

        $responseCode = $_.Exception.Response.StatusCode.value__
        if($responseCode -eq "404")
        {
            $file.DestinationExists = $false

            $returnMessage = "Destination File $destinationPath does not exist"
            Write-Host $returnMessage -ForegroundColor Yellow
        }
        else
        {
            $file.DestinationExists = $null

            $returnMessage = "Internal Server Error in checking the path $destinationPath"
            Write-Host $returnMessage -ForegroundColor Red
        }
        
        $FailureMsg = "DestinationFailure" + " - " + $_.Exception.Message + " - " + $responseCode
        Add-Content .\CSV\CheckFileExists\CheckFileExistsFailure$(Get-Date -Format yyyyMMdHH).txt "`n$FailureMsg"
     }

     return $file
}

#----------------------MAIN PROGRAM START---------------------------------------#

Write-Host -ForegroundColor DarkYellow "Please select a CSV file with Jobs to start"
[System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.initialDirectory = $inputFileDirectory #"C:\Software\SkySync\Box to SharePoint\Helper PS Scripts"
$OpenFileDialog.filter = "All files (*.csv)| *.csv"
$OpenFileDialog.ShowDialog() | Out-Null
$csvFile = $OpenFileDialog.filename

$FileName = Split-Path $csvFile -leaf
$NewFileName = ".\CSV\Results" + $FileName

if (($csvFile -ne $null) -and ($csvFile -ne ""))
{
    $files = Import-Csv -Path $csvFile | select *, SourceExists, DestinationExists

    foreach ($file in $files)
    {
        $output += CheckFileExists($file)        
    }

    $output | Select-Object -Property SourceAccount,DestinationAccount,SourceFileId,DestinationPath,SourceExists,DestinationExists | Export-Csv $NewFileName -NoTypeInformation

    write-host "All Files verified for existence and results successfully Exported to CSV" -ForegroundColor Green
}
else
{   
    Write-Host "No CSV file selected to check files existence" -ForegroundColor Red
}
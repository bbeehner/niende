1. Run the following command to see your current time drift:

# compare local time with time.windows.com
w32tm /stripchart /computer:time.windows.com /dataonly /samples:5


2. Put all files in C:\SkySyncLocal\TimeSync

3. In Windows Task Scheduler, import C:\SkySyncLocal\TimeSync\TimeSync.xml, you will need to set the username and password on the first tab

4. Manually run the scheduled task

5. Run the following command to see your current time drift, it should be improved now:

# compare local time with time.windows.com
w32tm /stripchart /computer:time.windows.com /dataonly /samples:5

w32tm /config /syncfromflags:manual /manualpeerlist:pool.ntp.org
w32tm /config /update
w32tm /resync
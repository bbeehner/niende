<#
    Options for status:  active|inactive|cannot_delete_edit|cannot_delete_edit_upload
    Using the "inactive" status will prevent anyone from accessing that users
    The "cannot_delete_edit_upload" status is the equivalent of setting the user to read only
#>
function ConvertUsers($boxUserList, $status)
{     
    $boxUsers = Import-Csv -Path $boxUserList

    foreach ($user in $boxUsers)
    {       
        $result = box users:update $user.id --status $status --json | ConvertFrom-Json
        
        $boxUserName = $result.Name
        $boxUserStatus = $result.Status

        if ($boxUserStatus -eq $status)
        {
            Write-Host "Status change was successful for $boxUserName - Status: $boxUserStatus" -ForegroundColor Green
        }
        else 
        {
            Write-Host "Status change was FAILED for $boxUserName - Status: $boxUserStatus" -ForegroundColor Red
        }
        
    }
}

function ConvertUsersToReadonly ($boxUserList)
{
    $status = "cannot_delete_edit_upload" 
    ConvertUsers $boxUserList $status
}

function ConvertUsersToActive ($boxUserList)
{
    $status = "active" 
    ConvertUsers $boxUserList $status
}


Write-Host "Please select the list of Box users `n" -ForegroundColor Yellow 

[System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

$OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
$OpenFileDialog.InitialDirectory = Get-Item -Path ".\"
$OpenFileDialog.filter = "All files (*.csv)| *.csv"
$OpenFileDialog.ShowDialog() | Out-Null
$csvFile = $OpenFileDialog.filename

if (-Not [string]::IsNullOrEmpty($csvFile))
{
    ConvertUsersToReadonly $csvFile
    #ConvertUsersToActive $csvFile
}
else
{   
    Write-Host "No CSV file selected" -ForegroundColor Red
}


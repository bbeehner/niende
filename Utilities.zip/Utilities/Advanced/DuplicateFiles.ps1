
# This can duplicate all files in a folder and will append a count to the duplicates. The $count is the # of copies you want
# this is good when you need to create some test files for migrations. 

$Path = ".\edm_data"
$Files = Get-ChildItem -Path $Path -File
Push-Location $Path
$count = 2000

foreach ($File in $Files){
$count = 2000
    do {
        $count--
        $count
        $countNum = $count.ToString('0000')
        $newName = $File.Name.Replace(".File","_$countNum.File")
        Write-Host "Running   Copy-Item -Path $File -Destination .\$newName"
                              Copy-Item -Path $File -Destination .\$newName
    } while (
        $count -gt 0
    )


}

Push-Location $PSScriptRoot




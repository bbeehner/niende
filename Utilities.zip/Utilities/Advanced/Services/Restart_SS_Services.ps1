<#
.DESCRIPTION
    Restarts SkySync or DryvIQ services on remote computers in the cluster - your current account must have admin rights on all boxes.
.INPUTS
    None
.OUTPUTS
    None
.NOTES
    Update the list of servers in the array with the server names.
    You can create other versions of this file for "stopping or starting" the service
    
    Remember to run the powershell window as "Administrator" first to execute this script otherwise the script may fail on the computer that you are on
.EXAMPLE

    I am sure we could add parameters for options in the future.

#>

$cluster1 = @("uls-op-boxra01.ad.shared","uls-op-boxra02.ad.shared","uls-op-boxra03.ad.shared","uls-op-boxra04.ad.shared","uls-op-boxra05.ad.shared","uls-op-boxra06.ad.shared","uls-op-boxra07.ad.shared","uls-op-boxra08.ad.shared","uls-op-boxra09.ad.shared","uls-op-boxra10.ad.shared")
#$cluster2 = @("uls-op-boxra11.ad.shared","uls-op-boxra12.ad.shared","uls-op-boxra13.ad.shared","uls-op-boxra14.ad.shared","uls-op-boxra15.ad.shared","uls-op-boxra16.ad.shared","uls-op-boxra17.ad.shared","uls-op-boxra18.ad.shared","uls-op-boxra19.ad.shared","uls-op-boxra20.ad.shared")

foreach ($PC in $cluster1)
{
    Write-host "Server: " $pc
    #$s = Get-Service -ComputerName $PC  -Name skysync | Stop-Service -Force
    #$s = Get-Service -ComputerName $PC  -Name skysync | Start-Service
    $s = Get-Service -ComputerName $PC  -Name skysync | Restart-Service -Force
    Write-host $s
}


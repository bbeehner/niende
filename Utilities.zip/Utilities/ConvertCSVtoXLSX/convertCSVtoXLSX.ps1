Clear-Host
Push-Location $PSSCriptRoot

# Set the source and destination file paths
$sourceFile      = ".\remediation_items.csv"
$destFile        = ".\remediation_items.xlsx"
$csvReportType   = "remediation_items" # this must be remediation_items or jobs_report


$excelModuleName = "ImportExcel"
$excelModuleInstalled = Get-Module -ListAvailable -Name $excelModuleName

if ($excelModuleInstalled -eq $null) {
    try {
        Install-Module -Name $excelModuleName -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
    } catch {
        Write-Host "Failed to install the ImportExcel module. Please make sure you have the necessary permissions and try again."
        return
    }
}


$existingFile = Get-Item -Path $destFile -ErrorAction SilentlyContinue

if ($existingFile) {
    try {
        Remove-Item $destFile -Force -ErrorAction Stop
    } catch {
        Write-Host "Failed to remove existing destination file: $_"
        return
    }
}

try {
    if ($csvReportType -eq "remediation_items"){
        $data = Import-Csv -Path $sourceFile -ErrorAction Stop | Select-Object  @{Name='Status'; Expression={$_.Status.Replace('none', 'unknown')}},item_type,source_id,source_name,source_path,source_bytes,source_exists,destination_id,destination_name,destination_path,destination_bytes,destination_exists,audit_category_name,job_id,job_name,last_failure_type,last_failure_message,last_failure_recorded_on,embedded_links
    }
    if ($csvReportType -eq "jobs_report"){
        $data = Import-Csv -Path $sourceFile -ErrorAction Stop | Select-Object @{Name='JobID'; Expression={$_.Id}},SourcePath,@{Name='DestinationSite'; Expression={$_.destinationaccount}},DestinationPath,JobName,Category,Status,RunPhase,RunStatus,StartTime,EndTime,Runs,Src_429,Dest_429,Success,Revised,Retry,Flagged,Ignored,DestGB,DaysSinceLastRun,LatestErrorMessage
    }
#    if ($csvReportType -ne "remediation_items" -or $csvReportType -ne "jobs_report"){
#        Write-Host "Failed to import CSV file: $_ `$csvReportType set incorrectly"
#        return
#    }
} catch {
    Write-Host "Failed to import CSV file: $_"
    return
}

try {
    $data | Export-Excel -Path $destFile -AutoSize -ErrorAction Stop
} catch {
    Write-Host "Failed to convert data to Excel workbook: $_"
    return
}

try {
    $workbook = Open-ExcelPackage -Path $destFile -ErrorAction Stop
    $worksheet = $workbook.Workbook.Worksheets[1]
    $maxColumn = $worksheet.Dimension.Columns
    $headerRow = $worksheet.Cells[$worksheet.Dimension.Start.Row, 1, $worksheet.Dimension.Start.Row, $maxColumn]
    $headerRow.AutoFilter = $true

    # Add bold font to the header row
    $headerRow.Style.Font.Bold = $true

    # Freeze the top row
    $worksheet.View.FreezePanes(2, 1)

    $workbook.Save()
    $workbook.Dispose()
} catch {
    Write-Host "Failed to process Excel workbook: $_"
    return
}

Write-Host "CSV to XLSX conversion complete. Output file: $destFile"

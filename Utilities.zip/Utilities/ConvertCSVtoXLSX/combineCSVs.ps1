# This script combines CSV files and adds a "cluster" column

# Define the path to the folder containing the CSV files
$folderPath = "C:\Path\To\Your\Folder"

# Get the list of CSV files in the folder
$csvFiles = Get-ChildItem -Path $folderPath -Filter "*.csv"

# Loop through each CSV file and process it
foreach ($csvFile in $csvFiles) {
    # Get the base name of the CSV file without the extension
    $clusterValue = $csvFile.BaseName

    # Import the CSV file
    $data = Import-Csv $csvFile.FullName

    # Add the "cluster" column with the base name as the value
    $data | Add-Member -NotePropertyName "Source" -NotePropertyValue $clusterValue -Force

    # Output the combined data to a new CSV file
    $combinedPath = Join-Path -Path $folderPath -ChildPath "Combined.csv"
    $data | Export-Csv -Path $combinedPath -NoTypeInformation -Append
}

# Notify that the process is complete
Write-Host "CSV files combined successfully."

Clear-Host
Push-Location $PSScriptRoot

#region Set the source and destination file paths
$sourceDir       = $PSScriptRoot
$destFile        = ".\Wave1_JobStatusReport_2023-07-25.xlsx"
$excelModuleName = "ImportExcel"
#endregion

#region Check and install Excel module if not installed
$excelModuleInstalled = Get-Module -ListAvailable -Name $excelModuleName
if ($excelModuleInstalled -eq $null) {
    try {
        Install-Module -Name $excelModuleName -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
    } catch {
        Write-Host "Failed to install the ImportExcel module. Please make sure you have the necessary permissions and try again."
        return
    }
}
#endregion

#region Get all CSVs from the source directory
$csvFiles = Get-ChildItem -Path $sourceDir -Filter "*.csv"
if ($csvFiles -eq $null) {
    Write-Host "No CSV files found in the source directory: $sourceDir"
    return
}
#endregion

#region Remove existing Excel file if it exists
if (Test-Path $destFile) {
    try {
        Remove-Item $destFile -Force -ErrorAction Stop
    } catch {
        Write-Host "Failed to remove existing destination file: $_"
        return
    }
}
#endregion

#region Loop over each CSV and import it into Excel
foreach ($csvFile in $csvFiles) {
    try {
        $data = Import-Csv -Path $csvFile -ErrorAction Stop
    } catch {
        Write-Host "Failed to import CSV file: $_"
        return
    }

    try {
        $data | Export-Excel -Path $destFile -WorksheetName $($csvFile.BaseName) -AutoSize -ErrorAction Stop
    } catch {
        Write-Host "Failed to convert data to Excel workbook: $_"
        return
    }
}
Write-Host "Total Number of CSVs: $($csvFiles.count)"

#endregion

#region Open the workbook and format each worksheet
try {
    $workbook = Open-ExcelPackage -Path $destFile -ErrorAction Stop
    foreach ($worksheetName in $workbook.Workbook.Worksheets.Name) {
        $worksheet = $workbook.Workbook.Worksheets[$worksheetName]
        if ($worksheet.Dimension -ne $null) {
            $maxColumn = $worksheet.Dimension.Columns
            $headerRow = $worksheet.Cells[$worksheet.Dimension.Start.Row, 1, $worksheet.Dimension.Start.Row, $maxColumn]
            $headerRow.AutoFilter = $true
            $headerRow.Style.Font.Bold = $true
            $worksheet.View.FreezePanes(2, 1)
        }
    }
    $workbook.Save()
    $workbook.Dispose()
} catch {
    Write-Host "Failed to process Excel workbook: $_"
    return
}
#endregion

Write-Host "CSV to XLSX conversion complete. Output file: $destFile"

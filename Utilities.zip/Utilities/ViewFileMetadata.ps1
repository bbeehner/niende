<#
.DESCRIPTION
    Outputs file metadata
.INPUTS
    skysyncServer               =   SkySync server host and port
    skysyncAdminUser            =   SkySync admin username
    skysyncAdminUserPassword    =   SkySync admin user password
	sourceConnID				=   Source Platform Connection ID
	sourceFilePath				=	File to retrieve metadata attributes from

.OUTPUTS
    None
.NOTES
	 * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'ViewFileMetadata.ps1' $skysyncServer=http://localhost:9090/
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
	[string]$skysyncAdminUser = "admin",
	[string]$skysyncAdminUserPassword = 'P@ssword',
	[string]$sourceConnID = "0f4eddc42ba24dfe982636c7adadc5e4",
	$sourceFilePath = '/Shared Documents/Filename.txt'
)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {	
	$accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
	$authHeader = get-request-header $accessToken

	$createJobMethod = $skysyncServer + "v1/connections/" + $sourceConnID + "/files/metadata?path=" + $sourceFilePath
	$createJobResponse = Invoke-RestMethod $createJobMethod -Headers $authHeader -Method Get -ContentType 'application/json; charset=utf-8' -Body $jobConfig

	Write-Host $createJobResponse.item
}
catch {
	$exMsg = $_.Exception.Message
	$line = $_.Exception.InvocationInfo.ScriptLineNumber
	$st = $_.ScriptStackTrace
	Write-Host "An error occurred while retrieving metadata :" $user.destination_username  " ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
	return
}
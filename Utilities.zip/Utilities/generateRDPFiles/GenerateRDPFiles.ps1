﻿Clear-Host
Push-Location $PSScriptRoot

# Set the path to the CSV file containing the servername, IP address, credentials, and password
$csvFile = ".\server_list.csv"

# Set the path to the RDP file template
$templateFile = ".\rdp_template.txt"

# Set the destination directory for the new RDP files
$outputDir = ".\RDPs"

# Create the output directory if it doesn't exist
if (!(Test-Path -Path $outputDir -PathType Container)) {
    Write-Host "Creating output directory..."
    New-Item -ItemType Directory -Path $outputDir
}

# Import the CSV file as an array of objects
$csvData = Import-Csv $csvFile

# Loop through each row in the CSV file
foreach ($row in $csvData) {
    # Get the servername and IP address from the current row
    $servername = $row.servername
    $ipAddress = $row.ipaddress

    # Construct the filename for the new RDP file
    $outputFile = "$servername.rdp"

    # Encrypt the password value using the specified key
    $securePassword = ConvertTo-SecureString $row.password -AsPlainText -Force
    $encryptedPassword = $securePassword | ConvertFrom-SecureString -Key $key


    # Create a copy of the RDP template file with the appropriate settings
    $rdpContents = Get-Content $templateFile
    $rdpContents = $rdpContents -replace "targetipaddress",$ipAddress
    $rdpContents = $rdpContents -replace "targetusername",$($row.username).Trim()
    $rdpContents = $rdpContents -replace "targetpassword",$encryptedPassword
    
    # Save the RDP file to a temporary .txt file
    $tempFile = "$outputDir\$outputFile.txt"
    Set-Content $tempFile -Value $rdpContents -Force

    # Set the new RDP file to read-only
    Set-ItemProperty $tempFile -Name IsReadOnly -Value $true

    # Rename the file to have a .rdp extension
    Rename-Item $tempFile -NewName ($outputFile) -Force

 
}
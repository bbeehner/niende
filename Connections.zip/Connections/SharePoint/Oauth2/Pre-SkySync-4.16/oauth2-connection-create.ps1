<#
.DESCRIPTION
    Creates Microsoft Oauth2 connection from runFile and connectionTemplateFile
.INPUTS
    skysyncServer               =   SkySync server host and port
    skysyncAdminUser            =   SkySync admin username
    skysyncAdminUserPassword    =   SkySync admin user password
	runFile						=   Path to file containing values to create the connection
	connectionTemplateFile		=   Path to connection template JSON file

.OUTPUTS
    None
.NOTES
    *This script is compatible with SkySync versions pre-dating 4.16.

    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'oauth2-connection-create.ps1' $skysyncServer=http://localhost:9090/
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
	[string]$skysyncAdminUser = "admin",
	[string]$skysyncAdminUserPassword = 'P@ssword',
	$runFile = "..\run-file.csv",
	$connectionTemplateFile = "..\connection-template.json"
)

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

function get-msft-access-tokens($uri, $username, $password) {
	$body = @{grant_type='password'
			client_id='b90d8e05-c7af-469c-b56f-02a38b792f49'
			client_secret='.]|!!@^|+@!;!;>>^{/;s};^?;2^^:)!;V*&?u_-|@A[@#?_(*$'
			scope='openid'
			resource=$uri
			username=$username
			password=$password}

	$authResponse = Invoke-RestMethod -Uri "https://login.microsoftonline.com/common/oauth2/token" -Method Post -ContentType "application/x-www-form-urlencoded" -Body $body
	return $authResponse
}

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$connections = Import-Csv -Path $runFile # List of users for connection creation
$connectionTemplate = Get-Content -Path $connectionTemplateFile -Raw | ConvertFrom-Json #Common Job Template

$connectionNameTemplate = "<uri> - <user>"

foreach ($user in $connections)
{
	try {
		$connection = $connectionTemplate
		$connectionName = $connectionNameTemplate -replace "<user>", $user.username
		$connectionName = $connectionName -replace "<uri>", $user.uri
		Write-Host "Processing:" $connectionName
		
		$connection.name = $connectionName
		$connection.platform.id = $user.platform_id
		$connection.auth.uri = $user.uri
		$connection.auth.domain = $user.uri
		$connection.auth.username = $user.username

		$connectionUri = ([System.Uri]$user.uri)
		$resourceUri = $connectionUri.GetLeftPart([System.UriPartial]'Authority')

		#lookup the user info from msft
        $msftAccessToken = get-msft-access-tokens $resourceUri $user.username $user.password
        
        $resourceToken = [PSCustomObject]@{
			$connectionUri.Authority = [PSCustomObject]@{
				token = $msftAccessToken.access_token }
		}

		$connection.auth.refresh_token = $msftAccessToken.refresh_token
		$connection.auth.resource_tokens = $resourceToken

		$connection = $connection | ConvertTo-Json -Depth 10

		Write-Host $connection

		$accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
		$authHeader = get-request-header $accessToken

		$createConnectionMethod = $skysyncServer + "v1/connections/"
		$createConnectionResponse = Invoke-RestMethod $createConnectionMethod -Headers $authHeader -Method Post -ContentType 'application/json; charset=utf-8' -Body $connection

		Write-Host "Successfully created connection:" $createConnectionResponse.connection.id "|" $createConnectionResponse.connection.name
		Write-Host ""
	}
	catch {
		$exMsg = $_.Exception.Message
		$line = $_.Exception.InvocationInfo.ScriptLineNumber
		$st = $_.ScriptStackTrace
		Write-Host "An error occurred while creating the connection: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
		return
	}
}
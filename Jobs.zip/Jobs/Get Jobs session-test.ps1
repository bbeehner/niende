Param(
	[string]$skysyncServer = "https://customer.go.skysync.com/",
	[string]$skysyncAdminUser = "adminUser",
	[string]$skysyncAdminUserPassword =	"Password!"
)

Clear-Host
Push-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $accessRequestBody = @{
        grant_type = "password"
        scope = "offline_access profile roles"
        resource = $skysyncServer
        username = $skysyncAdminUser
        password = $skysyncAdminUserPassword
    }
    $accessRequestUrl = $skysyncServer + "connect/token"
    $accessRequestResult = Invoke-WebRequest -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody -SessionVariable 'ssrequest'
   
    $cookie = $accessRequestResult.Headers.Get_Item("Set-Cookie")
    $accessToken = (ConvertFrom-Json $accessRequestResult.Content).access_token

    $ssrequest.Headers.Add("Authorization","Bearer $accessToken")
    $ssrequest.Headers.Add("Accept","application/json")
    $ssrequest.Headers.Add("Cookie","$cookie")



$createJobMethod = $skysyncServer + "v1/jobs?fields=all"



$createJobResponse = Invoke-WebRequest $createJobMethod -WebSession $ssrequest 




#(ConvertFrom-Json $createJobResponse.Content).discriminator
#$tst = $createJobResponse.Content | ConvertFrom-Json
#$tst

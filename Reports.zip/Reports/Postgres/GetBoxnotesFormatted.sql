
-- first job should exclude boxnotes
-- use this to get a list of all boxnotes that were excluded
-- then create a job for each boxnote location, include boxnote extension & exlude folders

-- query to get all boxnote location and massage data for job creation
SELECT DISTINCT
sj.Name,
sj.JobId,
tj.SourceAccountID as source_id, -- this is what you used to create the job, might need to be username 
tj.DestinationAccountUserName as destination_username,
replace(ti.SourcePath,ti.SourceName,'') as source_path,
'/BoxMigratedData' || replace(ti.SourcePath,ti.SourceName,'') as destination_path -- add a /BoxMigratedData on the destination
FROM TransferItems ti
inner join ScheduledJobs sj on sj.ID = ti.TransferID
inner join TransferJobs tj on tj.ID = sj.ID
WHERE sj.CategoryID in (2,3,4,5,6,7,8,9,10,11) -- All User Jobs Categories
and
ItemStatus = 5 and ti.Extension = '.boxnote'

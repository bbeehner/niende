-- Report on Folder Permissions 
SELECT 
sj.jobid
,sj.name job_name
,tj.sourcepath job_source_path
,ti.sourcepath item_path
,tip.permissioncount
FROM transferitempermissions tip
INNER JOIN transferitems ti
ON ti.id = tip.transferitemid
INNER JOIN scheduledjobs sj
ON ti.transferid = sj.id
INNER JOIN transferjobs tj
ON sj.jobid = tj.jobid
WHERE 
ti.iscontainer = 1
AND sj.isactive = 1
--and sj.jobid = ''
--and sj.categoryid=2
ORDER BY sj.id, tip.permissioncount DESC
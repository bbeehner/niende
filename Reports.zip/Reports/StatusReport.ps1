<#
.DESCRIPTION
    Exports Status Report Headers:
        JobName, SourceIdentifier, DetinationIdentifier, SourceItemsIdentified, ItemsTransferred, ItemsExcludedByPolicies, ItemsFlaggedForReview, ItemsRetrying
	 
.INPUTS
    DryvIQServer               =   DryvIQ server host and port
    DryvIQAdminUser            =   DryvIQ admin username
    DryvIQAdminUserPassword    =   DryvIQ admin user password
    categoryId                  =   Comma Delimited list of job categories. If unspecified, all jobs are included.

.OUTPUTS
    CSV file in relative directory
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $DryvIQServer must use machine name and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'StatusReport.ps1' $DryvIQServer=http://localhost:9090/ $categoryId="2,3"
#>

Param(
    [string]$DryvIQServer           = "http://localhost:9090/",
    [string]$DryvIQAdminUser        = "admin",
    [string]$DryvIQAdminUserPasswrd = 'P@ssword',
    [string]$categoryId             = "2"
)

#region Options/Clean up Parameters

$DryvIQServer           = $DryvIQServer.TrimEnd("/").TrimEnd("\").Trim() # Remove trailing slash for consistency across scripts
$DryvIQAdminUser        = $DryvIQAdminUser.Trim()
$DryvIQAdminUserPasswrd = $DryvIQAdminUserPasswrd.Trim()
$categoryId             = $categoryId.Trim()
$VerbosePreference      = "SilentlyContinue" # This should be "Continue" to show or "SilentlyContinue" to hide
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 # Negotiate TLS1.2 for to support https requests

#endregion

#region Functions

function NullString($objectToCheck) {
    if ($objectToCheck -eq $null) {
        return ""
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return ""
    }

    if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
        return ""
    }

    return $objectToCheck
}

function GetSourceItemsIdentifiedCount($transferStats) {
    return ([int](NullString $transferStats.success.source.files)) + ([int](NullString $transferStats.success.source.folders)) +
	([int](NullString $transferStats.skipped.source.files)) + ([int](NullString $transferStats.skipped.source.folders)) +
	([int](NullString $transferStats.processed.source.files)) + ([int](NullString $transferStats.processed.source.folders)) +
	([int](NullString $transferStats.remediation.source.files)) + ([int](NullString $transferStats.remediation.source.folders)) +
	([int](NullString $transferStats.retry.source.files)) + ([int](NullString $transferStats.retry.source.folders)) +
	([int](NullString $transferStats.pending.source.files)) + ([int](NullString $transferStats.pending.source.folders))
}

function GetSourceItemsTransferredCount($transferStats) {
    return ([int](NullString $transferStats.success.source.files)) + ([int](NullString $transferStats.success.source.folders)) +
	([int](NullString $transferStats.processed.source.files)) + ([int](NullString $transferStats.processed.source.folders))
}

function GetItemsExcludedByPoliciesCount($transferStats) {
    return ([int](NullString $transferStats.skipped.source.files)) + ([int](NullString $transferStats.skipped.source.folders))
}

function GetItemsFailedToTransferCount($transferStats) {
    return ([int](NullString $transferStats.remediation.source.files)) + ([int](NullString $transferStats.remediation.source.folders))
}

function GetItemsInRetryCount($transferStats) {
    return ([int](NullString $transferStats.retry.source.files)) + ([int](NullString $transferStats.retry.source.folders))
}

function GetSourceIdentifier($transferStats) {
    if ($job.transfer.source.impersonate_as.name) {return $job.transfer.source.impersonate_as.name}
    if ($job.transfer.source.impersonate_as.username) {return $job.transfer.source.impersonate_as.username}
    if ($job.transfer.source.impersonate_as.email) {return $job.transfer.source.impersonate_as.email}
    if ($job.transfer.source.impersonate_as.id) {return $job.transfer.source.impersonate_as.id}

    if ($job.transfer.source.target.item.root) {return $job.transfer.source.target.item.name}
    return $job.transfer.source.target.item.parent.name + "/" + $job.transfer.source.target.item.name
}

function GetDestinationIdentifier($job) {
    if ($job.transfer.destination.impersonate_as.id) {return $job.transfer.destination.impersonate_as.id}
    if ($job.transfer.destination.impersonate_as.email) {return $job.transfer.destination.impersonate_as.email}
    if ($job.transfer.destination.impersonate_as.username) {return $job.transfer.destination.impersonate_as.username}
    if ($job.transfer.destination.impersonate_as.name) {return $job.transfer.destination.impersonate_as.name}

    if ($job.transfer.source.target.item.root) {return $job.transfer.source.target.item.name}
    return $job.transfer.source.target.item.parent.name + "/" + $job.transfer.source.target.item.name
}

function RetrieveJobsToExport($categoryId) {


    $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
    $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken

    $offset     = 0
    $maxItemsPerRequest = 1000
    $totalJobs  = @()
    $hasMore    = $true

    while ($hasMore)
    {
        #retrieve all jobs to export
        $jobsRequestMethod  = $DryvIQServer + "/v1/jobs?fields=name,transfer.source,transfer.destination&limit=$maxItemsPerRequest&offset=$offset&job_categories=$categoryId"
        $jobsResponse       = Invoke-RestMethod $jobsRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'  

        $totalJobs          += $jobsResponse.jobs
        $hasMore            = $jobsResponse.meta.has_more

        if($hasMore) #make additional job requests as necessary
        {
            $offset += $maxItemsPerRequest
        }
    }

    return $totalJobs
}

function Set-DryvIQRequestHeader {
    [CmdletBinding()]
    [OutputType([Hashtable])]
	param ( 
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][string]$AccessToken 
    )
    `
	$RequestHeader = @{
		Authorization = "Bearer " + $AccessToken
		Accept = "application/json"
	}
    return $RequestHeader
    
<#
    .SYNOPSIS
    This sets the Bearer token for DryvIQ API calls.

    .DESCRIPTION
    This sets the Bearer token for DryvIQ API calls. This uses the AccessToken generated by the Get-DryvIQAccessToken function

    .OUTPUTS
    System.Hashtable. This returns a header in hashtable format for use in DryvIQ API calls

    .INPUTS
    This cmdlet can accept the $AccessToken via a pipeline. 

    .PARAMETER AccessToken
    This is the AccessToken generated by the Get-DryvIQAccessToken function

    .EXAMPLE
    $DryvIQServer              = "http://localhost:9090"
    $DryvIQAdminUser           = "Admin"
    $DryvIQAdminUserPasswrd    = "VeryStrongPassword"

    $RequestHeader = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer `
                                            -DryvIQAdminUser $DryvIQAdminUser `
                                            -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd | Set-DryvIQRequestHeader

    PS C:\>  $RequestHeader

    Name                           Value
    ----                           -----
    Accept                         application/json
    Authorization                  Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4... (token)                            

    .EXAMPLE
    PS C:\>  $AccessToken = Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"
    PS C:\>  $Header =   Set-DryvIQRequestHeader -AccessToken $AccessToken

    
    PS C:\>  $Header

    Name                           Value
    ----                           -----
    Accept                         application/json
    Authorization                  Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4... (token)     
#>

}

function Get-DryvIQAccessToken {
    [CmdletBinding()]
    [OutputType([String])]
    param (
        [Parameter(Mandatory=$true)][string]$DryvIQServer,    
        [Parameter(Mandatory=$true)][string]$DryvIQAdminUser,
        [Parameter(Mandatory=$true)][string]$DryvIQAdminUserPasswrd
    )


    $DryvIQAdminUser           = $DryvIQAdminUser.Trim()
    $DryvIQAdminUserPasswrd    = $DryvIQAdminUserPasswrd.Trim()
    $DryvIQServer              = ($DryvIQServer.TrimEnd("/")) + "/connect/token"


    $creds = @{
        username                = $DryvIQAdminUser
        password                = $DryvIQAdminUserPasswrd
        grant_type              = "password"
        scope                   = "offline_access profile roles"
    }

    try {

        Write-Host "`r`nTrying to connect to $($DryvIQServer)`r`n" -ForegroundColor Cyan
        $response = Invoke-RestMethod -Uri "$DryvIQServer" -Method 'Post' -Body $creds 
        $AccessToken = $response.access_token;
        if ($AccessToken){
            Write-Host "Successfully obtained token from $($DryvIQServer)`r`n" -ForegroundColor Green
            return $AccessToken;
        }
        else {
            Write-Host "Error obtaining token from $($DryvIQServer). Please check the URL, Username and/or Password.`r`n" -ForegroundColor Red
            exit
        }
    }
    catch {

        Write-Host "Error obtaining token from $($DryvIQServer). Please check the URL, Username and/or Password.`r`n" -ForegroundColor Red
        exit
    }

<#
    .SYNOPSIS
    This gets an authentication token.

    .DESCRIPTION
    This gets an authentication token, which you need when making API calls.

    .OUTPUTS
    A bearer token in a string format. You can pipe this value into Set-DryvIQRequestHeader.

    .PARAMETER DryvIQServer
    This is the DryvIQ server. Typically this is set to "http://localhost:9090"
.
    .PARAMETER DryvIQAdminUser
    This is the admin user for the DryvIQ server.

    .PARAMETER DryvIQAdminUserPasswrd
    This is the password for the admin user of the DryvIQ server.

    .EXAMPLE
    PS C:\>  Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"

    Trying to connect to http://localhost:9090/connect/token
    Successfully obtained token from http://localhost:9090/connect/token

    eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4ZmE..... (token)

        .EXAMPLE
    PS C:\>  $AccessToken = Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"

    Trying to connect to http://localhost:9090/connect/token
    Successfully obtained token from http://localhost:9090/connect/token

    PS C:\>  $AccessToken

    eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4ZmE..... (token)
#>

}

function Start-DryvIQTranscript {

    try { Stop-Transcript } catch {}
    $ScriptPath = $($MyInvocation.PSScriptRoot)
    New-Item -Path $ScriptPath -Name "logs" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    $logname = "log-$((Split-Path $MyInvocation.PSCommandPath -Leaf).Replace('.ps1','')).$(Get-Date -Format yyyy-MM-dd)"
    Start-Transcript -path "$ScriptPath\logs\$($logname).txt" -append
    Write-Host "`r`n"
    
}

function Stop-DryvIQTranscript {

    Write-Host "`r`n `r`n"
    try { Stop-Transcript } catch {}

}

#endregion

Start-DryvIQTranscript

try {
    $jobsToExport = RetrieveJobsToExport $categoryId
 
	
    Write-Host "Identified" $jobsToExport.count "jobs to Export."

    $jobReport = @() 
    foreach ($job in $jobsToExport)
    {
        Write-Host "Processing Job" $job.name

        $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
        $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken
        
        $reportEntry    = New-Object System.Object
        $sourceIdentifier       = GetSourceIdentifier $job
        $destinationIdentifier  = GetDestinationIdentifier $job

        $jobTransferStatsMethod     = $DryvIQServer + "/v1/transfers/$($job.id)/stats?fields=by_status"
        $jobTransferStatsResponse   = Invoke-RestMethod $jobTransferStatsMethod -Headers $authHeader #-Proxy 'http://localhost:8888'

         #Use JavaScriptSerializer to support large response payloads
        #if($jobTransferStatsResponse -is [System.string])
        #{
        #    [void][System.Reflection.Assembly]::LoadWithPartialName("System.Web.Extensions")        
        #    $jsonserial= New-Object -TypeName System.Web.Script.Serialization.JavaScriptSerializer 
        #    $jsonserial.MaxJsonLength =  [int]::MaxValue
        #    $jsonserial.RecursionLimit = 99   
        #    $transferStatsResponse = $jsonserial.DeserializeObject($jobTransferStatsResponse)
        #}
		
        #else { 
		$transferStatsResponse = $jobTransferStatsResponse 
		#}

		$transferStats              = $transferStatsResponse.transfer_stats.by_status
        $numSourceItemsIdentified   = GetSourceItemsIdentifiedCount $transferStats
        $numItemsTransferred        = GetSourceItemsTransferredCount $transferStats
		$numItemsExcluded           = GetItemsExcludedByPoliciesCount $transferStats
        $numItemsFailed             = GetItemsFailedToTransferCount $transferStats
        $numItemsRetry              = GetItemsInRetryCount $transferStats
		
		$reportEntry | Add-Member -Type NoteProperty -Name JobName -Value (NullString $job.name) #can be optionally exported for troubleshooting
        $reportEntry | Add-Member -Type NoteProperty -Name SourceIdentifier -Value (NullString $sourceIdentifier)
        $reportEntry | Add-Member -Type NoteProperty -Name DestinationIdentifier -Value (NullString $destinationIdentifier)
        $reportEntry | Add-Member -Type NoteProperty -Name SourceItemsIdentified -Value ($numSourceItemsIdentified)
        $reportEntry | Add-Member -Type NoteProperty -Name ItemsTransferred -Value ($numItemsTransferred)
        $reportEntry | Add-Member -Type NoteProperty -Name ItemsExcludedByPolicies -Value ($numItemsExcluded)
        $reportEntry | Add-Member -Type NoteProperty -Name ItemsFlaggedForReview -Value ($numItemsFailed)
        $reportEntry | Add-Member -Type NoteProperty -Name ItemsRetrying -Value ($numItemsRetry)
        $jobReport += $reportEntry
    }

    #Export to CSV
    [string]$reportDate = (Get-Date).ToString('yyyy-MM-dd')
    $jobReport | Select-Object -Property JobName, SourceIdentifier, DestinationIdentifier, SourceItemsIdentified, ItemsTransferred, ItemsExcludedByPolicies, ItemsFlaggedForReview, ItemsRetrying | Export-Csv "StatusReport_category_$categoryId`_$reportDate.csv" -NoTypeInformation

    Write-Host "Status Report Successfully Created."
}
catch{
    $exMsg  = $_.Exception.Message
    $line   = $_.Exception.InvocationInfo.ScriptLineNumber
    $st     = $_.ScriptStackTrace
    Write-Host "An error occurred while processing the Status report: ${exMsg}. Line ${line}. ${st}. $($error[0])." -ForegroundColor Red
    return
}

Stop-DryvIQTranscript
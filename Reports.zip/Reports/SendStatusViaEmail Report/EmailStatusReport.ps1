<#

# Step 1 Run this before you try to run SSDashboard.ps1
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Step 2 Run this to install the module
Install-Module UniversalDashboard.Community

#>


function IsNull($objectToCheck) {
    if ($objectToCheck -eq $null) {
        return $true
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return $true
    }

    if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
        return $true
    }

    return $false
}

function NullString($objectToCheck) {
    if ($objectToCheck -eq $null) {
        return ""
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return ""
    }

    if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
        return ""
    }

    return $objectToCheck
}

function getEpochDateTZ([long]$seconds, [int]$timeZoneOffset,[string]$format) {    
    if (IsNull $seconds)
    {
        return ""
    }

    $epoch = [datetime]"1/1/1970"

    $outDate = $epoch.AddSeconds($seconds)
    
    if (IsNull $seconds -eq $false)
    {
        $outDate.AddHours($timeZoneOffset)
    }

    if (NullString $format -ne "")
    {
        return $outDate.ToString($format)
    }

    return $outDate.ToString("MM/dd/yyyy HH:mm")
}

function formatFloat([double]$inVal, [int]$decimalPlaces, [string]$timeUnit) {
    if (IsNull $inVal)
    {
        return ""
    }

    if (IsNull $decimalPlaces)
    {
        $decimalPlaces = 2
    }

    $retVal = [math]::Round($inVal,$decimalPlaces)

    $retString = $retVal.ToString()

    if ((IsNull $timeUnit) -eq $false)
    {
        $retString = $retString.ToString() + " " + $timeUnit
    }

    return $retString
}

function getGBPerHour([double]$duration, [string]$durationUnit, [double]$destGB, [int]$decimalPlaces) {
    
    if ((IsNull $duration) -or (IsNull $durationUnit) -or (IsNull $destGB))
    {
        return ""
    }
    
    if (IsNull $decimalPlaces)
    {
        $decimalPlaces = 2
    }

    $hours = 0
    
    switch ($durationUnit)
    {
        "s" { $hours = $duration / 60.0 / 60.0 }
        "m" { $hours = $duration / 60.0 }
        "h" { $hours = $duration }
        "d" { $hours = $duration * 24.0 }
    }

    $gbPerHour = "0.00"

    if ($hours -gt 0 -and $destGB -gt 0)
    {
        $floatGbPerHour = $destGB / $hours

        $floatGbPerHour = [math]::Round($floatGbPerHour,$decimalPlaces)

        $gbPerHour = $floatGbPerHour.ToString()        
    }

    return $gbPerHour

}

function datediff ($lastActive) {
        $endDate = Get-Date
        $diff =  New-TimeSpan -Start $endDate -End $lastActive
       # return  $diff.ToString("HH:mm:s")
        
       return "{0:hh\:mm\:ss}" -f ([TimeSpan] $diff)
    }

function Get-JobHistory { 
    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody

    $accessToken = $accessRequestResult.access_token
    $authHeader = @{"Authorization"="Bearer $accessToken";"Content-Type"="application/json; charset=utf-8";}
    $hasMore = $true
    while ($hasMore)
    {
        
        $endPoint ="$url/jobs?fields=all&kind=$kind&simulation_mode=0&job_categories=$searchCategoryID&limit=$limit&offset=$offset"
        $accountsResponse = Invoke-RestMethod $endPoint -Headers $authHeader #-Proxy 'http://localhost:8888
		
        $global:totalJobs += $accountsResponse.jobs
        $hasMore = $accountsResponse.meta.has_more

        if($hasMore) #make additional job requests as necessary
        {
            $offset += 1000
        }
    }
    $active = $false 
	$jobtotal = $global:totalJobs.count

	Write-Host "Found $jobtotal to process..."

    foreach ($job in $global:totalJobs)
    {
        $jobStatus = New-Object System.Object
 		$jobStatus | Add-Member -Type NoteProperty -Name Name -Value (NullString $job.name)
        $jobStatus | Add-Member -Type NoteProperty -Name Discriminator -Value (NullString $job.discriminator)

        if ($active)
        {
            if (-NOT (IsNull $job.execution.status))
            {
                $jobStatus | Add-Member -Type NoteProperty -Name Status -Value (NullString $job.execution.status)
                $jobStatus | Add-Member -Type NoteProperty -Name RunPhase -Value (NullString $job.execution.phase)
                $jobStatus | Add-Member -Type NoteProperty -Name RunStatus -Value (NullString $job.execution.status)
				$jobStatus | Add-Member -Type NoteProperty -Name Runs -Value (NullString $job.stop_policy.executions )
				$jobStatus | Add-Member -Type NoteProperty -Name Last_Run -Value (getEpochDateTZ $job.previous_execution.end_time -4)
                $jobStatus | Add-Member -Type NoteProperty -Name Success -Value (NullString $job.transfer.stats.success_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Revised -Value (NullString $job.transfer.stats.processed_items )#processed_items
                $jobStatus | Add-Member -Type NoteProperty -Name Retry -Value (NullString $job.transfer.stats.retry_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Flagged -Value (NullString $job.transfer.stats.remediation_items )

                $global:jobStatusArray += $jobStatus
            }
        }
        else
        {

            if (IsNull $job.execution.status)
            {
                $jobStatus | Add-Member -Type NoteProperty -Name Status -Value "idle"
                $jobStatus | Add-Member -Type NoteProperty -Name RunPhase -Value (NullString $job.previous_execution.phase)
                $jobStatus | Add-Member -Type NoteProperty -Name RunStatus -Value (NullString $job.previous_execution.status)
				$jobStatus | Add-Member -Type NoteProperty -Name Last_Run -Value (getEpochDateTZ $job.previous_execution.end_time -4)
				#(getEpochDateTZ $job.previous_execution.start_time -4)
				$jobStatus | Add-Member -Type NoteProperty -Name Runs -Value (NullString $job.stop_policy.executions )
                $jobStatus | Add-Member -Type NoteProperty -Name Success -Value (NullString $job.transfer.stats.success_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Revised -Value (NullString $job.transfer.stats.processed_items )#processed_items
                $jobStatus | Add-Member -Type NoteProperty -Name Retry -Value (NullString $job.transfer.stats.retry_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Flagged -Value (NullString $job.transfer.stats.remediation_items )
            }
            else
            {
                $jobStatus | Add-Member -Type NoteProperty -Name Status -Value (NullString $job.execution.status)
                $jobStatus | Add-Member -Type NoteProperty -Name RunPhase -Value (NullString $job.execution.phase)
                $jobStatus | Add-Member -Type NoteProperty -Name RunStatus -Value (NullString $job.execution.status)
				$jobStatus | Add-Member -Type NoteProperty -Name Last_Run -Value (getEpochDateTZ $job.previous_execution.end_time -4)
				$jobStatus | Add-Member -Type NoteProperty -Name Runs -Value (NullString $job.stop_policy.executions )
                $jobStatus | Add-Member -Type NoteProperty -Name Success -Value (NullString $job.transfer.stats.success_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Revised -Value (NullString $job.transfer.stats.processed_items )#processed_items
                $jobStatus | Add-Member -Type NoteProperty -Name Retry -Value (NullString $job.transfer.stats.retry_items )
                $jobStatus | Add-Member -Type NoteProperty -Name Flagged -Value (NullString $job.transfer.stats.remediation_items )

            }
            $global:jobStatusArray += $jobStatus
        }
    
    }
	Write-Host "Finished processing $jobtotal Jobs"

    #return $global:jobStatusArray  | Export-Csv $csvReportFile -NoTypeInformation -Encoding UTF8
	return $global:jobStatusArray  | Export-Excel $StatusReportFile -AutoSize -AutoFilter -Title $reportTitle -Style $styles

}

function GetLatestErrorMessage($jobId) {

    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody

    $accessToken = $accessRequestResult.access_token
    $authHeader = @{"Authorization"="Bearer $accessToken";"Content-Type"="application/json; charset=utf-8";}
    

    $requestMethod = $url + "/transfers/auditing?jobs=$jobId&level=error&sort=recorded_on%20DESC&fields=message&offset=0&limit=1"
    $response = Invoke-RestMethod $requestMethod -Headers $authHeader #-Proxy 'http://localhost:8888'

    return $response.item[0].message
}

function Get-JobFailures {

    $accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody

    $accessToken = $accessRequestResult.access_token
    $authHeader = @{"Authorization"="Bearer $accessToken";"Content-Type"="application/json; charset=utf-8";}
    
    $maxJobsPerRequest = 1000
    $offset = 0

    $hasMore = $true
    while ($hasMore){

        if ($searchType -eq "0"){
            $jobsRequestMethod = $url + "/jobs?job_categories=$searchCategoryID&active=1&status=failed-to-start&fields=id,name&limit=$maxJobsPerRequest&offset=$offset"
        }
        else {
            $jobsRequestMethod = $url + "/jobs?q=$searchCategoryID&active=1&status=failed-to-start&fields=id,name&limit=$maxJobsPerRequest&offset=$offset"
        }

        $jobsResponse = Invoke-RestMethod $jobsRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

        $global:totalJobs += $jobsResponse.jobs
        $hasMore = $jobsResponse.meta.has_more

        if($hasMore) #make additional job requests as necessary
        {
            $offset += 1000
        }
	}

   $jobtotal = $global:totalJobs.count
    Write-Host "Found $jobtotal to process..."

    foreach ($job in $global:totalJobs)
    {
		
        $reportEntry = New-Object System.Object

		$latestErrorMessage = GetLatestErrorMessage $job.id
		
		$reportEntry | Add-Member -Type NoteProperty -Name JobId -Value (NullString $job.id)
		$reportEntry | Add-Member -Type NoteProperty -Name JobName -Value (NullString $job.name) 
        $reportEntry | Add-Member -Type NoteProperty -Name LatestErrorMessage -Value ($latestErrorMessage)
   
        $global:jobReport += $reportEntry
    }
	Write-Host "Finished processing $jobtotal Jobs"
    return $global:jobReport | Export-Csv $ErrorListFile -NoTypeInformation -Encoding UTF8

}

function send_email {
	$mailmessage = New-Object System.Net.Mail.MailMessage
	$mailmessage.from = ($EmailFrom)
	$mailmessage.To.add($EmailTo)
	$mailmessage.Subject = $EmailSubject
	$mailmessage.Body = $emailbody
	 
	$attachment = New-Object System.Net.Mail.Attachment($emailattachment)
	$mailmessage.Attachments.Add($attachment)

	#$mailmessage.IsBodyHTML = $true
	$SMTPClient = New-Object System.Net.Mail.SmtpClient($SMTPServer, $SMTPPort)
	$SMTPClient.UseDefaultCredentials = $false
	$SMTPClient.EnableSSL = $true
	$SMTPClient.Credentials = New-Object System.Net.NetworkCredential($SMTPAuthUsername, $SMTPAuthPassword)
	$SMTPClient.Send($mailmessage)
}


Try {
	try {Install-Module ImportExcel} catch {throw ; return}
	#Push-Location	
	$root = Get-Location
	$file_path = "Files"
	$log_path = "Logs"
	if (!(test-path -path $file_path)) {new-item -path $file_path -itemtype directory}
	if (!(test-path -path $log_path)) {new-item -path $log_path -itemtype directory}

	$styleParams = @{
		FontSize = 12  
		Bold = $true
		}
	$styles = $(
    New-ExcelStyle -BackgroundColor LightBlue -FontSize 18 -Bold -Range "A1:K1" -HorizontalAlignment Center -Merge
    New-ExcelStyle -BackgroundColor LightGray -Range "A2:K2" @styleParams
    # cell level options
    # New-ExcelStyle -BackgroundColor Red -Range "B12" @styleParams
	)

    $reportDate = (Get-Date).ToString('yyyyMMdd_hhmmss')
	$reportDate_pretty = (Get-Date).ToString('dddd MM/dd/yyyy HH:mm')

	$reportTitle = "Automated SkySync Job Status Report - $reportDate_pretty"
	$transscriptPath = "$root\Logs\ExportRun_" + $reportDate + ".txt"	
    $csvReportFile = "$root\Files\Status_ " + $reportDate + ".csv"
	$StatusReportFile = "$root\Files\Status_ " + $reportDate + ".xlsx"
    $ErrorListFile = "$root\Files\ErrorList_" + $reportDate + ".csv"
	$startTime = "{0:G}" -f (Get-date)
	Start-Transcript -Path $transscriptPath
	Write-Host "*** Script started on $startTime ***" -f Blue -b DarkYellow
	#Email stuff
    $EmailFrom = "SkySync.Export@gmail.com"
    #$EmailFrom = "mcislo@skysync.com"
#	Joshua.feliciano@spglobal.com,Thomas.murrow@spglobal.com,dharmesh.pariawala@spglobal.com,animeshnigam@spglobal.com,box-migration@spglobal.com,Azhar.uddin@spglobal.com,todd.chaney@spglobal.com,eric.gonzales@spglobal.com
	
    $EmailTo = "mcislo@skysync.com,bmichel@skysync.com"
    $EmailSubject = "Automated Export File attached Executed at $reportDate_pretty"  
    $SMTPAuthUsername = "SkySync.Export@gmail.com"
    $SMTPAuthPassword = "Skyme1100!123" 
    $SMTPServer = "smtp.gmail.com"
    $SMTPPort = "587"
 
    $emailattachment = $StatusReportFile
    $emailbody = "Automated Export File attached: Executed at $reportDate_pretty"

	#Array Stuff
    $global:jobStatusArray = @()
    $global:totalJobs = @()
    $global:jobReport = @()
    $offset = 0 # $config["offset"]
    $limit = 1000 # $config["limit"]
    $kind = "transfer" #$config["kind"]
	
	#Category ID to send email on
	$searchCategoryID = "-1,18" # $filter[1]

	# Normal Connection stuff
    $baseurl = "http://localhost:9090"
    #$baseurl = "http://18.119.110.129:9090"
    $url = $baseurl.TrimEnd("/") + "/v1" 
    $user = 'admin'
    $pwd = "Skyme1100!"


    $accessRequestUrl = $baseurl + "/connect/token"
    $accessRequestBody = @{
    grant_type = "password"
    scope = "offline_access profile roles"
    resource = $baseurl
    username = $user
    password = $pwd
    }
	

	
    Write-Host "Getting job Status"
	
    Get-JobHistory
		
    #Write-Host "Getting job Failures"
    #Get-JobFailures
    Write-Host "Done generating report..."

    Write-Host "Send Email"
    send_email
    Write-Host "Sending email complete"
	$endTime = "{0:G}" -f (Get-date)
	Write-Host "*** Script finished on $endTime ***" -f Blue -b DarkYellow
	Write-Host "Time elapsed: $(New-Timespan $startTime $endTime)" -f White -b DarkRed

	Stop-Transcript


	}
	
catch{
		$exMsg = $_.Exception.Message
		$line = $_.Exception.InvocationInfo.ScriptLineNumber
		$st = $_.ScriptStackTrace
		Write-Host "An error occurred while processing the report: ${exMsg}. Line ${line}. ${st}. $($error[0])." -ForegroundColor Red
		return
}
	#Stop-Transcript
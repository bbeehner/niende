select distinct(tal.message) message,
sj.name jobName, sj.jobid,ti.sourcepath, jc.name as wave
from transferauditlog tal
inner join transferitems ti
on tal.transferitemid = ti.id
inner join scheduledjobs sj
on tal.transferid = sj.id
inner join transferjobs tj
on sj.jobid = tj.jobid
inner join jobcategories jc
on sj.categoryid = jc.id
inner join transfersecuritymaps tsm
on tsm.transferid = sj.id
where tal.type = 4002
and tsm.mapper = 'unresolved' and tj.usesimulationmode = 0
--and tsm.sourceusername != sj.name --optional: filter out failed permissions to owners of files, but we impersonated the user on the destination
group by tal.message,sj.name,sj.jobid,ti.sourcepath,jc.name
order by wave,sj.jobid

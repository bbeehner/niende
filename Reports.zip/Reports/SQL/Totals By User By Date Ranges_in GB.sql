--
-- This report will give the "roll-up" of the content based off of date ranges
-- you can filter by Category ID (Business Unit Number) and/or Simulation Mode
-- 
DECLARE @NOWDATE AS BIGINT 
DECLARE @MINUS1YRFROMNOW AS BIGINT 
DECLARE @MINUS3YRFROMNOW AS BIGINT 
DECLARE @MINUS5YRFROMNOW AS BIGINT 
DECLARE @YEARCOUNT AS BIGINT = 31622400 -- 1 YEAR DIFFERENCE - 31622400

SET @NOWDATE = DATEDIFF(SECOND, '1970-01-01', GETDATE())
SET @MINUS1YRFROMNOW = @NOWDATE - @YEARCOUNT
SET @MINUS3YRFROMNOW = @NOWDATE - (3 * @YEARCOUNT)
SET @MINUS5YRFROMNOW = @NOWDATE - (5 * @YEARCOUNT)

SELECT 
		SJ.JOBID																		AS JOBID			
	   ,SJ.NAME																			AS JOBNAME
	   ,CAST(SUM(SOURCEBYTES)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))             AS [SOURCE_GB]
       ,CAST(SUM(SOURCESTORAGE)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))           AS [SOURCESTORAGE_GB]
       ,SUM(SOURCEITEMS)                                                                AS SOURCEITEMS
       ,SUM(SOURCEVERSIONS)                                                             AS SOURCEVERSIONS
       ,CAST(SUM(DESTINATIONBYTES)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))        AS [DESTINATION_GB]
       ,CAST(SUM(DESTINATIONSTORAGE)/ (1024.0 * 1024.0 * 1024.0) AS NUMERIC(10,4))      AS [DESTINATIONSTORAGE_GB]
       ,SUM(DESTINATIONITEMS)                                                           AS DESTINATIONITEMS
       ,SUM(DESTINATIONVERSIONS)                                                        AS DESTINATIONVERSIONS
       ,CASE WHEN (AGE>=@MINUS1YRFROMNOW)                                               THEN ' < 1 year old'
             WHEN ((AGE>=@MINUS3YRFROMNOW) AND (AGE<@MINUS1YRFROMNOW))                  THEN 'Between 1 AND 3 years old'
             WHEN ((AGE>=@MINUS5YRFROMNOW) AND (AGE<@MINUS3YRFROMNOW))                  THEN 'Between 3 AND 5 years old'
             WHEN ((AGE>=0) AND (AGE<@MINUS5YRFROMNOW))                                 THEN 'Greater than 5 years old' 
        END AS AGE
FROM TRANSFERAGEROLLUP TR WITH (NOLOCK)
        INNER JOIN TRANSFERJOBS TJ
          ON TJ.ID = TR.TRANSFERID
        INNER JOIN SCHEDULEDJOBS SJ
          ON SJ.JOBID = TJ.JOBID
WHERE TJ.USESIMULATIONMODE = 1 -- Simulation Mode ON or Off 
      AND SJ.ISACTIVE = 1 -- Just get the active jobs -- AND SJ.CategoryID IN (3, 4, 5) -- if we want to break down by category, otherwise we will pull back all jobs -
GROUP BY 
	  SJ.JOBID,
	  SJ.NAME,
      CASE WHEN (AGE>=@MINUS1YRFROMNOW)                                                 THEN ' < 1 year old'
           WHEN ((AGE>=@MINUS3YRFROMNOW) AND (AGE<@MINUS1YRFROMNOW))                    THEN 'Between 1 AND 3 years old'
           WHEN ((AGE>=@MINUS5YRFROMNOW) AND (AGE<@MINUS3YRFROMNOW))                    THEN 'Between 3 AND 5 years old'
           WHEN ((AGE>=0) AND (AGE<@MINUS5YRFROMNOW))                                   THEN 'Greater than 5 years old' 
        END
ORDER BY SJ.NAME, AGE;
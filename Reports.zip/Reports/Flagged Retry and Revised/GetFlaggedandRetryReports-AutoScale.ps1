<#
.DESCRIPTION
    Creates Flagged and Retry Reports, both per user CSV and merged CSV with all users.
.INPUTS
    DryvIQServer                =   DryvIQ server host and port
    DryvIQAdminUser             =   DryvIQ admin username
    DryvIQAdminUserPassword     =   DryvIQ admin user password
	searchCategory				=   This is the category or catergories separated by comma

.OUTPUTS
    None.
.NOTES
	Depending on desired report features, input parameters may differ. 
.EXAMPLE
    .\'GetFlaggedandRetryReports.ps1' $DryvIQServer "http://localhost:9090/"...
#>


Param(
    [string]$DryvIQServer           = "https://dryviq.io",
	[string]$searchCategory 		= "2"
)


#region Options/Clean up Parameters

Push-Location $PSScriptRoot
Clear-Host
$DryvIQServer           = $DryvIQServer.TrimEnd("/").TrimEnd("\").Trim() # Remove trailing slash for consistency across scripts
$DryvIQAdminUser        = $DryvIQAdminUser.Trim()
$DryvIQAdminUserPasswrd = $DryvIQAdminUserPasswrd.Trim() 
$VerbosePreference      = "SilentlyContinue" # This should be "Continue" to show or "SilentlyContinue" to hide
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 # Negotiate TLS1.2 for to support https requests

#endregion

#region Functions

function Start-DryvIQTranscript {

    try { Stop-Transcript } catch {}
    $ScriptPath = $($MyInvocation.PSScriptRoot)
    New-Item -Path $ScriptPath -Name "logs" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    $logname = "log-$((Split-Path $MyInvocation.PSCommandPath -Leaf).Replace('.ps1','')).$(Get-Date -Format yyyy-MM-dd)"
    Start-Transcript -path "$ScriptPath\logs\$($logname).txt" -append
    Write-Host "`r`n"
    
}

function Stop-DryvIQTranscript {

    Write-Host "`r`n `r`n"
    try { Stop-Transcript } catch {}

}

#endregion

Start-DryvIQTranscript


$totalJobs = @()
$offset = 0
$maxJobsPerRequest = 1000


try {  
    $hasMore = $true
    while ($hasMore)
    {
        #retrieve all jobs to export
		$jobsRequestMethod = $DryvIQServer + "/v1/jobs?job_categories=$searchCategory&fields=all&limit=$maxJobsPerRequest&offset=$offset"
		$jobsResponse = Invoke-RestMethod $jobsRequestMethod -Headers @{ Authorization="Bearer $idToken" }  #-Proxy 'http://localhost:8888
		$totalJobs += $jobsResponse.jobs
        $hasMore = $jobsResponse.meta.has_more

        if($hasMore) #make additional job requests as necessary
        {
            $offset += $maxJobsPerRequest
        }
    }

	Write-Host "Identified" $totalJobs.count "jobs."
}
	catch{
		$exMsg = $_.Exception.Message
		$line = $_.Exception.InvocationInfo.ScriptLineNumber
		$st = $_.ScriptStackTrace
		Write-Host "An error occurred while starting jobs: ${exMsg}. Line ${line}. ${st}. $($error[0])." -ForegroundColor Red
		return
	}

#region jobs
# use this for specific jobs
# $totaljobs = @(
# 	'e4baffad2c094a5bb6dcf7fc2d69d6fd',
# 	'76df97cf8f274a1a99d807f073a91f9d'	
# )
#endregion


foreach ($job in $totaljobs){

	# Generate the individual report name(s)
	$reportName  = $($job.name).Replace("@","_").Replace(":","_").Replace(".","_").Replace(" ","_").Replace("`'","_").Replace(">","_").Replace("/","_").Replace("&","_") + "-FlaggedRetryReport.csv"
	Write-Host "Processing report: $($reportName)"

	if ($job.transfer.stats.remediation_items -ge 1 -or $job.transfer.stats.retry_items -ge 1){

		Write-Host "$($job.id)"
		Write-Host "$($job.name)`r`n"

		Push-Location $PSScriptRoot
		New-Item -Path $PSScriptRoot -Name "Reports_FlaggedRetry" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
		$testPath = Test-Path -Path ".\Reports_FlaggedRetry\$($reportName)" -PathType Leaf
		if ($testPath -eq $false){

			# Types of calls we we can make
			# $iteminfo     = $DryvIQServer + "/v1/transfers/items.csv?jobs=$($job)" 
			# $flaggedinfo	= $DryvIQServer + "/v1/transfers/items.csv?jobs=$($job)&item_status=remediation&source_exists=1" 
			# $retryinfo	= $DryvIQServer + "/v1/transfers/items.csv?jobs=$($job)&item_status=retry&source_exists=1" 
			# $revisedinfo	= $DryvIQServer + "/v1/transfers/items.csv?jobs=$($job.id)&source_exists=1&item_status=processed" 

			$reportRequestMethod = $DryvIQServer + "/v1/transfers/items.csv?jobs=$($job.id)&source_exists=1&item_status=retry&item_status=remediation" 
			$reportResponse = Invoke-RestMethod $reportRequestMethod -Headers @{ Authorization="Bearer $idToken" }  #-Proxy 'http://localhost:8888
			$reportResponse | Out-File .\Reports_FlaggedRetry\$($reportName) -Encoding utf8 -Append
			Write-Host "Writing: \Reports_FlaggedRetry\$($reportName)"

			$check = Get-Content -Path ".\Reports_FlaggedRetry\$($reportName)" | Where-Object {$_.trim() -ne ""}
			$check = $check.Trim()
			Write-Host "Check COUNT IS: "
			$check.count
			if ($check.count -le 1 ){
					Remove-Item -Path ".\Reports_FlaggedRetry\$($reportName)"
			}
		}
		else
		{
			Write-Host "Skipping: \Reports_FlaggedRetry\$($reportName)"
		}

	}
	else {
		Write-Host "Skipping job because no Flagged or Retry items: \Reports_FlaggedRetry\$($reportName)"
	}

}

# Generate the merged report name and export
$mergedExportFile     = "$(Get-Date -format yyyy.MM.dd)-FlaggedRetryReport-Consolidated.csv"
New-Item -Path "$PSScriptRoot\Reports_FlaggedRetry" -Name "Merged" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
Get-ChildItem -Path "$PSScriptRoot\Reports_FlaggedRetry" -Filter *.csv | Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv "$PSScriptRoot\Reports_FlaggedRetry\merged\$mergedExportFile" -NoTypeInformation -Append

Stop-DryvIQTranscript
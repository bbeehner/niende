<#
.DESCRIPTION
    Retrieves permissions applied (or failed to apply) for each item.
        If categoryId is not specified, all jobs will be selected.
     
    Prerequisites:
        1. Source connection is an NFS connection
        2. DryvIQ environment is configured to show connection details
            appsettings.json entry: "connectors": { "hide_authentication_details": false }

.INPUTS
    DryvIQServer                =   Url to access DryvIQ environment.
    DryvIQAdminUser             =   Administrator username to access DryvIQ
    DryvIQAdminUserPassword     =   Administrator password to access DryvIQ
    categoryId                  =   Single category or comma delimited list of categoryIds. ex:  $categoryId = "1" OR $categoryId = "1,2,3"
    simulationMode              =   Flag to determine whether production/simulation results should be included
    maxBatchSize                =   Maximum amount of security maps to retrieve prior to looking up affected items
    startOffset                 =   Starting point to retrieve security maps.
    maxOffset                   =   Excel has  max row size of 1,048,576. Can set maxOffset to control file record count.
    LogFile                     =   Location to write output log file
    numberOfThreads             =   Controls # of concurrent threads to retrieve items
    DryvIQDatabaseName          =   DryvIQ Database name for database reporting
    sqlConnectionUsername       =   SQL Username. If empty, integrated security will be used
    sqlConnectionPassword       =   SQL Password
.OUTPUTS
    CSV File to path location
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $DryvIQServer to use fqdn/IP and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'PermissionInventoryReport.ps1' $DryvIQServer=http://DESKTOP-9BHVIFS:9090/ $categoryId=2
#>

Param(
    [string]$DryvIQServer           = "http://localhost:9090/",
    [string]$DryvIQAdminUser        = "admin",
    [string]$DryvIQAdminUserPasswrd = 'P@ssword',
    [string]$categoryId             = "",
    [bool]$simulationMode           = $false,
    [int]$maxBatchSize              = 500,
    $startOffset                    = 0,
    [string]$maxOffset              = "",
    $logfile                        = ".\PermissionInventoryReport $(get-date -f yyyy-MM-dd).csv",
    [int]$numberOfThreads           = 50,
    [string]$DryvIQDatabaseName    = "skysyncv4",
    [string]$sqlConnectionUsername  = "",
    [string]$sqlConnectionPassword  = ""
)

Get-ChildItem .\ | Unblock-File -Confirm:$false
. .\Invoke-Parallel.ps1

#region Options/Clean up Parameters

$DryvIQServer           = $DryvIQServer.TrimEnd("/").TrimEnd("\").Trim() # Remove trailing slash for consistency across scripts
$DryvIQAdminUser        = $DryvIQAdminUser.Trim()
$DryvIQAdminUserPasswrd = $DryvIQAdminUserPasswrd.Trim() 
$categoryId             = $categoryId.Trim()
$VerbosePreference      = "SilentlyContinue" # This should be "Continue" to show or "SilentlyContinue" to hide
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 # Negotiate TLS1.2 for to support https requests

#endregion

#region Functions

function NullString($objectToCheck) {
    if ($objectToCheck -eq $null) {
        return ""
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return ""
    }

    if ($objectToCheck -is [DBNull] -or $objectToCheck -is [System.Management.Automation.Language.NullString]) {
        return ""
    }

    return $objectToCheck
}

function GetConnectionSourceFolderPath($connectionId) {
    if ($connectionIdToPathMap.ContainsKey($connectionId)) {
        return $connectionIdToPathMap[$connectionId]
    } 
    else {
        #retrieve connection source path
        $connectionAuthRequestMethod = $DryvIQServer + "/v1/connections/" + $connectionId + "?fields=auth"
        $connectionAuthResponse = Invoke-RestMethod $connectionAuthRequestMethod -Headers $authHeader | ConvertTo-Json | ConvertFrom-Json  #decodes UNC Path
        
        $connectionIdToPathMap[$connectionId] = $connectionAuthResponse.connection.auth.uri

        return $connectionAuthResponse.connection.auth.uri
    }
}

function GetJobFolderPaths($transferId) {
    $source = ""
    $destination = ""

    if ($transferIdToSourcePathMap.ContainsKey($transferId)) {
        $source = $transferIdToSourcePathMap[$transferId]
    } 

    if ($transferIdToDestinationPathMap.ContainsKey($transferId)) {
        $destination = $transferIdToDestinationPathMap[$transferId]
    } 

    if ([string]::IsNullOrEmpty($source) -or [string]::IsNullOrEmpty($destination)) {

        $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
        $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken

        #retrieve job target paths
        $jobPathRequestMethod = $DryvIQServer + "/v1/jobs/" + $transferId + "?fields=transfer.source,transfer.destination"
        $jobPathResponse = Invoke-RestMethod $jobPathRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

        if ([string]::IsNullOrEmpty($source))
        {
            $source = BuildDirectoryPath $jobPathResponse.job.transfer.source.target
            $transferIdToSourcePathMap[$transferId] = $source
        }

        if ([string]::IsNullOrEmpty($destination))
        {
            $destination = BuildDirectoryPath $jobPathResponse.job.transfer.destination.target
            $transferIdToDestinationPathMap[$transferId] = $destination
        }
    }

    [pscustomobject]@{
        sourcePath = $source
        destinationPath = $destination
    }
}

function BuildDirectoryPath($target) {
    $sourcePath = "/"
    
    #Job targets connection root
    if ($null -eq $target) {
        return $sourcePath
    }

    [bool]$isRoot = $false
    $folderSegment = $target.item
    while (!$isRoot)
    {
        $sourcePath = "/" + $folderSegment.name + $sourcePath
        
        if ($null -ne $folderSegment.root) {
            $isRoot = $folderSegment.root
        }
        $folderSegment = $folderSegment.parent
    }

    return $sourcePath
}

function Set-DryvIQRequestHeader {
    [CmdletBinding()]
    [OutputType([Hashtable])]
	param ( 
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)][string]$AccessToken 
    )
    `
	$RequestHeader = @{
		Authorization = "Bearer " + $AccessToken
		Accept = "application/json"
	}
    return $RequestHeader
    
<#
    .SYNOPSIS
    This sets the Bearer token for DryvIQ API calls.

    .DESCRIPTION
    This sets the Bearer token for DryvIQ API calls. This uses the AccessToken generated by the Get-DryvIQAccessToken function

    .OUTPUTS
    System.Hashtable. This returns a header in hashtable format for use in DryvIQ API calls

    .INPUTS
    This cmdlet can accept the $AccessToken via a pipeline. 

    .PARAMETER AccessToken
    This is the AccessToken generated by the Get-DryvIQAccessToken function

    .EXAMPLE
    $DryvIQServer              = "http://localhost:9090"
    $DryvIQAdminUser           = "Admin"
    $DryvIQAdminUserPasswrd    = "VeryStrongPassword"

    $RequestHeader = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer `
                                            -DryvIQAdminUser $DryvIQAdminUser `
                                            -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd | Set-DryvIQRequestHeader

    PS C:\>  $RequestHeader

    Name                           Value
    ----                           -----
    Accept                         application/json
    Authorization                  Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4... (token)                            

    .EXAMPLE
    PS C:\>  $AccessToken = Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"
    PS C:\>  $Header =   Set-DryvIQRequestHeader -AccessToken $AccessToken

    
    PS C:\>  $Header

    Name                           Value
    ----                           -----
    Accept                         application/json
    Authorization                  Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4... (token)     
#>

}

function Get-DryvIQAccessToken {
    [CmdletBinding()]
    [OutputType([String])]
    param (
        [Parameter(Mandatory=$true)][string]$DryvIQServer,    
        [Parameter(Mandatory=$true)][string]$DryvIQAdminUser,
        [Parameter(Mandatory=$true)][string]$DryvIQAdminUserPasswrd
    )


    $DryvIQAdminUser           = $DryvIQAdminUser.Trim()
    $DryvIQAdminUserPasswrd    = $DryvIQAdminUserPasswrd.Trim()
    $DryvIQServer              = ($DryvIQServer.TrimEnd("/")) + "/connect/token"


    $creds = @{
        username                = $DryvIQAdminUser
        password                = $DryvIQAdminUserPasswrd
        grant_type              = "password"
        scope                   = "offline_access profile roles"
    }

    try
    {
        Write-Host "`r`nTrying to connect to $($DryvIQServer)`r`n" -ForegroundColor Cyan
        $response = Invoke-RestMethod -Uri "$DryvIQServer" -Method 'Post' -Body $creds 
        $AccessToken = $response.access_token;
        if ($AccessToken){
            Write-Host "Successfully obtained token from $($DryvIQServer)`r`n" -ForegroundColor Green
            return $AccessToken;
        }
        else {
            Write-Host "Error obtaining token from $($DryvIQServer). Please check the URL, Username and/or Password.`r`n" -ForegroundColor Red
            exit
        }
    }
    catch
    {
        Write-Host "Error obtaining token from $($DryvIQServer). Please check the URL, Username and/or Password.`r`n" -ForegroundColor Red
        exit
    }

<#
    .SYNOPSIS
    This gets an authentication token.

    .DESCRIPTION
    This gets an authentication token, which you need when making API calls.

    .OUTPUTS
    A bearer token in a string format. You can pipe this value into Set-DryvIQRequestHeader.

    .PARAMETER DryvIQServer
    This is the DryvIQ server. Typically this is set to "http://localhost:9090"
.
    .PARAMETER DryvIQAdminUser
    This is the admin user for the DryvIQ server.

    .PARAMETER DryvIQAdminUserPasswrd
    This is the password for the admin user of the DryvIQ server.

    .EXAMPLE
    PS C:\>  Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"

    Trying to connect to http://localhost:9090/connect/token
    Successfully obtained token from http://localhost:9090/connect/token

    eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4ZmE..... (token)

        .EXAMPLE
    PS C:\>  $AccessToken = Get-DryvIQAccessToken -DryvIQServer "http://localhost:9090" -DryvIQAdminUser "admin" -DryvIQAdminUserPasswrd "VeryStrongPassword"

    Trying to connect to http://localhost:9090/connect/token
    Successfully obtained token from http://localhost:9090/connect/token

    PS C:\>  $AccessToken

    eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOWQ4NzUyYzg4ZmE..... (token)
#>

}

function Start-DryvIQTranscript {

    try { Stop-Transcript } catch {}
    $ScriptPath = $($MyInvocation.PSScriptRoot)
    New-Item -Path $ScriptPath -Name "logs" -itemtype Directory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    $logname = "log-$((Split-Path $MyInvocation.PSCommandPath -Leaf).Replace('.ps1','')).$(Get-Date -Format yyyy-MM-dd)"
    Start-Transcript -path "$ScriptPath\logs\$($logname).txt" -append
    Write-Host "`r`n"
    
}

function Stop-DryvIQTranscript {

    Write-Host "`r`n `r`n"
    try { Stop-Transcript } catch {}

}

function GetItemsBySecurityMap($securityMapId) {
    $totalItems = @()
    $maxItemsPerRequest = 1000
    $offset = 0
    $hasMore = $true

    $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
    $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken
    
    while ($hasMore)
    {
        #retrieve all items to export
        $itemsBySecurityMapRequestMethod = $DryvIQServer + "/v1/transfers/items?security_maps=$securityMapId&job_categories=$categoryId&simulation_mode=$simulationMode&source_exists=1&offset=$offset&limit=$maxItemsPerRequest&fields=id,transfer.source,transfer.id,source,destination,type,last_failure"
        $itemsBySecurityMapResponse = Invoke-RestMethod $itemsBySecurityMapRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

        $totalItems += $itemsBySecurityMapResponse.item
        $hasMore = $itemsBySecurityMapResponse.meta.has_more

        if($hasMore) #make additional item requests as necessary
        {
            $offset += $maxItemsPerRequest
        }
    }

    return $totalItems
}

function GetAccessControlIdentifier($sourceMap) {
    if($sourceMap.type -eq "group")
    {
        if($null -ne $sourceMap.name) {return $sourceMap.name}
        if($null -ne $sourceMap.username) {return $sourceMap.username}
        if($null -ne $sourceMap.email) {return $sourceMap.email} 
        return $sourceMap.id
    }
    else {
        if($null -ne $sourceMap.email) {return $sourceMap.email} 
        if($null -ne $sourceMap.username) {return $sourceMap.username}
        if($null -ne $sourceMap.id) {return $sourceMap.id}
        return $sourceMap.name
    }
}

function GetReportEntry($sourceFilePath,$destinationFilePath,$fileType,$userOrGroup,$permissions,$status,$errorMessage) {

    $reportEntry = New-Object System.Object
    $reportEntry | Add-Member -Type NoteProperty -Name SourcePath -Value ($sourceFilePath)
    $reportEntry | Add-Member -Type NoteProperty -Name DestinationPath -Value ($destinationFilePath)
    $reportEntry | Add-Member -Type NoteProperty -Name FileType -Value ($fileType)
    $reportEntry | Add-Member -Type NoteProperty -Name UserOrGroup -Value ($userOrGroup)
    $reportEntry | Add-Member -Type NoteProperty -Name Permissions -Value ($permissions)
    $reportEntry | Add-Member -Type NoteProperty -Name Status -Value ($status)
    $reportEntry | Add-Member -Type NoteProperty -Name ErrorMessage -Value ($errorMessage)
    return $reportEntry
}

function GetItemPermissionLevel($transferItemId,$securityMapId){
    try
    {
        $conn = New-Object System.Data.SqlClient.SqlConnection

        #use SQL Server authentication if credentials specifiied
        if([string]::IsNullOrWhiteSpace($sqlConnectionUsername))
        {
            $conn.ConnectionString =("Data Source=$dataSource;Initial Catalog=$DryvIQDatabaseName;Integrated Security=SSPI")
        }
        else
        {
            $conn.ConnectionString =("Data Source=$dataSource;Initial Catalog=$DryvIQDatabaseName;User Id=$sqlConnectionUsername;Password=$sqlConnectionPassword")
        }
        
        $conn.open()

        $sqlcmd = New-Object System.Data.SqlClient.SqlCommand
        $sqlcmd.connection = $conn
        $sqlcmd.CommandTimeout = 60000
        $sqlcmd.CommandText = 
        "SELECT DISTINCT 
        tp.TransferItemID, tsm.UniqueID,
        CASE 
            WHEN tp.AccessControl = 0 THEN 'Allow' 
            WHEN tp.AccessControl = 1 THEN 'Deny'
            ELSE NULL 
        END AS Access,
        tp.Rights AS Rights
        FROM $DryvIQDatabaseName.dbo.TransferPermissions tp
        INNER JOIN $DryvIQDatabaseName.dbo.TransferSecurityMaps tsm
        ON tp.SecurityMapID = tsm.ID
        AND tsm.UniqueID = '$securityMapId'
        AND tp.TransferItemID = $transferItemId
        GROUP BY tp.TransferItemID, tsm.UniqueID, AccessControl, Rights"
        
        $sqladapter = New-Object System.Data.SqlClient.SqlDataAdapter
        $sqladapter.SelectCommand = $sqlcmd
        $dataset = New-Object System.Data.DataSet
        $sqladapter.Fill($dataset) | Out-Null
        $itemPermission = $dataset.Tables[0]

        return ,$itemPermission
    }
    finally
    {
        $conn.Dispose()
    }
}

function GetItemPermissionLevels($transferItemId,$securityMapId){
    $totalItems = @()
    $maxItemsPerRequest = 1000
    $offset = 0
    $hasMore = $true

    $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
    $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken
    
    while ($hasMore)
    {
        #retrieve all items to export
        $itemPermissionLevelRequestMethod = $DryvIQServer + "/v1/transfers/permissions?security_map_id=$securityMapId&transfer_item_id=$transferItemId&offset=$offset&limit=$maxItemsPerRequest&fields=rights,access,audit_trail"
        $itemPermissionLevelResponse = Invoke-RestMethod $itemPermissionLevelRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'

        $totalItems += $itemPermissionLevelResponse.item
        $hasMore = $itemPermissionLevelResponse.meta.has_more

        if($hasMore) #make additional item requests as necessary
        {
            $offset += $maxItemsPerRequest
        }
    }

    $itemPermissionLevels = @()
    foreach ($item in $totalItems)
    {
        if(!($item | Get-Member "audit_trail")) {
            $itemPermissionLevels += $item
         }
    }
    return ,$itemPermissionLevels
}

function ProcessAffectedItems($map) {
    $userOrGroup = GetAccessControlIdentifier $map.source
    Write-Host "Processing affected items for" $map.source.type $userOrGroup

    $affectedItems = GetItemsBySecurityMap $map.id

    #there will be 0 affected items for unresolved mappings
    if ($affectedItems.count -eq 0)
    {
        $connectionSourcePath = GetConnectionSourceFolderPath $map.transfer.source.connection.id
        
        if($null -ne $connectionSourcePath)
        {
            $connectionSourcePath = $connectionSourcePath.trimend('\')
        }

        $folderPaths = GetJobFolderPaths $map.transfer.id
        $jobSourceTargetPath = $folderPaths.sourcePath -replace '/','\'

        $filePath = $connectionSourcePath + $jobSourceTargetPath #do not have an item source path

        #when $map.resolution -eq "exception",the Security map has 0 resolved items. 
        #Omitting this occurrence from report since no permission record exists. This Occurs in author preservation.

        if($map.resolution -eq "unresolved") {
            #do not have an item type, permission level or failure message.
            $reportEntry = GetReportEntry (NullString $filePath) "" "" (NullString $userOrGroup) "" (NullString $map.resolution) ""
            [void]$reportEntries.add($reportEntry)
        } 
    }

    #Retrieve item permission mappings for resolved security maps.
    foreach ($item in $affectedItems)
    {
        $connectionSourcePath = GetConnectionSourceFolderPath $item.transfer.source.connection.id
        
        if($null -ne $connectionSourcePath)
        {
            $connectionSourcePath = $connectionSourcePath.trimend('\')
        }

        $folderPaths = GetJobFolderPaths $item.transfer.id
        $jobSourceTargetPath = $folderPaths.sourcePath -replace '/','\'

        $itemSourcePath = $item.source.path.trimstart('/') -replace '/','\'
        $filePath = $connectionSourcePath + $jobSourceTargetPath + $itemSourcePath

        $destinationPath = $folderPaths.destinationPath.trimend('/') + $item.destination.path
        
        $errorMessage = ""
        if($null -ne $item.last_failure -and $item.last_failure.event -eq "permission_fail" ) {
            $errorMessage = $item.last_failure.message
        }  

        $itemPermissionLevels = GetItemPermissionLevel $item.id $map.id
        $permissionLevels = ""
  
         if($itemPermissionLevels.Rows.Count -ge 1) { #add all permission levels assigned/revoked
            foreach ($permission in $itemPermissionLevels) {
                if ($null -ne $permission -and $permission.rights -ne [System.DBNull]::Value) {
                    $permissionLevels += ($permission.access + ": " + [ItemPermissionLevels]$permission.rights) -join ","
                }
            }
        }

        $reportEntry = GetReportEntry (NullString $filePath) (NullString $destinationPath) (NullString $item.type) (NullString $userOrGroup) (NullString $permissionLevels) (NullString $map.resolution) (NullString $errorMessage)
        [void]$reportEntries.add($reportEntry)
    }        
}

#endregion

Start-DryvIQTranscript

# requires -Version 5
[Flags()]
enum ItemPermissionLevels
{
    None = 0
    Read = 1
    Write = 2
    Append = 4
    Delete = 8
    ReadPermissions = 16
    WritePermissions = 32
    ReadWrite = 15
    FullPermissions = 48
    FullControl = 63
}

try {

    $connectionIdToPathMap          = [System.Collections.Concurrent.ConcurrentDictionary[String,String]]@{}
    $transferIdToSourcePathMap      = [System.Collections.Concurrent.ConcurrentDictionary[String,String]]@{}
    $transferIdToDestinationPathMap = [System.Collections.Concurrent.ConcurrentDictionary[String,String]]@{}
    
    $securityMaps                   = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
    $reportEntries                  = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
    $maxItemsPerRequest             = 1000
    $offset                         = $startOffset
    $hasMore                        = $true

    $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
    $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken
    
    while ($hasMore -and ([string]::IsNullOrEmpty($maxOffset) -or  $offset -lt $maxOffset))
    {
        #retrieve all security maps
        $transferSecurityMapRequestMethod   = $DryvIQServer + "/v1/transfers/security_map?active=1&job_categories=$categoryId&simulation_mode=$simulationMode&offset=$offset&limit=$maxItemsPerRequest&fields=id,source,transfer.source,transfer.id,resolution"
        $transferSecurityMapResponse        = Invoke-RestMethod $transferSecurityMapRequestMethod -Headers $authHeader # -Proxy 'http://localhost:8888'
        $securityMaps                       += $transferSecurityMapResponse.item
        $hasMore                            = $transferSecurityMapResponse.meta.has_more

        if($hasMore) #make additional item requests as necessary
        {
            $offset += $maxItemsPerRequest
        }

        if ($securityMaps.Count % $maxBatchSize -eq 0 -or !$hasMore)
        { 
            #intermittent token refresh and batch commit
            Write-host "Processed next batch"
            $accessToken    = Get-DryvIQAccessToken -DryvIQServer $DryvIQServer -DryvIQAdminUser $DryvIQAdminUser -DryvIQAdminUserPasswrd $DryvIQAdminUserPasswrd
            $authHeader     = Set-DryvIQRequestHeader -AccessToken $accessToken

            $securityMaps | Invoke-Parallel -ImportVariables -ImportFunctions -Throttle $numberOfThreads -RunspaceTimeout 3600 -ScriptBlock {
               ProcessAffectedItems $_
            }

            #write items to file
            $reportEntries | Select-Object -Property SourcePath, DestinationPath, FileType, UserOrGroup, Permissions, Status, ErrorMessage | Export-Csv $logfile -NoTypeInformation -Encoding utf8 -Append

            #clear maps and affected items from memory
            $securityMaps   = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
            $reportEntries  = [System.Collections.ArrayList]::Synchronized((New-Object System.Collections.ArrayList))
        }
    }
    
    Write-Host "Permission Inventory Report Successfully Created."
}
catch{
    $exMsg  = $_.Exception.Message
    $line   = $_.Exception.InvocationInfo.ScriptLineNumber
    $st     = $_.ScriptStackTrace
    Write-Host "An error occurred while retrieving item permissions: ${exMsg}. Line ${line}. ${st}. $($error[0])." -ForegroundColor Red
    return
} 

Stop-DryvIQTranscript
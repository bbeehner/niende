<#
.DESCRIPTION
    Retrieves permissions for each item using /permissions.csv
        This export mirrrors the "Export Full Permissions Report" available in Core Sharing Insights page(s)

.INPUTS
    skysyncServer               =   Url to access SkySync environment.
    categoryId                  =   Single category or comma delimited list of categoryIds. ex:  $categoryId = "1" OR $categoryId = "1,2,3"
    skysyncAdminUser            =   Administrator username to access SkySync
    skysyncAdminUserPassword    =   Administrator password to access SkySync
    jobId                       =   Single or Comma delimited list of Job Ids.
    LogFile                     =   Location to write output log file

.OUTPUTS
    CSV File to path location
.NOTES
    * To route local endpoint calls from PowerShell through Fiddler for debugging/testing:
        * $skysyncServer to use fqdn/IP and not "localhost"
        * uncomment -Proxy 'http://localhost:8888', which is Fiddlers Proxy address
    
.EXAMPLE
    .\'FullPermissionsReport.ps1' $skysyncServer=http://DESKTOP-9BHVIFS:9090/ $categoryId=2
#>

Param(
	[string]$skysyncServer = "http://localhost:9090/",
    [string]$categoryId = "",
    [string]$skysyncAdminUser = "admin",
    [string]$skysyncAdminUserPassword = 'Skyme1100!',
    [string]$jobId = "",
    $logFile = ".\FullPermissionsReport_all $(get-date -f yyyy-MM-dd).csv"
)

#negotiate TLS1.2 for to support https requests
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 

function get-skysync-access-token {
	param( [string] $skysyncServer, [string] $skysyncAdminUser, [string] $skysyncAdminUserPassword )
	$accessRequestUrl = $skysyncServer + "connect/token"

	$accessRequestBody = @{
		grant_type = "password"
		scope = "offline_access profile roles"
		resource = $skysyncServer
		username = $skysyncAdminUser
		password = $skysyncAdminUserPassword
	}

	$accessRequestResult = Invoke-RestMethod -Method 'Post' -Uri $accessRequestUrl -Body $accessRequestBody
	return $accessRequestResult.access_token
}

function get-request-header {
	param( [string]$accessToken )
	$requestHeader = @{
		Authorization = "Bearer " + $accessToken
		Accept = "application/json"
	}
	return $requestHeader
}

try {
    $accessToken = get-skysync-access-token $skysyncServer $skysyncAdminUser $skysyncAdminUserPassword
    $authHeader = get-request-header $accessToken
    
    #retrieve Permission Export
    $transferSecurityMapRequestMethod = $skysyncServer + "v1/transfers/permissions.csv"
    
    if ($jobId -ne "")
    {
        $transferSecurityMapRequestMethod = $transferSecurityMapRequestMethod + "?job_ids=$jobId"
        $logfile = $logfile -replace "all", $jobid
    }
    elseif ($categoryId -ne "")
    {
        $transferSecurityMapRequestMethod = $transferSecurityMapRequestMethod + "?job_category_ids=$categoryId"
        $logfile = $logfile -replace "all", $categoryId
    }

    Invoke-RestMethod $transferSecurityMapRequestMethod -Headers $authHeader | Out-File -FilePath $logFile # -Proxy 'http://localhost:8888'

    Write-Host "Permission Report Successfully Created." -ForegroundColor Green
}
catch{
    $exMsg = $_.Exception.Message
    $line = $_.Exception.InvocationInfo.ScriptLineNumber
    $st = $_.ScriptStackTrace
    Write-Host "An error occurred while retrieving item permissions: ${exMsg}. Line ${line}. ${st}" -ForegroundColor Red
    return
} 